from numpy import *
import numpy as np
from Main_functions.HSS_L2_Linfty_noise04 import generate_data, Test_error_KGD_BSP
# from HSS_L2_Linfty_noise06_diffL_flat import generate_data, Test_error_KGD_BSP

import time
from datetime import datetime

time_start = time.time()

start_time = datetime.now()
start_time_str = start_time.strftime('%Y.%m.%d')

# for simualtion: sim_t_diffalgorithm_with_diffpercentof|D|_curve


dim = 3
step_size = 3

split_L_tr_per = 0.7  # 固定不变
noise_var = 0.6
train_size = 1000
train, test = (train_size, dim), (200, dim)
# C_bsp_list = [0.00001, 0.0001, 0.001, 0.01] + [i * 0.2 for i in range(1, 31, 1)]  # d=1

C_bsp_list = [0.00001, 0.0001, 0.001, 0.01] + [i * 0.05 for i in range(1, 21, 1)]  # [0,1] L2 norm

C_bsp_list2 = [0.00001, 0.0001, 0.001, 0.01] + [i * 0.1 for i in range(1, 41, 1)] # [0,4] infty

log_filename = f'./KGD_result_data_log_file/20_trials_result_log/BSP_dim{dim}_noisevar{noise_var}_fixedD{train_size}_diffL_stepsize{step_size}_start{start_time_str}_new_flat_time.txt'
# 初始化日志文件
with open(log_filename, 'w') as log_file:
    log_file.write("Start Logging\n")

L2_C_20trial, L2_t_list_20trial, L2_norm_list_20trial = np.empty(shape=(5, 13)), np.empty(shape=(5, 13)), np.empty(shape=(5, 13))
Linfinity_C_20trial, Linfinity_t_list_20trial, Linfinity_norm_list_20trial = np.empty(shape=(5, 13)), np.empty(shape=(5, 13)), np.empty(shape=(5, 13))
L2_norm_list_20trial_mean, Linfinity_norm_list_20trial_mean = [], []
split_L_list = [100, 200, 300, 400, 500, 600, 700, 800, 900, 1000]
index_1 = 0
time_start1 = time.time()
time_list = []
for split_L in split_L_list:
    time_start = time.time()
    split_L_tr = int(split_L * split_L_tr_per)
    L2_C_list, L2_t_star_list, L2_test_error_list, Linfinity_C_list, Linfinity_t_star_list, Linfinity_test_error_list = [], [], [], [], [], []
    print(
        ' ------------------  💎 dim: %s; step_size: %s; fixed train_size: %s; split_L_per: %s; split_L_tr_per: %s; split_L_tr:%s; noise_var: %s  ------------------' % (
        dim, step_size, train_size, split_L, split_L_tr_per, split_L_tr, noise_var))
    for trial_i in range(15, 16):
        print('------------------   trial_i: %s  ------------------' % (trial_i - 24))
        np.random.seed(trial_i)
        _, _, X_test, y_test = generate_data((300, dim), (500, dim), dim, noise_var)  # 保证 test只在不同的trial时有所不同
        X_train, y_train, _, _ = generate_data(train, test, dim, noise_var)
        # L2_C, L2_t_star, L2_test_error, Linfinity_C, Linfinity_t_star, Linfinity_test_error = Test_error_KGD_BSP(X_train, y_train, X_test, y_test, dim, step_size, split_L, split_L_tr, log_filename, C_bsp_list, C_bsp_list2)
        L2_C, L2_t_star, L2_test_error, Linfinity_C, Linfinity_t_star, Linfinity_test_error = Test_error_KGD_BSP(X_train, y_train, X_test, y_test, dim, step_size, split_L, split_L_tr, log_filename)

        L2_C_list.append(L2_C)
        L2_t_star_list.append(L2_t_star)
        L2_test_error_list.append(L2_test_error)
        Linfinity_C_list.append(Linfinity_C)
        Linfinity_t_star_list.append(Linfinity_t_star)
        Linfinity_test_error_list.append(Linfinity_test_error)
        print('L2_t_star_list:', L2_t_star_list)
        print('L2_test_error_list:', L2_test_error_list)
        print('Linfinity_t_star_list:', Linfinity_t_star_list)
        print('Linfinity_test_error_list:', Linfinity_test_error_list)

        # 💎logging in process "for trial_i in range(10, 20)"
        with open(log_filename, 'a') as log_file:
            log_file.write(
                f'--------------------------- train_size: {train_size}; trial_i: {trial_i - 10}--------------------------- \n'
                f'history:\nL2_C_list: {L2_C_list}\n'
                f'L2_t_star_list: {L2_t_star_list}\n'
                f'L2_test_error_list: {L2_test_error_list}\n'
                f'Linfinity_C_list: {Linfinity_C_list}\n'
                f'Linfinity_t_star_list: {Linfinity_t_star_list}\n'
                f'Linfinity_test_error_list: {Linfinity_test_error_list}\n')

    L2_C_20trial[:, index_1] = np.squeeze(np.array(L2_C_list))
    L2_t_list_20trial[:, index_1] = np.squeeze(np.array(L2_t_star_list))
    L2_norm_list_20trial[:, index_1] = np.squeeze(np.array(L2_test_error_list))
    L2_test_error_list_mean = np.mean(L2_test_error_list)
    L2_norm_list_20trial_mean.append(L2_test_error_list_mean)

    Linfinity_C_20trial[:, index_1] = np.squeeze(np.array(Linfinity_C_list))
    Linfinity_t_list_20trial[:, index_1] = np.squeeze(np.array(Linfinity_t_star_list))
    Linfinity_norm_list_20trial[:, index_1] = np.squeeze(np.array(Linfinity_test_error_list))
    Linfinity_test_error_list_mean = np.mean(Linfinity_test_error_list)
    Linfinity_norm_list_20trial_mean.append(Linfinity_test_error_list_mean)
    index_1 = index_1 + 1
    time_total = time.time() - time_start
    time_list.append(time_total)
    print('time_list', time_list)

    # 💎logging in process "for trial_i in range(10, 20)"
    with open(log_filename, 'a') as log_file:
        log_file.write(
            f'------------------------------------------------- train_size: {train_size} ------------------------------------------------- \n'
            f'history:\nL2_C_20trial: {L2_C_20trial}\n'
            f'L2_t_list_20trial: {L2_t_list_20trial}\n'
            f'L2_norm_list_20trial: {L2_norm_list_20trial}\n'
            f'L2_norm_list_20trial_mean: {L2_norm_list_20trial_mean}\n'
            f'Linfinity_C_20trial: {Linfinity_C_20trial}\n'
            f'Linfinity_t_list_20trial: {Linfinity_t_list_20trial}\n'
            f'Linfinity_norm_list_20trial: {Linfinity_norm_list_20trial}\n'
            f'Linfinity_norm_list_20trial_mean: {Linfinity_norm_list_20trial_mean}\n'
            f'time_list: {time_list}\n'
        )

    # ☀️save in process
    KGD_result = {
        'L2_C_20trial': L2_C_20trial,
        'L2_t_list_20trial': L2_t_list_20trial,
        'L2_norm_list_20trial': L2_norm_list_20trial,
        'L2_norm_list_20trial_mean': L2_norm_list_20trial_mean,
        'Linfinity_C_20trial': Linfinity_C_20trial,
        'Linfinity_t_list_20trial': Linfinity_t_list_20trial,
        'Linfinity_norm_list_20trial': Linfinity_norm_list_20trial,
        'Linfinity_norm_list_20trial_mean': Linfinity_norm_list_20trial_mean,
    'time_list': time_list}
    filename = f'./KGD_result_data/20_trials_result/BSP_dim{dim}_noisevar{noise_var}_fixedD{train_size}_diffL_stepsize{step_size}_new_flat_time.npy'
    np.save(filename, KGD_result)

time_total = time.time() - time_start1

# ☀️save final
KGD_result = {
    'L2_C_20trial': L2_C_20trial,
    'L2_t_list_20trial': L2_t_list_20trial,
    'L2_norm_list_20trial': L2_norm_list_20trial,
    'L2_norm_list_20trial_mean': L2_norm_list_20trial_mean,
    'Linfinity_C_20trial': Linfinity_C_20trial,
    'Linfinity_t_list_20trial': Linfinity_t_list_20trial,
    'Linfinity_norm_list_20trial': Linfinity_norm_list_20trial,
    'Linfinity_norm_list_20trial_mean': Linfinity_norm_list_20trial_mean}
filename = f'./KGD_result_data/20_trials_result/BSP_dim{dim}_noisevar{noise_var}_fixedD{train_size}_diffL_stepsize{step_size}_new_flat_time.npy'
np.save(filename, KGD_result)
with open(log_filename, 'a') as log_file:
    log_file.write(f'Total running time: {time_total}\n')

print('------------------------------ runing information ------------------------------------------')
print('running time:', time_total)
print(filename)
print(KGD_result.keys())
print(log_filename)
print("Logging complete.")




