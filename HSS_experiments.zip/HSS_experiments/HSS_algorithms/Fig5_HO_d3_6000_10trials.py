from numpy import *
import numpy as np
from Main_functions.KGD_algorithm_by_Hold_out_L2_infinity_norm import generate_data, Test_error_KGD_HO
import time
from datetime import datetime
time_start = time.time()
start_time = datetime.now()
start_time_str = start_time.strftime('%Y.%m.%d')


dim = 3
step_size = 3
split_L_tr_per = 0.7 # 固定不变


split_L_per = 1.0 # 💎1， 0.8，0.6， 0.4
noise_var = 0.6

log_filename = f'../KGD_result_data_log_file/20_trials_result_log/HO_6000_10trials_dim{dim}_noisevar{noise_var}_split_L_per{split_L_per}_stepsize{step_size}_start{start_time_str}_log.txt'
# 初始化日志文件
with open(log_filename, 'w') as log_file:
    log_file.write("Start Logging\n")


L2_t_list_20trial, L2_norm_list_20trial = np.empty(shape=(10, 30)), np.empty(shape=(10, 30))
Linfinity_t_list_20trial, Linfinity_norm_list_20trial = np.empty(shape=(10, 30)), np.empty(shape=(10, 30))

L2_norm_list_20trial_mean, Linfinity_norm_list_20trial_mean = [], []
for size_i in range(1,31):
    L2_t_star_list, L2_test_error_list, Linfinity_t_star_list, Linfinity_test_error_list = [], [], [], []
    train_size = 200 * size_i
    split_L = int(train_size * split_L_per)
    split_L_tr = int(split_L * split_L_tr_per)
    train, test = (train_size, dim), (200, dim)
    print(' ------------------  💎 dim: %s; step_size: %s; train_size: %s; split_L_per: %s; split_L_tr_per: %s; noise_var: %s  ------------------' % (dim, step_size, train_size, split_L_per, split_L_tr_per, noise_var))

    for trial_i in range(15, 25):
        print('------------------   trial_i: %s  ------------------' % (trial_i-9))
        np.random.seed(trial_i)
        _, _, X_test, y_test = generate_data((300, dim), (500, dim), dim, noise_var)  #保证 test只在不同的trial时有所不同
        X_train, y_train, _, _ = generate_data(train, test, dim, noise_var)

        L2_t_star, L2_test_error, Linfinity_t_star, Linfinity_test_error = Test_error_KGD_HO(X_train, y_train, X_test, y_test, dim, split_L, step_size)
        L2_t_star_list.append(L2_t_star)
        L2_test_error_list.append(L2_test_error)
        Linfinity_t_star_list.append(Linfinity_t_star)
        Linfinity_test_error_list.append(Linfinity_test_error)
        print('L2_t_star_list:', L2_t_star_list)
        print('L2_test_error_list:', L2_test_error_list)
        print('Linfinity_t_star_list:', Linfinity_t_star_list)
        print('Linfinity_test_error_list:', Linfinity_test_error_list)


        # 💎logging in process "for trial_i in range(10, 20)"
        with open(log_filename, 'a') as log_file:
            log_file.write(
                f'--------------------------- train_size: {train_size}; trial_i: {trial_i-10}--------------------------- \n'
                f'history:\nL2_t_star_list: {L2_t_star_list}\n'
                f'L2_test_error_list: {L2_test_error_list}\n'
                f'Linfinity_t_star_list: {Linfinity_t_star_list}\n'
                f'Linfinity_test_error_list: {Linfinity_test_error_list}\n')

    L2_t_list_20trial[:, size_i - 1] = np.squeeze(np.array(L2_t_star_list))
    L2_norm_list_20trial[:, size_i - 1] = np.squeeze(np.array(L2_test_error_list))
    L2_test_error_list_mean = np.mean(L2_test_error_list)
    L2_norm_list_20trial_mean.append(L2_test_error_list_mean)

    Linfinity_t_list_20trial[:, size_i - 1] = np.squeeze(np.array(Linfinity_t_star_list))
    Linfinity_norm_list_20trial[:, size_i - 1] = np.squeeze(np.array(Linfinity_test_error_list))
    Linfinity_test_error_list_mean = np.mean(Linfinity_test_error_list)
    Linfinity_norm_list_20trial_mean.append(Linfinity_test_error_list_mean)


    # 💎logging in process "for trial_i in range(10, 20)"
    with open(log_filename, 'a') as log_file:
        log_file.write(
            f'------------------------------------------------- train_size: {train_size} ------------------------------------------------- \n'
            f'history:\nL2_t_list_20trial: {L2_t_list_20trial}\n'
            f'L2_norm_list_20trial: {L2_norm_list_20trial}\n'
            f'L2_norm_list_20trial_mean: {L2_norm_list_20trial_mean}\n'
            f'Linfinity_t_list_20trial: {Linfinity_t_list_20trial}\n'
            f'Linfinity_norm_list_20trial: {Linfinity_norm_list_20trial}\n'
            f'Linfinity_norm_list_20trial_mean: {Linfinity_norm_list_20trial_mean}\n'
        )

    # ☀️save in process
    KGD_result = {
        'L2_t_list_20trial': L2_t_list_20trial,
        'L2_norm_list_20trial': L2_norm_list_20trial,
        'L2_norm_list_20trial_mean': L2_norm_list_20trial_mean,
        'Linfinity_t_list_20trial': Linfinity_t_list_20trial,
        'Linfinity_norm_list_20trial': Linfinity_norm_list_20trial,
        'Linfinity_norm_list_20trial_mean': Linfinity_norm_list_20trial_mean}
    filename = f'../KGD_result_data/20_trials_result/HO_6000_10trials_dim{dim}_noisevar{noise_var}_split_L_per{split_L_per}_stepsize{step_size}.npy'
    np.save(filename, KGD_result)


time_total = time.time() - time_start
# ☀️save final
KGD_result = {
    'L2_t_list_20trial': L2_t_list_20trial,
    'L2_norm_list_20trial': L2_norm_list_20trial,
    'L2_norm_list_20trial_mean': L2_norm_list_20trial_mean,
    'Linfinity_t_list_20trial': Linfinity_t_list_20trial,
    'Linfinity_norm_list_20trial': Linfinity_norm_list_20trial,
    'Linfinity_norm_list_20trial_mean': Linfinity_norm_list_20trial_mean}
filename = f'../KGD_result_data/20_trials_result/HO_6000_10trials_dim{dim}_noisevar{noise_var}_split_L_per{split_L_per}_stepsize{step_size}.npy'
np.save(filename, KGD_result)
with open(log_filename, 'a') as log_file:
    log_file.write(f'Total running time: {time_total}\n')


print('------------------------------ runing information ------------------------------------------')
print('running time:', time_total)
print(filename)
print(KGD_result.keys())
print(log_filename)
print("Logging complete.")




