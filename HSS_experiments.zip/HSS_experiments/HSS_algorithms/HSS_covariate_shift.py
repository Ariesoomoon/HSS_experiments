from numpy import *
import numpy as np
from Main_functions.HSS_L2_Linfty_noise06_range01 import generate_data, Test_error_KGD_BSP, generate_data_test, distance_KL
import time
from datetime import datetime
time_start = time.time()
start_time = datetime.now()
start_time_str = start_time.strftime('%Y.%m.%d')


dim = 1
step_size = 1
split_L_tr_per = 0.7 # 固定不变
split_L_per = 1 # 💎1， 0.8，0.6， 0.4
noise_var = 0.6

mu_x3 = 0.0
sigma_x3_list = [1.1, 1.2, 1.3, 1.4, 1.5]

train_size = 2000
split_L = int(train_size * split_L_per)
split_L_tr = int(split_L * split_L_tr_per)
train, test = (train_size, dim), (200, dim)



log_filename = f'./KGD_result_data_log_file/20_trials_result_log/HSS_trainsize{train_size}_dim{dim}_split_L_per{split_L_per}_mu{mu_x3}_covarite_shift_log.txt'
# 初始化日志文件
with open(log_filename, 'w') as log_file:
    log_file.write("Start Logging\n")


L2_C_20trial, L2_t_list_20trial, L2_norm_list_20trial = np.empty(shape=(10, 5)), np.empty(shape=(10, 5)), np.empty(shape=(10, 5))
Linfinity_C_20trial, Linfinity_t_list_20trial, Linfinity_norm_list_20trial = np.empty(shape=(10, 5)), np.empty(shape=(10, 5)), np.empty(shape=(10, 5))
L2_norm_list_20trial_mean, Linfinity_norm_list_20trial_mean, distance_KL_list_mean_20trial = [], [], []


for i in range(len(sigma_x3_list)):
    sigma_x3 = sigma_x3_list[i]
    print('sigma_x3', sigma_x3)
    L2_C_list, L2_t_star_list, L2_test_error_list, Linfinity_C_list, Linfinity_t_star_list, Linfinity_test_error_list = [], [], [], [], [], []
    distance_KL_list = []
    print(' ------------------  💎 dim: %s; step_size: %s; train_size: %s; split_L_per: %s; split_L_tr_per: %s; noise_var: %s  ------------------' % (dim, step_size, train_size, split_L_per, split_L_tr_per, noise_var))

    for trial_i in range(15, 25):
        print('------------------   trial_i: %s  ------------------' % (trial_i-15))
        np.random.seed(trial_i)
        X_train, y_train, _, _ = generate_data(train, test, dim, noise_var)
        # _, _, X_test, y_test = generate_data((300, dim), (500, dim), dim, noise_var)  #保证 test只在不同的trial时有所不同； 用不同于训练数据的分布生成测试数据
        _, _, X_test, y_test = generate_data_test((300, dim), (500, dim), dim, noise_var, mu_x3, sigma_x3)  # 保证 test只在不同的trial时有所不同； 用不同于训练数据的分布生成测试数据


        L2_C, L2_t_star, L2_test_error, Linfinity_C, Linfinity_t_star, Linfinity_test_error = Test_error_KGD_BSP(X_train, y_train, X_test, y_test, dim, step_size, split_L, split_L_tr, log_filename)
        L2_C_list.append(L2_C)
        L2_t_star_list.append(L2_t_star)
        L2_test_error_list.append(L2_test_error)
        Linfinity_C_list.append(Linfinity_C)
        Linfinity_t_star_list.append(Linfinity_t_star)
        Linfinity_test_error_list.append(Linfinity_test_error)

        # 计算KL divergence
        X_train = np.squeeze(X_train)
        X_test = np.squeeze(X_test)
        print(X_train.shape)
        print(X_test.shape)
        KL = distance_KL(X_train, X_test) # (n, )
        distance_KL_list.append(KL)
        print('distance_KL_list:', distance_KL_list)
        print('L2_t_star_list:', L2_t_star_list)
        print('L2_test_error_list:', L2_test_error_list)
        print('Linfinity_t_star_list:', Linfinity_t_star_list)
        print('Linfinity_test_error_list:', Linfinity_test_error_list)


    L2_C_20trial[:, i] = np.squeeze(np.array(L2_C_list))
    L2_t_list_20trial[:, i] = np.squeeze(np.array(L2_t_star_list))
    L2_norm_list_20trial[:, i] = np.squeeze(np.array(L2_test_error_list))
    L2_test_error_list_mean = np.mean(L2_test_error_list)
    L2_norm_list_20trial_mean.append(L2_test_error_list_mean)

    Linfinity_C_20trial[:, i] = np.squeeze(np.array(Linfinity_C_list))
    Linfinity_t_list_20trial[:, i] = np.squeeze(np.array(Linfinity_t_star_list))
    Linfinity_norm_list_20trial[:, i] = np.squeeze(np.array(Linfinity_test_error_list))
    Linfinity_test_error_list_mean = np.mean(Linfinity_test_error_list)
    Linfinity_norm_list_20trial_mean.append(Linfinity_test_error_list_mean)
    distance_KL_list_mean = np.mean(distance_KL_list)
    distance_KL_list_mean_20trial.append(distance_KL_list_mean)
    print('L2_norm_list_20trial_mean:', L2_norm_list_20trial_mean)
    print('Linfinity_norm_list_20trial_mean:', Linfinity_norm_list_20trial_mean)
    print('distance_KL_list_mean:', distance_KL_list_mean)

    # 💎logging in process "for trial_i in range(10, 20)"
    with open(log_filename, 'a') as log_file:
        log_file.write(
            f'------------------------------------------------- train_size: {train_size} ------------------------------------------------- \n'
            f'history:\nL2_C_20trial: {L2_C_20trial}\n'
            f'L2_t_list_20trial: {L2_t_list_20trial}\n'
            f'L2_norm_list_20trial: {L2_norm_list_20trial}\n'
            f'L2_norm_list_20trial_mean: {L2_norm_list_20trial_mean}\n'
            f'Linfinity_C_20trial: {Linfinity_C_20trial}\n'
            f'Linfinity_t_list_20trial: {Linfinity_t_list_20trial}\n'
            f'Linfinity_norm_list_20trial: {Linfinity_norm_list_20trial}\n'
            f'Linfinity_norm_list_20trial_mean: {Linfinity_norm_list_20trial_mean}\n'
            f'distance_KL_list_mean: {distance_KL_list_mean}\n'
            f'distance_KL_list: {distance_KL_list}\n'
        )


time_total = time.time() - time_start
# ☀️save final
KGD_result = {
    'distance_KL_list_mean_20trial': distance_KL_list_mean_20trial,
    'L2_C_20trial': L2_C_20trial,
    'L2_t_list_20trial': L2_t_list_20trial,
    'L2_norm_list_20trial': L2_norm_list_20trial,
    'L2_norm_list_20trial_mean': L2_norm_list_20trial_mean,
    'Linfinity_C_20trial': Linfinity_C_20trial,
    'Linfinity_t_list_20trial': Linfinity_t_list_20trial,
    'Linfinity_norm_list_20trial': Linfinity_norm_list_20trial,
    'Linfinity_norm_list_20trial_mean': Linfinity_norm_list_20trial_mean}


filename = f'./KGD_result_data/20_trials_result/HSS_trainsize{train_size}_dim{dim}_split_L_per{split_L_per}_mu{mu_x3}_covarite_shift.npy'
# filename = f'../KGD_result_data/20_trials_result/BSP_trainsize{train_size}_dim{dim}_noisevar{noise_var}_split_L_per{split_L_per}_stepsize{step_size}_original_covarite_shift.npy'
np.save(filename, KGD_result)
with open(log_filename, 'a') as log_file:
    log_file.write(f'Total running time: {time_total}\n')


print('------------------------------ runing information ------------------------------------------')
print('running time:', time_total)
print(filename)
print(KGD_result.keys())
print(log_filename)
print("Logging complete.")

