import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
config = {
    "font.family":'Times New Roman',
    "font.size": 20,
    "mathtext.fontset":'stix',
}
rcParams.update(config)
import numpy as np
import matplotlib.pyplot as plt
fig, ax = plt.subplots()  # 子图
def list_generator(mean, dis, number):  # 封装一下这个函数，用来后面生成数据
    return np.random.normal(mean, dis * dis, number)  # normal分布，输入的参数是均值、标准差以及生成的数量



dim = 1
step_size = 1 # noise=0时用1.4
train_size = 2000
'''  ⬆----------------------- 💎 需要手动改的地方 -----------------------------------------'''
noise_var = 0.6 # 只有0.2和0.0的结果
split_L_tr_per = 0.7 # 固定不变
split_L_per_BS = 1.0  # ⚠️，不用这个参数，只是占个位置
split_L_per = 1
mu_x3 = 0.0
sigma_x3_list = [1.1, 1.2, 1.3, 1.4, 1.5]



'''--------------------- 1000 KL 不同时的数据， 其中HSS， L=0.6, range(0,1) ----------------------'''

filename_BS = f'../HSS_result_data/20_trials_result/BS_trainsize{train_size}_dim{dim}_split_L_per{split_L_per}_mu{mu_x3}_covarite_shift.npy'
BS_result = np.load(filename_BS, allow_pickle=True).item()
BS_l2norm = BS_result['Linfinity_norm_list_20trial_mean']

filename_HO = f'../HSS_result_data/20_trials_result/HO_trainsize{train_size}_dim{dim}_split_L_per{split_L_per}_mu{mu_x3}_covarite_shift.npy'
HO_result = np.load(filename_HO, allow_pickle=True).item()
HO_l2norm = HO_result['Linfinity_norm_list_20trial_mean']
print(HO_result.keys())

filename_HSS = f'../HSS_result_data/GPU_KGD_result_10trials/covariate_shift_result/HSS_trainsize{train_size}_dim1_split_L_per0.6_mu0.0_covarite_shift.npy'
HSS_result = np.load(filename_HSS, allow_pickle=True).item()
HSS_l2norm = HSS_result['Linfinity_norm_list_20trial_mean']
KL_values = HSS_result['distance_KL_list_mean_20trial']
print('KL_values', KL_values)
# KL_values [0.06316207729311171, 0.14840158079424323, 0.23136662572973776, 0.30701561403757444, 0.3763757654387847]

# print('BS', BS_l2norm)
# print('HO', HO_l2norm)
print('HSS', HSS_l2norm)
# print(HO_result['L2_norm_list_20trial'].shape)



# HO_10trial = HO_result['L2_norm_list_20trial']

HO_10trial = HO_result['Linfinity_norm_list_20trial']
print(HO_10trial[:, 2].shape)

HSS_10trial = HSS_result['Linfinity_norm_list_20trial']

HSS_box = [HSS_10trial[:, 0], HSS_10trial[:, 1], HSS_10trial[:, 2], HSS_10trial[:, 3], HSS_10trial[:, 4]]
HO_box = [HO_10trial[:, 0], HO_10trial[:, 1], HO_10trial[:, 2], HO_10trial[:, 3], HO_10trial[:, 4]]


bp1 = ax.boxplot(HSS_box, positions=[0, 0.8, 1.6, 2.4, 3.2], widths = 0.15, patch_artist = True,
                 boxprops = {'color':'rosybrown','facecolor':'rosybrown'},
                 showfliers=False,
                 whiskerprops={'color': 'black', 'linewidth': 0.8, 'linestyle': '-'},
                 showmeans=True, meanline=True, meanprops=dict(color='forestgreen', linewidth=1.6, linestyle='--'),
                 medianprops=dict(color='mediumorchid', linewidth=1.4, linestyle='-'))




bp2 = ax.boxplot(HO_box, positions=[0.23, 1.02, 1.82, 2.62, 3.42], widths = 0.15, patch_artist = True,
                 boxprops = {'color':'sandybrown','facecolor':'sandybrown'},
                 showfliers=False,
                 whiskerprops={'color': 'black', 'linewidth': 0.8, 'linestyle': '-'},
                 showmeans=True, meanline=True, meanprops=dict(color='forestgreen', linewidth=1.6, linestyle='--'),
                 medianprops=dict(color='mediumorchid', linewidth=1.4, linestyle='-'))



ax.legend([bp1["boxes"][0], bp2["boxes"][0]], ['HSS ($L=0.6|D|$)', 'HO'], loc='upper left', fontsize=18)
plt.ylim(0.05, 1.05)
# plt.yscale('log')
plt.ylabel('$L_\\infty$ norm', fontsize=20)
ax.set_xticks([0.1, 0.9, 1.7, 2.53, 3.28]) # 设置刻度
KL_values = ['0.06', '0.15', '0.23', '0.30', '0.37']

ax.set_xticklabels(KL_values)  # 设置x轴刻度标签

ax.set_xlabel('Different KL divergence $\mathbb{D}_{\mathrm{KL}}$ \n $(d=1, \\sigma=0.6, |D|=2000, \\beta=1)$', fontsize=19, labelpad=12)


plt.tight_layout()
plt.savefig(f'../HSS_figures/Covariate_shift_boxplot_Linftynorm_dim{dim}_D2000_L06.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()




