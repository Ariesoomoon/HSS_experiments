
import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
config = {
    "font.family":'Times New Roman',
    "font.size": 16,
    "mathtext.fontset":'stix',
}
rcParams.update(config)
from matplotlib.patches import Patch
import numpy as np
import matplotlib.pyplot as plt
from math import pi

dim =3
trainsize = 1000
noise_var = 0.6
step_size = 3


categories = ['                 Accuracy     \n               (by $L_2$ norm)', 'Accuracy \n   (by $L_\\infty$ norm)\n', 'Efficiency          \n(by time)          ', '\nEfficiency \n(by MMU)']
data_ranges = {
    '                 Accuracy     \n               (by $L_2$ norm)': (0.1571, 0.245),
    'Accuracy \n   (by $L_\\infty$ norm)\n': (0.8633, 1.07),
    'Efficiency          \n(by time)          ': (15.98, 1700),
    '\nEfficiency \n(by MMU)': (0.54, 90)
}
#     '                 Accuracy     \n               (by $L_2$ norm)': (0.1571, 0.17),
#     'Accuracy \n   (by $L_\\infty$ Norm)\n': (0.8633, 1.1),
#     'Efficiency          \n(by time)          ': (87.01, 1800),
#     '\nEfficiency \n(by MMU)': (0.62, 100)
# }
#



algorithms = {
'HO': [0.1641, 0.9370, 15.98, 0.54],
'AIC': [0.1738, 1.0100, 110.76, 0.80],
'BIC': [0.2356, 1.0573, 109.75, 0.81],
    'BP': [0.1680, 1.0030, 1081.37, 53.38],
    'LP': [0.1631, 0.9624, 1543.62, 75.79],
    'ESR': [0.1632, 1.0001, 93.09, 1.03],
    'DP': [0.1617, 0.9307, 87.01, 0.62],
    'HSS': [0.1571, 0.8633, 108.17, 0.62],
}


# Normalize and reverse data for radar chart
normalized_data = {}
for algo, values in algorithms.items():
    normalized = []
    for i, value in enumerate(values):
        category = categories[i]
        min_val, max_val = data_ranges[category]
        # Reverse the normalization for efficiency metrics
        if category in ['Efficiency          \n(by time)          ', '\nEfficiency \n(by MMU)']:
            normalized_value = (max_val - value) / (max_val - min_val)
            print('max_val', max_val)
            print('normalized_value', normalized_value)
        else:
            normalized_value = 1 - (value - min_val) / (max_val - min_val)
            print(normalized_value)
        normalized.append(normalized_value)
    normalized_data[algo] = normalized

# Number of variables
N = len(categories)

# Compute angle for each axis
angles = [n / float(N) * 2 * pi for n in range(N)]
angles += angles[:1]  # Complete the loop

# Initialize radar chart
fig, ax = plt.subplots(figsize=(6, 6), subplot_kw=dict(polar=True))

# Draw one axis per variable and add labels
plt.xticks(angles[:-1], categories)

colors = {
    'HO': 'm',
    'AIC': 'dimgrey',
'BIC': 'dodgerblue',
    'BP': 'royalblue',
    'LP': 'teal',
    'ESR': 'rebeccapurple',
    'DP': 'orange',
    'HSS': 'brown',
}

# Plot each algorithm's performance
for algo, values in normalized_data.items():
    values += values[:1]  # Complete the loop
    ax.plot(angles, values, linewidth=1, linestyle='solid', label=algo, color=colors[algo])
    ax.fill(angles, values, alpha=0.1, color=colors[algo])

    for angle, value in zip(angles, values):
        ax.scatter([angle], [value], s=30, color=colors[algo], zorder=5)

# Customize the radar chart to have straight lines
ax.yaxis.grid(True)
ax.spines['polar'].set_visible(False)  # Hide the circular frame
ax.set_yticklabels([])


ax.legend(loc='lower center', bbox_to_anchor=(0.5, -0.45), ncol=4, frameon=False, prop={'size': 16})
ax.set_xlabel(f'Comparison of different methods \n $(d={dim}, \\sigma={noise_var}, |D|=1000, \\beta={step_size})$', fontsize='17', labelpad=60)

# Increase the bottom margin to prevent overlapping with labels
plt.subplots_adjust(bottom=0.4)

# Show plot
# plt.title('Algorithm Performance Radar Chart (Inverted Metrics)')
plt.tight_layout()  # Adjust layout to prevent clipping of labels
plt.savefig(f'../GPU_paper_use/Radar_Chart_dim{dim}_trainsize{trainsize}_all_new.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()

