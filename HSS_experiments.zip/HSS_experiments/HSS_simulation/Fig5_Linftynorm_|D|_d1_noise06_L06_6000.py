import os, time
import numpy as np
time_start = time.time()
from numpy import *
import matplotlib.pyplot as plt
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
config = {
    "font.family":'Times New Roman',
    "font.size": 17,
    "mathtext.fontset":'stix',
}
rcParams.update(config)



split_L_per = 0.6 # ⚠同时： ax.set_xlabel(f'Size of the training data $|D|$ \n $(d={dim}, \\sigma={noise_var}, \\beta={step_size}, L=0.8|D|$)', fontsize='18')
dim = 1
step_size = 1
'''  ⬆----------------------- 💎 需要手动改的地方 -----------------------------------------'''
noise_var = 0.6 # ⚠️ 当噪音为0.0的时候，stepsize是5（d=3）和1.4(d=1，用logscale)
split_L_tr_per = 0.7 # 固定不变
split_L_per_BS = 1.0  # ⚠️，不用这个参数，只是占个位置
sizes = [i for i in range(200, 6001, 200)]


filename_BSP = f'../HSS_result_data/GPU_KGD_result_10trials/HSS_6000_10trials_dim{dim}_noisevar{noise_var}_split_L_per{split_L_per}_stepsize{step_size}.npy'
BSP_result = np.load(filename_BSP, allow_pickle=True).item()
BSP_L2_norm_list_20trial = BSP_result['L2_norm_list_20trial'] # 观察哪些trial好-------
BSP_Linfinity_norm_list_20trial = BSP_result['Linfinity_norm_list_20trial'] # 观察哪些trial好-------
BSP_L2_norm_list_20trial_mean = BSP_result['L2_norm_list_20trial_mean']
BSP_Linfinity_norm_list_20trial_mean = BSP_result['Linfinity_norm_list_20trial_mean']



filename_BS = f'../HSS_result_data/GPU_KGD_result_10trials/BS_6000_10trials_dim{dim}_noisevar{noise_var}_split_L_per{split_L_per_BS}_stepsize{step_size}.npy'
BS_result = np.load(filename_BS, allow_pickle=True).item()
BS_L2_norm_list_20trial = BS_result['L2_norm_list_20trial'] # 观察哪些trial好
BS_Linfinity_norm_list_20trial = BS_result['Linfinity_norm_list_20trial'] # 观察哪些trial好
BS_L2_norm_list_20trial_mean = BS_result['L2_norm_list_20trial_mean']
BS_Linfinity_norm_list_20trial_mean = BS_result['Linfinity_norm_list_20trial_mean']



filename_HO = f'../HSS_result_data/GPU_KGD_result_10trials/HO_6000_10trials_dim{dim}_noisevar{noise_var}_split_L_per{split_L_per_BS}_stepsize{step_size}.npy'
HO_result = np.load(filename_HO, allow_pickle=True).item()
HO_L2_norm_list_20trial = HO_result['L2_norm_list_20trial'] # 观察哪些trial好
HO_Linfinity_norm_list_20trial = HO_result['Linfinity_norm_list_20trial'] # 观察哪些trial好
HO_L2_norm_list_20trial_mean = HO_result['L2_norm_list_20trial_mean']
HO_Linfinity_norm_list_20trial_mean = HO_result['Linfinity_norm_list_20trial_mean']



# (1) -------------  L2 norm, noise_var = 0.2, split_L_per = 1.0    -------------
fig = plt.figure(tight_layout=True)
gs = gridspec.GridSpec(1, 1)
ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.', axis="y")



ax.plot(sizes, BS_Linfinity_norm_list_20trial_mean, c='teal', marker='o',  linestyle='-', linewidth=1.2, markersize=5)
ax.plot(sizes, HO_Linfinity_norm_list_20trial_mean, c='darkorange', marker='^',  linestyle='-', linewidth=1.2, markersize=5)
ax.plot(sizes, BSP_Linfinity_norm_list_20trial_mean, c='brown', marker='s',  linestyle='-', linewidth=1.2, markersize=5)


# 添加阴影区
# ax.fill_between(sizes, [y for y in BS_L2_norm_list_20trial_mean], [y * (1+0.20) for y in BS_L2_norm_list_20trial_mean], color='teal', alpha=0.15)   # d=1
# ax.fill_between(sizes, [y for y in BS_L2_norm_list_20trial_mean], [y * (1+0.20) for y in BS_L2_norm_list_20trial_mean], color='teal', alpha=0.15) # d=3
# 添加箭头和文字
# arrowprops = dict(facecolor='royalblue', arrowstyle='->', color='royalblue')
# ax.annotate('BS\'s error add 0.003', xy=(680, BS_L2_norm_list_20trial_mean[5]+0.001), xytext=(400, 0.015),
#             arrowprops=arrowprops, fontsize=12, color='royalblue')
'''  ⬆----------------------- 💎 需要手动改的地方 -----------------------------------------'''

ax.set_xlabel(f'Size of the training data $|D|$ \n $(d={dim}, \\sigma={noise_var}, \\beta={step_size}, L={split_L_per}\\times|D|$)', fontsize='18')
# ax.set_ylabel('RMSE', fontsize='20')
ax.set_ylabel('$L_\\infty$ norm', fontsize='20')
# plt.yscale('log')
# plt.ylim(0.005, 0.9999)
plt.ylim(0.02, 0.45)
plt.legend(['BS', 'HO', 'HSS'], ncol=1, loc='upper right', fontsize='18')
# plt.xticks([500, 1000, 1500, 2000, 2400])
plt.savefig(f'../HSS_figures/6000_10trials_BS_HO_BSP_dim{dim}_noisevar{noise_var}_split_L_per{split_L_per}_stepsize{step_size}_infty.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()







# # 比较不同的trial中，各自选的t
# L2_t_list_20trial = HO_result['L2_t_list_20trial'][9]
# print('L2_t_list_20trial:', L2_t_list_20trial)
# L2_t_list_20trial = BS_result['L2_t_list_20trial'][9]
# print('L2_t_list_20trial:', L2_t_list_20trial)
# L2_C_20trial = BSP_result['L2_C_20trial'][1]
# L2_t_list_20trial = BSP_result['L2_t_list_20trial'][9]
# print('L2_t_list_20trial:', L2_t_list_20trial)
# print('L2_C_20trial:', L2_C_20trial)


