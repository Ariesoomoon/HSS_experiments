import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
config = {
    "font.family":'Times New Roman',
    "font.size": 17,
    "mathtext.fontset":'stix',
}
rcParams.update(config)


dim = 1
step_size = 1 # noise=0时用1.4
'''  ⬆----------------------- 💎 需要手动改的地方 -----------------------------------------'''
noise_var = 0.6 # 只有0.2和0.0的结果
split_L_tr_per = 0.7 # 固定不变
D_nums = [i for i in range(500, 6001, 500)]
train_size = 6000
split_L_per = 1

filename_BSP1 = f'../HSS_result_data/C_range/BSP_dim{dim}_noisevar{noise_var}_split_L_per{split_L_per}_stepsize{step_size}.npy'
BSP_result1 = np.load(filename_BSP1, allow_pickle=True).item()
L2_C_list = BSP_result1['L2_C_list']
L2_t_star_list = BSP_result1['L2_t_star_list']
Linfinity_C_list = BSP_result1['Linfinity_C_list']
Linfinity_t_star_list = BSP_result1['Linfinity_t_star_list']

fig = plt.figure(tight_layout=True)
fig = plt.figure(figsize=(6, 5), tight_layout=True)
gs = gridspec.GridSpec(1, 1)
ax = fig.add_subplot(gs[0, 0])
ax.grid(linestyle='-.', axis="y")
# ax.plot(D_nums[:-1], L2_C_list[:-1], c='brown', marker='d',  linestyle='-', linewidth=1.2, markersize=5)
# ax.plot(D_nums[:-1], Linfinity_C_list[:-1], c='teal', marker='s',  linestyle='-', linewidth=1.2, markersize=5)
# ax.scatter(D_nums[:-1], L2_C_list[:-1], c='brown', marker='d', s=50, label='$\hat{t}^*$ under $L_2$ norm')
# ax.scatter(D_nums[:-1], Linfinity_C_list[:-1], c='teal', marker='s', s=50, label='$\hat{t}^*$ under $L_\\infty$ norm')
ax.scatter(D_nums[:-1], L2_C_list[:-1], c='brown', marker='d', s=50, label='$\hat{t}^*$ under $L_2$ norm')
ax.scatter(D_nums[:-1], Linfinity_C_list[:-1], c='teal', marker='s', s=50, label='$\hat{t}^*$ under $L_\\infty$ norm')


ax.set_xlabel(f'Different data size $|D|$ \n $(d={dim}, \\sigma={noise_var}, \\beta={step_size}, \hat C_j\in(0.0, 12.0])$', fontsize='18')
ax.set_ylabel('Value of $\hat{C}_{j^*}$', fontsize='20')
# plt.yscale('log')
plt.ylim(-0.5, 10) # d=1, 0.6
plt.legend(['$\hat{C}_{j^*}$ under $L_2$ norm', '$\hat{C}_{j^*}$ under $L_\\infty$ norm'], ncol=1, loc='upper right', fontsize='18')
# plt.legend(['BS', 'HO', 'HSS'], ncol=1, loc='upper right', fontsize='16')
plt.savefig(f'../HSS_figures/C_range_DiffD_dim{dim}_noisevar{noise_var}_stepsize{step_size}.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()





# dim = 3
# step_size = 3 # noise=0时用1.4
# '''  ⬆----------------------- 💎 需要手动改的地方 -----------------------------------------'''
# noise_var = 0.6 # 只有0.2和0.0的结果
# split_L_tr_per = 0.7 # 固定不变
# D_nums = [i for i in range(500, 6001, 500)]
# train_size = 6000
# split_L_per = 1
#
#
# filename_BSP1 = f'../HSS_result_data/C_range/BSP_dim{dim}_noisevar{noise_var}_split_L_per{split_L_per}_stepsize{step_size}.npy'
# BSP_result1 = np.load(filename_BSP1, allow_pickle=True).item()
# L2_C_list = BSP_result1['L2_C_list']
# L2_t_star_list = BSP_result1['L2_t_star_list']
# Linfinity_C_list = BSP_result1['Linfinity_C_list']
# Linfinity_t_star_list = BSP_result1['Linfinity_t_star_list']
#
# fig = plt.figure(tight_layout=True)
# fig = plt.figure(figsize=(6, 5), tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.', axis="y")
# # ax.plot(D_nums[:-1], L2_C_list[:-1], c='brown', marker='d',  linestyle='-', linewidth=1.2, markersize=5)
# # ax.plot(D_nums[:-1], Linfinity_C_list[:-1], c='teal', marker='s',  linestyle='-', linewidth=1.2, markersize=5)
# ax.scatter(D_nums[:-1], L2_C_list[:-1], c='brown', marker='d', s=50, label='$\hat{t}^*$ under $L_2$ norm')
# ax.scatter(D_nums[:-1], Linfinity_C_list[:-1], c='teal', marker='s', s=50, label='$\hat{t}^*$ under $L_\\infty$ norm')
#
# ax.set_xlabel(f'Different data size $|D|$ \n $(d={dim}, \\sigma={noise_var}, \\beta={step_size}, \hat C_j\in(0.0, 12.0])$', fontsize='18')
# ax.set_ylabel('Value of $\hat{C}_{j^*}$', fontsize='20')
# # plt.yscale('log')
# plt.ylim(-0.5, 10) # d=1, 0.6
# plt.legend(['$\hat{C}_{j^*}$ under $L_2$ norm', '$\hat{C}_{j^*}$ under $L_\\infty$ norm'], ncol=1, loc='upper right', fontsize='18')
# # plt.legend(['BS', 'HO', 'HSS'], ncol=1, loc='upper right', fontsize='16')
# plt.savefig(f'../HSS_figures/C_range_DiffD_dim{dim}_noisevar{noise_var}_stepsize{step_size}.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()


