import time

time_start = time.time()
from numpy import *
import matplotlib.pyplot as plt
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
import matplotlib.ticker as ticker
config = {
    "font.family":'Times New Roman',
    "font.size": 18,
    "mathtext.fontset":'stix',
}
rcParams.update(config)



dim = 3 # np.random.seed(17), index1 = 0
step_size = 3
np.random.seed(49)


# dim = 1 # np.random.seed(49), index1 = 3
# step_size = 1
# np.random.seed(17)


noise_var = 0.6
train_size = 1000





# train, test = (train_size, dim), (200, dim)
# split_L_per = 1.0
# split_L = int(train_size * split_L_per)
#
# L2_t_star_list, L2_test_error_list, Linfinity_t_star_list, Linfinity_test_error_list = [],[],[],[]
# _, _, X_test, y_test = generate_data_noise02((300, dim), (500, dim), dim, noise_var)  # 保证 test只在不同的trial时有所不同
#
# '''--------------------------  noise_var = 0.6  --------------------------------------'''
# X_train, y_train, _, _ = generate_data_noise02(train, test, dim, noise_var)
# step_list, L2_error_list_noise02, Linfinity_error_list_noise02 = Baseline_plot(X_train, y_train, X_test, y_test, dim, split_L, step_size)
# X_train_noise0, y_train_noise0, _, _ = generate_data_noise0(train, test, dim, noise_var)
# _, L2_error_list_noise0, Linfinity_error_list_noise0 = Baseline_plot(X_train_noise0, y_train_noise0, X_test, y_test, dim, split_L, step_size)
#
# KGD_result = {
#     'step_list': step_list,
#     'L2_error_list_noise02': L2_error_list_noise02,
#     'Linfinity_error_list_noise02': Linfinity_error_list_noise02,
#     'L2_error_list_noise0': L2_error_list_noise0,
#     'Linfinity_error_list_noise0': Linfinity_error_list_noise0
# }
#
#
# filename = f'../KGD_result_data/BS_bias_var_tradeoff_dim{dim}_noisevar{noise_var}_stepsize{step_size}.npy'
# np.save(filename, KGD_result)
# print(f'save result file: BS_dim{dim}_noisevar{noise_var}_stepsize{step_size}')
# print(KGD_result.keys())


filename = f'../HSS_result_data/BS_bias_var_tradeoff_dim{dim}_noisevar{noise_var}_stepsize{step_size}.npy'
BS_result = np.load(filename, allow_pickle=True).item()
print(BS_result.keys())
# dict_keys(['step_list', 'L2_error_list_noise02', 'Linfinity_error_list_noise02', 'L2_error_list_noise0', 'Linfinity_error_list_noise0'])
sizes = BS_result['step_list']
L2_noise02 = BS_result['L2_error_list_noise02']
L2_noise0 = BS_result['L2_error_list_noise0']
L2_noise02 = np.array(L2_noise02) ** 2
bias = np.array(L2_noise0) ** 2
print(np.array(L2_noise02).shape)
print(np.array(bias).shape)
variance = np.array(L2_noise02) - np.array(bias)
# fig = plt.figure(tight_layout=True)
fig = plt.figure(figsize=(6, 5), tight_layout=True)
gs = gridspec.GridSpec(1, 1)
ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.', axis="y")
# ax.plot(sizes, L2_noise02, c='brown',  linestyle='-', linewidth=1.2, label='$L_2$ norm of KGD')
# ax.plot(sizes, bias, c='darkorange', linestyle='-', linewidth=1.2, label='Bias')
# ax.plot(sizes, variance, c='teal', linestyle='-', linewidth=1.2, label='Variance')
index1 = 4
ax.plot(sizes[index1:], L2_noise02[index1:], c='brown',  linestyle='-', linewidth=1.2, label='Total error')
ax.plot(sizes[index1:], bias[index1:], c='darkorange', linestyle='-', linewidth=1.2, label='Bias (error on noise-free data)')
ax.plot(sizes[index1:], variance[index1:], c='teal', linestyle='-', linewidth=1.2, label='Variance (Total error $-$ Bias)')


plt.ylabel('$L_2$ norm', fontsize=19)
# ax.set_xlabel('Number of iterations \n($d=1, \\sigma=0.6, |D|=1000, \\beta=1$)', fontsize='18')
ax.set_xlabel('Number of iterations \n($d=3, \\sigma=0.6, |D|=1000, \\beta=3$)', fontsize='18')
# plt.yscale('log')


# ax.set_xlabel('Number of iterations \n($d=3, \\sigma=0.6, |D|=1000, \\beta=3$)', fontsize='18')
# plt.ylim(0.0, 0.09) # d=3
ax.yaxis.set_major_formatter(ticker.FormatStrFormatter('%.4f'))
ax.legend(ncol=1, loc='upper right', fontsize='17')
plt.savefig(f'../HSS_figures/BS_bias_variance_dim{dim}_size{train_size}_step_size{step_size}_L2.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()











