import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
config = {
    "font.family":'Times New Roman',
    "font.size": 18,
    "mathtext.fontset":'stix',
}
rcParams.update(config)


dim = 1
step_size = 1 # noise=0时用1.4
train_size = 2000
'''  ⬆----------------------- 💎 需要手动改的地方 -----------------------------------------'''
noise_var = 0.6 # 只有0.2和0.0的结果
split_L_tr_per = 0.7 # 固定不变
split_L_per_BS = 1.0  # ⚠️，不用这个参数，只是占个位置
split_L_per = 1
mu_x3 = 0.0
sigma_x3_list = [1.1, 1.2, 1.3, 1.4, 1.5]


'''--------------------- 1000 原始数据----------------------'''
# BS:
BS_l2norm_ori = 0.028311470099089724
BS_linftynorm_ori = 0.07214887740526248
# HSS:
# L=1
# HSS_l2norm_ori = 0.03752570955416399
# HSS_linftynorm_ori = 0.09975039710030101

# L=0.6
HSS_l2norm_ori = 0.0397294766567961
HSS_linftynorm_ori = 0.10421282591604271


filename_HSS_ori = f'../HSS_result_data/20_trials_result/HSS_trainsize2000_dim1_split_L_per0.6_mu0.0_covarite_shift_range02_ori.npy' # 这里保存名字应该是01，数据是对的
HSS_result = np.load(filename_HSS_ori, allow_pickle=True).item()
HSS_l2norm_ori = HSS_result['L2_norm_list_20trial_mean']
HSS_linftynorm_ori = HSS_result['Linfinity_norm_list_20trial_mean']
HSS_l2norm_ori = HSS_l2norm_ori[0]
HSS_linftynorm_ori = HSS_linftynorm_ori[0]
print(HSS_l2norm_ori)
print(HSS_linftynorm_ori)

# HO:
HO_l2norm_ori = 0.0353512794511399
HO_linftynorm_ori = 0.18939779960099293




'''--------------------- 1000 KL 不同时的数据， 其中HSS， L=0.6, range(0,1) ----------------------'''

filename_BS = f'../HSS_result_data/20_trials_result/BS_trainsize{train_size}_dim{dim}_split_L_per{split_L_per}_mu{mu_x3}_covarite_shift.npy'
BS_result = np.load(filename_BS, allow_pickle=True).item()
BS_l2norm = BS_result['Linfinity_norm_list_20trial_mean']

filename_HO = f'../HSS_result_data/20_trials_result/HO_trainsize{train_size}_dim{dim}_split_L_per{split_L_per}_mu{mu_x3}_covarite_shift.npy'
HO_result = np.load(filename_HO, allow_pickle=True).item()
HO_l2norm = HO_result['Linfinity_norm_list_20trial_mean']

filename_HSS = f'../HSS_result_data/20_trials_result/HSS_trainsize2000_dim1_split_L_per0.6_mu0.0_covarite_shift_range02.npy'
HSS_result = np.load(filename_HSS, allow_pickle=True).item()
HSS_l2norm = HSS_result['Linfinity_norm_list_20trial_mean']
KL_values = HSS_result['distance_KL_list_mean_20trial']
print('KL_values', KL_values)


BS_diff = [abs(x - BS_l2norm_ori) * 100 for x in BS_l2norm]
HO_diff = [abs(x - HO_l2norm_ori) * 100 for x in HO_l2norm]
HSS_diff = [abs(x - HSS_l2norm_ori)* 100  for x in HSS_l2norm]

print('BS', BS_l2norm)
print('HO', HO_l2norm)
print('HSS', HSS_l2norm)
print('BS_diff', BS_diff)
print('HO_diff', HO_diff)
print('HSS_diff', HSS_diff)



# 设置柱状图的位置
x = np.arange(len(HO_diff))
width = 0.35

# 绘制柱状图
fig, ax = plt.subplots()
bars1 = ax.bar(x - width/2, HSS_diff, width, label='HSS ($L=0.6|D|$)', color='brown', alpha=0.8)
bars2 = ax.bar(x + width/2, HO_diff, width, label='HO', color='darkorange', alpha=0.8)

# KL_values [0.05971811458278049, 0.1461528295253031, 0.22889273750541722, 0.3044190872043554, 0.3748230875368379]
KL_values = ['$\mathbb{D}_{\mathrm{KL}}$=0.06', '$\mathbb{D}_{\mathrm{KL}}$=0.15', '$\mathbb{D}_{\mathrm{KL}}$=0.23', '$\mathbb{D}_{\mathrm{KL}}$=0.30', '$\mathbb{D}_{\mathrm{KL}}$=0.37']
ax.set_xlabel('Different KL divergence ($\mathbb{D}_{\mathrm{KL}}$) \n $(d=1, \\sigma=0.6, |D|=2000, \\beta=1)$', fontsize=20, labelpad=15)
ax.set_ylabel('$\\Delta$ $L_\\infty$ norm (%)', fontsize=20)
ax.set_xticks([r  for r in range(len(KL_values))])
ax.set_xticklabels([f'{p}' for p in KL_values], fontsize='15')
# ax.set_xticklabels([f'{p}' for p in KL_values], fontsize='16', rotation=40, ha='right')


plt.ylim(0.0, 70) # d=3
ax.legend(ncol=1, loc='upper left', fontsize='18')

# 显示图形
plt.tight_layout()
plt.savefig(f'../HSS_figures/Covariate_shift_Linftynorm_dim{dim}_D2000_L06_Crange02.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()
