import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
config = {
    "font.family":'Times New Roman',
    "font.size": 18,
    "mathtext.fontset":'stix',
}
rcParams.update(config)


dim = 1
step_size = 1 # noise=0时用1.4
train_size = 2000
'''  ⬆----------------------- 💎 需要手动改的地方 -----------------------------------------'''
noise_var = 0.6 # 只有0.2和0.0的结果
split_L_tr_per = 0.7 # 固定不变
split_L_per_BS = 1.0  # ⚠️，不用这个参数，只是占个位置
split_L_per = 1
mu_x3 = 0.0
sigma_x3_list = [1.1, 1.2, 1.3, 1.4, 1.5]



'''--------------------- 1000 KL 不同时的数据， 其中HSS， L=0.6, range(0,1) ----------------------'''


filename_HSS = f'../HSS_result_data/GPU_KGD_result_10trials/covariate_shift_result/HSS_trainsize{train_size}_dim1_split_L_per1_mu0.0_covarite_shift.npy' #
HSS_result = np.load(filename_HSS, allow_pickle=True).item()
HSS_l2norm_L1 = HSS_result['Linfinity_norm_list_20trial_mean']
KL_values = HSS_result['distance_KL_list_mean_20trial']
print('HSS_l2norm_L1', HSS_l2norm_L1)

filename_HSS = f'../HSS_result_data/GPU_KGD_result_10trials/covariate_shift_result/HSS_trainsize{train_size}_dim1_split_L_per0.8_mu0.0_covarite_shift.npy'
HSS_result = np.load(filename_HSS, allow_pickle=True).item()
HSS_l2norm_L06 = HSS_result['Linfinity_norm_list_20trial_mean']
KL_values = HSS_result['distance_KL_list_mean_20trial']
print('KL_values', KL_values)
print('HSS_l2norm_L06', HSS_l2norm_L06)


filename_HSS = f'../HSS_result_data/GPU_KGD_result_10trials/covariate_shift_result/HSS_trainsize{train_size}_dim1_split_L_per0.5_mu0.0_covarite_shift.npy'#
HSS_result = np.load(filename_HSS, allow_pickle=True).item()
HSS_l2norm_L04 = HSS_result['Linfinity_norm_list_20trial_mean']
KL_values = HSS_result['distance_KL_list_mean_20trial']
print('KL_values', KL_values)
print('HSS_l2norm_L06', HSS_l2norm_L04)
# KL_values [0.05971811458278049, 0.1461528295253031, 0.22889273750541722, 0.3044190872043554, 0.3748230875368379]


filename_HSS = f'../HSS_result_data/GPU_KGD_result_10trials/covariate_shift_result/HSS_trainsize{train_size}_dim1_split_L_per0.6_mu0.0_covarite_shift.npy'
HSS_result = np.load(filename_HSS, allow_pickle=True).item()
HSS_l2norm = HSS_result['Linfinity_norm_list_20trial_mean']
KL_values = HSS_result['distance_KL_list_mean_20trial']
print('KL_values', KL_values)
# KL_values [0.06316207729311171, 0.14840158079424323, 0.23136662572973776, 0.30701561403757444, 0.3763757654387847]





KL_values = ['$\mathbb{D}_{\mathrm{KL}}$=0.06', '$\mathbb{D}_{\mathrm{KL}}$=0.15', '$\mathbb{D}_{\mathrm{KL}}$=0.23', '$\mathbb{D}_{\mathrm{KL}}$=0.30', '$\mathbb{D}_{\mathrm{KL}}$=0.37']

methods = ['HSS ($L=|D|$)', 'HSS ($L=0.8|D|$)', 'HSS ($L=0.5|D|$)']
num_params = 5
width = 0.14  # 柱子宽度
x = np.arange(len(methods))  # 方法的x位置
# 定义颜色列表
colors = ['peachpuff', 'peru', 'sandybrown','chocolate', 'sienna']
colors = ['slategrey', 'cornflowerblue', 'royalblue','mediumslateblue', 'rebeccapurple']
colors = ['rosybrown', 'lightcoral', 'indianred','brown', 'darkred']

# 绘制柱状图
fig, ax = plt.subplots(figsize=(8, 6))
# ax.grid(color='brown', linestyle='-.', axis="y")
# 依次绘制每个方法的五个柱子
for i in range(num_params):
    ax.bar(x - width + i * width,
           [HSS_l2norm_L1[i], HSS_l2norm_L06[i], HSS_l2norm_L04[i]],
           width,
           color=colors[i],  # 设置颜色
           label=KL_values[i])  # 这里可以设置图例标签
    ax.axhline(y=HSS_l2norm_L04[i], color=colors[i], linestyle='-.', linewidth=0.9)


# 设置X轴标签
ax.set_xticks([r + 0.15 for r in range(len(methods))])
ax.set_xticklabels([f'{p}' for p in methods], fontsize='17')

# ax.set_xticks(x)
# ax.set_xticklabels(methods, fontsize=15)

# 设置Y轴标签
ax.set_ylabel('$L_\\infty$ norm', fontsize=20)

# 设置图例
ax.legend(ncol=3, loc='upper left', fontsize='17')
ax.set_xlabel('HSS with diverse $L$ \n $(d=1, \\sigma=0.6, |D|=2000, \\beta=1)$', fontsize=19, labelpad=15)
# ax.set_ylabel('$L_2$ norm', fontsize=20)
# 设置y轴的范围

plt.yscale('log')
plt.ylim(0.0, 1)
# 显示图形
plt.tight_layout()
plt.savefig(f'../HSS_figures/Covariate_shift_Linftynorm_dim{dim}_D2000_L10_L08_L05.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()
