import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
config = {
    "font.family":'Times New Roman',
    "font.size": 17,
    "mathtext.fontset":'stix',
}
rcParams.update(config)



dim = 1
step_size = 1 # noise=0时用1.4
'''  ⬆----------------------- 💎 需要手动改的地方 -----------------------------------------
是按照二分法选参时候，1trial的时间记录

'''
noise_var = 0.6 # 只有0.2和0.0的结果
split_L_tr_per = 0.7 # 固定不变
split_L_per_BS = 1.0  # ⚠️，不用这个参数，只是占个位置
L_nums = [i for i in range(200, 4001, 200)]
train_size = 1000
split_L_list = [100, 200, 400, 600, 800, 1000, 1200, 1400, 1600, 1800, 2000]


time_d1 = [2.312382936477661, 2.1595168113708496, 2.2246758937835693, 2.6743969917297363, 2.481476068496704, 2.860038995742798, 2.910554885864258, 3.7467100620269775, 3.7170424461364746, 3.8440327644348145, 4.638488531112671]
fig = plt.figure(tight_layout=True)
fig = plt.figure(figsize=(6, 5), tight_layout=True)
gs = gridspec.GridSpec(1, 1)
ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.', axis="y")
ax.plot(split_L_list, time_d1, c='royalblue', marker='d',  linestyle='-', linewidth=1.2, markersize=5)

# 在x=2400处添加蓝色星星标记
x_value = 1200
y_value = time_d1[split_L_list.index(x_value)]
ax.scatter(x_value, y_value, color='blue', marker='*', s=100, label='Marked Point', zorder=2)

ax.set_xlabel(f'Different $L$ in HSS\n $(d={dim}, \\sigma={noise_var}, |D|=2000, \\beta={step_size})$', fontsize='18')
ax.set_ylabel('Time (s) of HSS in one trial', fontsize='20')
plt.savefig(f'../HSS_figures/DiffL_dim{dim}_time_2000.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()




# dim = 3
# step_size = 3 # noise=0时用1.4
# '''  ⬆----------------------- 💎 需要手动改的地方 -----------------------------------------
# 是按照二分法选参时候，1trial的时间记录
#
# '''
# noise_var = 0.6 # 只有0.2和0.0的结果
# split_L_tr_per = 0.7 # 固定不变
# split_L_per_BS = 1.0  # ⚠️，不用这个参数，只是占个位置
# L_nums = [i for i in range(200, 4001, 200)]
# train_size = 1000
# split_L_list = [100, 200, 400, 600, 800, 1000, 1200, 1400, 1600, 1800, 2000]
#
#
# time_d1 = [11.727832317352295, 13.059061527252197, 15.548508644104004, 19.824949502944946, 25.874509811401367, 33.68230891227722, 43.679368019104004, 56.202922344207764, 69.0097165107727, 87.01847243309021, 107.43958592414856]
# fig = plt.figure(tight_layout=True)
# fig = plt.figure(figsize=(6, 5), tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# # ax.grid(linestyle='-.', axis="y")
# ax.plot(split_L_list, time_d1, c='royalblue', marker='d',  linestyle='-', linewidth=1.2, markersize=5)
#
# # 在x=2400处添加蓝色星星标记
# x_value = 1200
# y_value = time_d1[split_L_list.index(x_value)]
# ax.scatter(x_value, y_value, color='blue', marker='*', s=100, label='Marked Point', zorder=2)
#
# ax.set_xlabel(f'Different $L$ in HSS\n $(d={dim}, \\sigma={noise_var}, |D|=2000, \\beta={step_size})$', fontsize='18')
# ax.set_ylabel('Time (s) of HSS in one trial', fontsize='20')
# plt.savefig(f'../HSS_figures/DiffL_dim{dim}_time_2000.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()
