import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
config = {
    "font.family":'Times New Roman',
    "font.size": 17,
    "mathtext.fontset":'stix',
}
rcParams.update(config)


# dim = 1
# step_size = 1 # noise=0时用1.4
# '''  ⬆----------------------- 💎 需要手动改的地方 -----------------------------------------'''
# noise_var = 0.6 # 只有0.2和0.0的结果
# split_L_tr_per = 0.7 # 固定不变
# D_nums = [i for i in range(500, 6001, 500)]
# train_size = 6000
# split_L_per = 1
#
# filename = f'../HSS_result_data/C_range/BS_dim{dim}_noisevar{noise_var}_split_L_per{split_L_per}_stepsize{step_size}.npy'
# BS_result1 = np.load(filename, allow_pickle=True).item()
# L2_t_star_list = BS_result1['L2_t_star_list']
# Linfinity_t_star_list = BS_result1['Linfinity_t_star_list']
# print(L2_t_star_list)
# print(Linfinity_t_star_list)
#
# fig = plt.figure(tight_layout=True)
# fig = plt.figure(figsize=(6, 5), tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.', axis="y")
#
# ax.scatter(D_nums[:-1], L2_t_star_list[:-1], c='brown', marker='d', s=50, label='$\hat{t}^*$ under $L_2$ norm')
# ax.scatter(D_nums[:-1], Linfinity_t_star_list[:-1], c='teal', marker='s', s=50, label='$\hat{t}^*$ under $L_\\infty$ norm')
# # [141, 145, 95, 275, 215, 113, 135, 133, 434, 180, 157, 160]
# # [190, 331, 128, 451, 556, 156, 189, 187, 668, 187, 235, 193]
#
# ax.set_xlabel(f'Different data size $|D|$ \n $(d={dim}, \\sigma={noise_var}, \\beta={step_size}, t\in[1, |D|])$', fontsize='18')
# ax.set_ylabel('Value of $\hat{t}^*$', fontsize='20')
# # plt.yscale('log')
# plt.ylim(0, 1200) # d=3
# plt.legend(['$\hat{t}^*$ under $L_2$ norm', '$\hat{t}^*$ under $L_\\infty$ norm'], ncol=1, loc='upper right', fontsize='18')
# # plt.legend(['BS', 'HO', 'HSS'], ncol=1, loc='upper right', fontsize='16')
# plt.savefig(f'../HSS_figures/t_range_DiffD_dim{dim}_noisevar{noise_var}_stepsize{step_size}.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()





dim = 3
step_size = 3 # noise=0时用1.4
'''  ⬆----------------------- 💎 需要手动改的地方 -----------------------------------------'''
noise_var = 0.6 # 只有0.2和0.0的结果
split_L_tr_per = 0.7 # 固定不变
D_nums = [i for i in range(500, 6001, 500)]
train_size = 6000
split_L_per = 1

filename = f'../HSS_result_data/C_range/BS_dim{dim}_noisevar{noise_var}_split_L_per{split_L_per}_stepsize{step_size}.npy'
BS_result1 = np.load(filename, allow_pickle=True).item()
L2_t_star_list = BS_result1['L2_t_star_list']
Linfinity_t_star_list = BS_result1['Linfinity_t_star_list']
print(L2_t_star_list)
print(Linfinity_t_star_list)

fig = plt.figure(tight_layout=True)
fig = plt.figure(figsize=(6, 5), tight_layout=True)
gs = gridspec.GridSpec(1, 1)
ax = fig.add_subplot(gs[0, 0])
ax.grid(linestyle='-.', axis="y")

ax.scatter(D_nums[:-1], L2_t_star_list[:-1], c='brown', marker='d', s=50, label='$\hat{t}^*$ under $L_2$ norm')
ax.scatter(D_nums[:-1], Linfinity_t_star_list[:-1], c='teal', marker='s', s=50, label='$\hat{t}^*$ under $L_\\infty$ norm')
# [141, 145, 95, 275, 215, 113, 135, 133, 434, 180, 157, 160]
# [190, 331, 128, 451, 556, 156, 189, 187, 668, 187, 235, 193]


ax.set_xlabel(f'Different data size $|D|$ \n $(d={dim}, \\sigma={noise_var}, \\beta={step_size}, t\in[1, |D|])$', fontsize='18')
ax.set_ylabel('Value of $\hat{t}^*$', fontsize='20')
plt.ylim(0, 800) # d=3
plt.legend(['$\hat{t}^*$ under $L_2$ norm', '$\hat{t}^*$ under $L_\\infty$ norm'], ncol=1, loc='upper right', fontsize='18')
# plt.legend(['BS', 'HO', 'HSS'], ncol=1, loc='upper right', fontsize='16')
plt.savefig(f'../HSS_figures/t_range_DiffD_dim{dim}_noisevar{noise_var}_stepsize{step_size}.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()

