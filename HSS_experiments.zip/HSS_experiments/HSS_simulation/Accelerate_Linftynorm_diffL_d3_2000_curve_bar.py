import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
config = {
    "font.family":'Times New Roman',
    "font.size": 17,
    "mathtext.fontset":'stix',
}
rcParams.update(config)


dim = 3
step_size = 3 # noise=0时用1.4
'''  ⬆----------------------- 💎 需要手动改的地方 -----------------------------------------'''
noise_var = 0.6 # 只有0.2和0.0的结果
split_L_tr_per = 0.7 # 固定不变
split_L_per_BS = 1.0  # ⚠️，不用这个参数，只是占个位置
train_size = 2000
split_L_list = [100, 200, 400, 600, 800, 1000, 1200, 1400,1600, 1800, 2000]
# split_L_list = [1500, 1800, 2100, 2400, 2700, 3000, 3300]


fig = plt.figure(tight_layout=True)
fig = plt.figure(figsize=(6, 5), tight_layout=True)
gs = gridspec.GridSpec(1, 1)
ax = fig.add_subplot(gs[0, 0])



filename_BS = f'../HSS_result_data/GPU_KGD_result_10trials/BS_6000_10trials_dim{dim}_noisevar{noise_var}_split_L_per{split_L_per_BS}_stepsize{step_size}.npy'
BS_result = np.load(filename_BS, allow_pickle=True).item()
BS_L2_norm_list_20trial = BS_result['L2_norm_list_20trial'] # 观察哪些trial好
BS_Linfinity_norm_list_20trial = BS_result['Linfinity_norm_list_20trial'] # 观察哪些trial好
BS_L2_norm_list_20trial_mean = BS_result['L2_norm_list_20trial_mean']
BS_Linfinity_norm_list_20trial_mean = BS_result['Linfinity_norm_list_20trial_mean']

filename_HO = f'../HSS_result_data/GPU_KGD_result_10trials/HO_6000_10trials_dim{dim}_noisevar{noise_var}_split_L_per{split_L_per_BS}_stepsize{step_size}.npy'
HO_result = np.load(filename_HO, allow_pickle=True).item()
HO_L2_norm_list_20trial = HO_result['L2_norm_list_20trial'] # 观察哪些trial好
HO_Linfinity_norm_list_20trial = HO_result['Linfinity_norm_list_20trial'] # 观察哪些trial好
HO_L2_norm_list_20trial_mean = HO_result['L2_norm_list_20trial_mean']
HO_Linfinity_norm_list_20trial_mean = HO_result['Linfinity_norm_list_20trial_mean']

# L1200_D2000
HO_L2norm_D2000 = HO_Linfinity_norm_list_20trial_mean[9]
BS_L2norm_D2000 = BS_Linfinity_norm_list_20trial_mean[9]



filename_BSP04 = f'../HSS_result_data/GPU_KGD_result_10trials/BSP_dim3_noisevar0.6_fixedD2000_diffL_stepsize3_new_flat_range04.npy'
BSP_result04 = np.load(filename_BSP04, allow_pickle=True).item()
HSS_range04 = BSP_result04['Linfinity_norm_list_20trial_mean']

filename_BSP03 = f'../HSS_result_data/GPU_KGD_result_10trials/BSP_dim3_noisevar0.6_fixedD2000_diffL_stepsize3_new_flat_range03.npy'
BSP_result03 = np.load(filename_BSP03, allow_pickle=True).item()
HSS_range03 = BSP_result03['Linfinity_norm_list_20trial_mean']

filename_BSP02 = f'../HSS_result_data/GPU_KGD_result_10trials/BSP_dim3_noisevar0.6_fixedD2000_diffL_stepsize3_new_flat_range02.npy'
BSP_result02 = np.load(filename_BSP02, allow_pickle=True).item()
HSS_range02 = BSP_result02['Linfinity_norm_list_20trial_mean']
print(HSS_range02)

filename_BSP01 = f'../HSS_result_data/GPU_KGD_result_10trials/BSP_dim3_noisevar0.6_fixedD2000_diffL_stepsize3_new_flat_range01.npy'
BSP_result01 = np.load(filename_BSP01, allow_pickle=True).item()
HSS_range01 = BSP_result01['Linfinity_norm_list_20trial_mean']


# print(HSS_range01)
# print(HSS_range02)
# print(HSS_range03)
# print(HSS_range04)



# # HSS_select1 = HSS_range04[:2] + HSS_range02[2:6] + HSS_range01[6:]
HSS_select = HSS_range04[:2] + HSS_range03[2:4] + HSS_range01[4:]

# ax.plot(split_L_list, HSS_range01, c='teal', marker='d',  linestyle='-', linewidth=1.2, markersize=5)
# ax.plot(split_L_list, HSS_range02, c='black', marker='d',  linestyle='-', linewidth=1.2, markersize=5)
# ax.plot(split_L_list, HSS_range03, c='darkorange', marker='d',  linestyle='-', linewidth=1.2, markersize=5)
# ax.plot(split_L_list, HSS_range04, c='brown', marker='d',  linestyle='-', linewidth=1.2, markersize=5)

# ax.plot(split_L_list, [BS_L2norm_D2000]*11, c='teal', marker='d',  linestyle='-', linewidth=1.2, markersize=5)
# ax.plot(split_L_list, [HO_L2norm_D2000]*11, c='darkorange', marker='d',  linestyle='-', linewidth=1.2, markersize=5)
# ax.plot(split_L_list, HSS_select1, c='brown', marker='d',  linestyle='--', linewidth=1.2, markersize=5)
ax.plot(split_L_list, HSS_select, c='brown', marker='d',  linestyle='-', linewidth=1.2, markersize=5)

# 在x=2400处添加蓝色星星标记
x_value = 1200
y_value = HSS_select[split_L_list.index(x_value)]
ax.scatter(x_value, y_value, color='blue', marker='*', s=100, label='Marked Point', zorder=2)


ax.set_xlabel(f'Different $L$ in HSS\n $(d={dim}, \\sigma={noise_var}, |D|=2000, \\beta={step_size})$', fontsize='18')
ax.set_ylabel('$L_\\infty$ norm', fontsize='20')
# plt.yscale('log')
# plt.ylim(0.015, 0.11) # d=1, 0.6
# plt.ylim(0.01, 0.13)
plt.ylim(0.6, 1.2)
# plt.legend(['HSS'], ncol=1, loc='upper right', fontsize='18')
# plt.legend(['BS', 'HO', 'HSS'], ncol=1, loc='upper right', fontsize='18')
# plt.legend(['HSS'], ncol=1, loc='upper right', fontsize='18')
# plt.legend(['BS', 'HO', 'HSS'], ncol=1, loc='upper right', fontsize='16')
plt.savefig(f'../HSS_figures/DiffL_Linftynorm_dim{dim}_2000.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()




#
# '''=============================  画柱状图  ============================= '''
# config = {
#     "font.family":'Times New Roman',
#     "font.size": 23,
#     "mathtext.fontset":'stix',
# }
# rcParams.update(config)
# L_values = [800, 1200, 1400]
# BS = [BS_L2norm_D2000, BS_L2norm_D2000, BS_L2norm_D2000]
# BSP = [HSS_select[4], HSS_select[6], HSS_select[7]] # 对应L=600， 700， 800
# HO = [HO_L2norm_D2000, HO_L2norm_D2000, HO_L2norm_D2000]
#
#
# # fig = plt.figure(tight_layout=True)
# fig = plt.figure(figsize=(6, 5), tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# fig, ax = plt.subplots(figsize=(8, 7.5))
# bar_width = 0.2
# r1 = np.arange(len(L_values))
# r2 = [x + bar_width for x in r1]
# r3 = [x + bar_width for x in r2]
#
# ax.bar(r1, BS, width=bar_width, color='teal', edgecolor='teal', label='BS', alpha=0.8)
# ax.bar(r2, BSP, width=bar_width, color='brown', edgecolor='brown', label='BSP', alpha=0.8)
# ax.bar(r3, HO, width=bar_width, color='darkorange', edgecolor='darkorange', label='HO', alpha=0.8)
#
# ax.set_xticks([r + bar_width for r in range(len(L_values))])
# ax.set_xticklabels([f'{p}' for p in L_values])
# ax.set_ylabel('$L_\\infty$ norm', fontsize='28')
# ax.set_xlabel(f'Different $L$ in HSS \n $(d={dim}, \\sigma={noise_var}, |D|=2000, \\beta={step_size})$', fontsize='26')
#
# # plt.yscale('log')
# # plt.ylim(0.0, 0.08) # d=1
# plt.ylim(0.0, 1.4) # d=3
# '''  ⬆----------------------- 💎 需要手动改的地方 -----------------------------------------'''
# # 调整布局避免轴标签被剪切
# ax.legend(['BS', 'HSS', 'HO'], ncol=1, loc='upper right', fontsize='20')
# # plt.legend(['BS', 'HO', 'BSP'], ncol=1, loc='upper right', fontsize='16')
# plt.tight_layout()
# plt.savefig(f'../HSS_figures/DiffL_Linftynorm_dim{dim}_2000_bar.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()



