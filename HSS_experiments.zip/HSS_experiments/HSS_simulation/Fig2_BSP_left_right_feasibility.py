import time
from Main_functions.KGD_algorithm_by_Backward_Selection_Principle_L2_infinity_norm import generate_data, BSP_left_right_calculation

time_start = time.time()
from numpy import *
import matplotlib.pyplot as plt
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
import matplotlib.ticker as ticker
config = {
    "font.family":'Times New Roman',
    "font.size": 17,
    "mathtext.fontset":'stix',
}
rcParams.update(config)
time_start = time.time()



np.random.seed(77) # d=3
dim = 3
step_size = 3
C_bsp_1, C_bsp_2, C_bsp_3 = 0.52, 0.6, 0.7 # d=3


# np.random.seed(60) # d=1
# dim = 1
# step_size = 1
# C_bsp_1, C_bsp_2, C_bsp_3 = 0.25, 0.3, 0.4 # d=1



noise_var = 0.6
train_size = 1000
total_steps = train_size
train, test = (train_size, dim), (200, dim)
_, _, X_test, y_test = generate_data((300, dim), (500, dim), dim, noise_var)  # 保证 test只在不同的trial时有所不同
X_train, y_train, _, _ = generate_data(train, test, dim, noise_var)
BSP_left_list, BSP_right_W = BSP_left_right_calculation(X_train, y_train, dim, total_steps, step_size)
BSP_right_list_1 = C_bsp_1 * BSP_right_W
BSP_right_list_2 = C_bsp_2 * BSP_right_W
BSP_right_list_3 = C_bsp_3 * BSP_right_W

KGD_result = {
    'BSP_left_list': BSP_left_list,
    'BSP_right_list_1': BSP_right_list_1,
    'BSP_right_list_2': BSP_right_list_2,
    'BSP_right_list_3': BSP_right_list_3}
filename = f'../HSS_result_data/BSP_left_right_dim{dim}_noisevar{noise_var}_stepsize{step_size}.npy'
np.save(filename, KGD_result)
print(KGD_result.keys())




filename = f'../HSS_result_data/BSP_left_right_dim{dim}_noisevar{noise_var}_stepsize{step_size}.npy'
BSP_result = np.load(filename, allow_pickle=True).item()
sizes = [i for i in range(1, 1001, 1)]     # m = 5,10, ..., 350
# fig = plt.figure(tight_layout=True)
fig = plt.figure(figsize=(6, 5), tight_layout=True)
gs = gridspec.GridSpec(1, 1)
ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.', axis="y")


# d=3
index=0
ax.plot(sizes[index:], BSP_result['BSP_left_list'][index:], c='brown',  linestyle='-', linewidth=1.3, label=r'$t||f_{t+1,\beta,D}-f_{t,\beta,D}||_{D}+t^{1/2}||f_{t+1,\beta,D}-f_{t,\beta,D}||_{K}$')
ax.plot(sizes[index:], BSP_result['BSP_right_list_1'][index:], c='purple', linestyle='--', linewidth=1.3, label=r'$\tilde{C_1}\mathcal{W}_{D, {t}} \quad (\tilde{C_1}=0.52)$')
ax.plot(sizes[index:], BSP_result['BSP_right_list_2'][index:], c='royalblue', linestyle='--', linewidth=1.3, label=r'$\tilde{C_2}\mathcal{W}_{D, {t}} \quad (\tilde{C_2}=0.6)$')
ax.plot(sizes[index:], BSP_result['BSP_right_list_3'][index:], c='green', linestyle='--', linewidth=1.3, label=r'$\tilde{C_3}\mathcal{W}_{D, {t}} \quad (\tilde{C_3}=0.7)$')
ax.yaxis.set_major_formatter(ticker.FormatStrFormatter('%.2f'))
ax.set_xlabel(f'Number of iterations \n ($d=3, \\sigma=0.6, |D|=1000, \\beta=3$)', fontsize='18')
ax.set_xlabel(f'Number of iterations \n ($d=1, \\sigma=0.6, |D|=1000, \\beta=1$)', fontsize='18')
plt.ylim(0.0, 0.8) # d=3
ax.legend(ncol=1, loc='upper right', fontsize='14')
plt.savefig(f'../HSS_figures/HSS_left_right_existC_dim{dim}_noise{noise_var}_stepsize{step_size}.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()



# # d=1
# index=0
# ax.plot(sizes[index:], BSP_result['BSP_left_list'][index:], c='brown',  linestyle='-', linewidth=1.3, label=r'$t||f_{t+1,\beta,D}-f_{t,\beta,D}||_{D}+t^{1/2}||f_{t+1,\beta,D}-f_{t,\beta,D}||_{K}$')
# ax.plot(sizes[index:], BSP_result['BSP_right_list_1'][index:], c='purple', linestyle='--', linewidth=1.3, label=r'$\tilde{C_1}\mathcal{W}_{D, {t}} \quad (\tilde{C_1}=0.25)$')
# ax.plot(sizes[index:], BSP_result['BSP_right_list_2'][index:], c='royalblue', linestyle='--', linewidth=1.3, label=r'$\tilde{C_2}\mathcal{W}_{D, {t}} \quad (\tilde{C_2}=0.3)$')
# ax.plot(sizes[index:], BSP_result['BSP_right_list_3'][index:], c='green', linestyle='--', linewidth=1.3, label=r'$\tilde{C_3}\mathcal{W}_{D, {t}} \quad (\tilde{C_3}=0.4)$')
# ax.yaxis.set_major_formatter(ticker.FormatStrFormatter('%.2f'))
# ax.set_xlabel(f'Number of iterations \n ($d=1, \\sigma=0.6, |D|=1000, \\beta=1$)', fontsize='18')
# plt.ylim(0.0, 0.3) # d=1
# ax.legend(ncol=1, loc='upper right', fontsize='14')
# plt.savefig(f'../HSS_figures/HSS_left_right_existC_dim{dim}_noise{noise_var}_stepsize{step_size}.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()


