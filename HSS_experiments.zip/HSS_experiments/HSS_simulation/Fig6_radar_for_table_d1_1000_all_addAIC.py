import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
config = {
    "font.family":'Times New Roman',
    "font.size": 16,
    "mathtext.fontset":'stix',
}
rcParams.update(config)

import numpy as np
import matplotlib.pyplot as plt
from math import pi

dim = 1
trainsize = 1000
noise_var = 0.6
step_size = 1

categories = ['                 Accuracy     \n               (by $L_2$ norm)', 'Accuracy \n   (by $L_\\infty$ norm)\n', 'Efficiency          \n(by time)          ', '\nEfficiency \n(by MMU)']
data_ranges = {
    '                 Accuracy     \n               (by $L_2$ norm)': (0.0506, 0.080),
    'Accuracy \n   (by $L_\\infty$ norm)\n': (0.1216, 0.31),
    'Efficiency          \n(by time)          ': (1.03, 1800),
    '\nEfficiency \n(by MMU)': (0.43, 85)}

algorithms = {
'HO': [0.0587, 0.2630, 1.03, 0.43],
'AIC': [0.0742, 0.2407, 7.26, 0.66],
'BIC': [0.0750, 0.2995, 8.85, 0.65],
    'BP': [0.0643, 0.1817, 924.71, 52.40],
    'LP': [0.0658, 0.2394, 1618.29, 76.65],
    'ESR': [0.0598, 0.2604, 4.88, 0.92],
    'DP': [0.0566, 0.2788, 4.32, 0.49],
    'HSS': [0.0506, 0.1216, 8.71, 0.51],}


# Normalize and reverse data for radar chart
normalized_data = {}
for algo, values in algorithms.items():
    normalized = []
    for i, value in enumerate(values):
        category = categories[i]
        min_val, max_val = data_ranges[category]
        # Reverse the normalization for efficiency metrics
        if category in ['Efficiency          \n(by time)          ', '\nEfficiency \n(by MMU)']:
            normalized_value = (max_val - value) / (max_val - min_val)
            print('max_val', max_val)
            print('normalized_value', normalized_value)
        else:
            normalized_value = 1 - (value - min_val) / (max_val - min_val)
            print(normalized_value)
        normalized.append(normalized_value)
    normalized_data[algo] = normalized

# Number of variables
N = len(categories)

# Compute angle for each axis
angles = [n / float(N) * 2 * pi for n in range(N)]
angles += angles[:1]  # Complete the loop

# Initialize radar chart
fig, ax = plt.subplots(figsize=(6, 6), subplot_kw=dict(polar=True))

# Draw one axis per variable and add labels
plt.xticks(angles[:-1], categories)

colors = {
    'HO': 'm',
    'AIC': 'dimgrey',
'BIC': 'dodgerblue',
    'BP': 'royalblue',
    'LP': 'teal',
    'ESR': 'rebeccapurple',
    'DP': 'orange',
    'HSS': 'brown',
}

# Plot each algorithm's performance
for algo, values in normalized_data.items():
    values += values[:1]  # Complete the loop
    ax.plot(angles, values, linewidth=1, linestyle='solid', label=algo, color=colors[algo])
    ax.fill(angles, values, alpha=0.1, color=colors[algo])

    for angle, value in zip(angles, values):
        ax.scatter([angle], [value], s=30, color=colors[algo], zorder=5)

# Customize the radar chart to have straight lines
ax.yaxis.grid(True)
ax.spines['polar'].set_visible(False)  # Hide the circular frame
ax.set_yticklabels([])


ax.legend(loc='lower center', bbox_to_anchor=(0.5, -0.45), ncol=4, frameon=False, prop={'size': 16})
ax.set_xlabel(f'Comparison of different methods \n $(d={dim}, \\sigma={noise_var}, |D|=1000, \\beta={step_size})$', fontsize='17', labelpad=60)

# Increase the bottom margin to prevent overlapping with labels
plt.subplots_adjust(bottom=0.4)


# Show plot
# plt.title('Algorithm Performance Radar Chart (Inverted Metrics)')
plt.tight_layout()  # Adjust layout to prevent clipping of labels
plt.savefig(f'../HSS_figures/Radar_Chart_dim{dim}_trainsize{trainsize}_all_new.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()

# plt.savefig(f'../GPU_paper_use/Radar_Chart_dim{dim}_trainsize{trainsize}_only_ESR_DP_HSS.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()