import pandas as pd
from numpy import *
import numpy as np
import math
import h5py
from sklearn.model_selection import KFold
import os, time
time_start = time.time()
import random
import matplotlib.pyplot as plt


'''------------------------------------------------定义核函数------------------------------------------------'''
def kernel_matrix_dim_1(x, y):
    n,t = len(x), len(y)
    mat_1 = np.ones((t,n))
    y_1 = np.reshape(y, (t, 1), order='A')  # (t, 1)
    y_1 = np.repeat(y_1, n, axis=1)         # (t, n)
    x_1 = np.reshape(x, (1, n), order='A')  # (1, n)
    x_1 = np.repeat(x_1, t, axis=0)         # (t, n)
    kermatrix = np.minimum(x_1, y_1) + mat_1
    return kermatrix

def func_kernel_dim_3(x):
    if x >= 0 and x <= 1:
        result = (1 - x) ** 4 * (4*x+1)
    else:
        result = 0.0
    return result

# (2) gaussian kernel
def gaussian_k(x):
    result = math.exp(-x**2)
    return result

def kernel_matrix_dim_3(x, y):
    n, t = len(x), len(y)
    y_1 = np.reshape(y, (t, 1, 3))
    y_1 = np.repeat(y_1, n, axis=1)  # (t,n,3)
    x_1 = np.reshape(x, (1, n, 3))
    x_1 = np.repeat(x_1, t, axis=0)  # (t,n,3)
    dis = x_1 - y_1
    dis_norm = np.linalg.norm(dis, axis=2)   # (t,n)
    # for kernel defined in "h3_k()"
    h3_k_vector = np.vectorize(func_kernel_dim_3)
    kermatrix = h3_k_vector(dis_norm)
    return kermatrix

'''------------------------------------------------定义回归函数------------------------------------------------'''
def func_dim_1(x):
    if x>=0 and x<=0.5:
        result=x
    else:
        result=1-x
    return result

def create_y_func_dim_1(x):
    func_dim_1_vector = np.vectorize(func_dim_1)
    y = func_dim_1_vector(x)      # (6,n)
    return y


def func_dim_3(norm_x):
    if norm_x>=0 and norm_x<=1:
        result=(1-norm_x)**6 * (35*norm_x**2 + 18*norm_x + 3)
    else:
        result=0
    return result


def create_y_func_dim_3(x):
    norm_x = np.linalg.norm(x, axis=1)
    func_dim_3_vector = np.vectorize(func_dim_3)
    y = func_dim_3_vector(norm_x)      # (6,n)
    return y


'''------------------------------------------------采集样本------------------------------------------------'''
def sample(train_size, test_size,  dim, noise_var):
    X_train = np.random.uniform(0.0, 1.0, train_size)
    X_test = np.random.uniform(0.0, 1.0, test_size)
    truncated_noise_value = 0.4
    if dim == 1:
        noise = np.random.normal(0, noise_var, train_size)
        noise_clipped = np.clip(noise, -truncated_noise_value, truncated_noise_value)
        y_train = create_y_func_dim_1(X_train) + noise # or noise_clipped
        y_test = create_y_func_dim_1(X_test)
    else: # d=3
        noise = np.random.normal(0, noise_var, train_size[0])
        noise_clipped = np.clip(noise, -truncated_noise_value, truncated_noise_value)
        y_train = create_y_func_dim_3(X_train) + noise # or noise_clipped
        y_test = create_y_func_dim_3(X_test)
    return X_train.shape, y_train.shape, X_train, y_train, X_test.shape, y_test.shape, X_test, y_test


def generate_data(train, test, dim, noise_var):
    samples = sample(train, test, dim, noise_var)
    X_train, y_train, X_test, y_test = samples[2], samples[3], samples[6], samples[7]
    print('\n ########### ♣️From dim = %s | noise_var=%s | Train set X:%s, y:%s | Test set X:%s, y:%s  ##########' % (dim, noise_var, samples[0], samples[1], samples[4], samples[5]))
    return X_train, y_train, X_test, y_test


'''------------------------------------------------计算有效维------------------------------------------------'''
# 计算有效维，快速计算，直接计算出所有steps的有效维
def effective_dim(X_tra, dim, T_upper):
    ker = kernel_matrix_dim_1(X_tra, X_tra) if dim == 1 else kernel_matrix_dim_3(X_tra, X_tra)
    U, S, V = np.linalg.svd(ker)

    step_t_list = list(range(1, T_upper + 1, 1))
    step_t_array = np.array(step_t_list)
    n_s, n_t = S.shape[0], step_t_array.shape[0]

    step_t_array = np.reshape(step_t_array, (n_t, 1)) # (n_t, 1)
    step_t_array = np.repeat(step_t_array, n_s, axis=1) # (n_t, n_s)
    step_t_array = step_t_array.T   # (n_s, n_t)

    S_new = np.reshape(S, (n_s, 1)) # (n_s, 1)
    S_new = np.repeat(S_new, n_t, axis=1) # (n_s, n_t)

    S_parameter = S_new/(S_new + (1/step_t_array) * n_s) #
    effect_dim = np.sum(S_parameter, axis = 0)
    return effect_dim



'''-------------------------------计算 KGD的系数alpha(对应论文中的c_t, 默认c_0=(0,...,0))和核矩阵ker ------------------------------------'''
def Alpha_KGD_vector(X_train, y_tra, dim, step_t, step_size):
    ker = kernel_matrix_dim_1(X_train, X_train) if dim == 1 else kernel_matrix_dim_3(X_train, X_train)
    n = len(X_train)
    y_tra = np.reshape(y_tra, (n, 1))
    alpha = np.reshape(np.zeros(n), (n, 1))
    # for i in range(step_t + 1): # 应该改为step_t，此时对应才是c_t
    for i in range(step_t):
        alpha = alpha + (step_size / n) * (y_tra - np.dot(ker, alpha)) # t=1,...,t # i=0,计算的是t=1时的结果
    return alpha


def Predicted_KGD(X_train, y_tra, x_tes, y_tes, dim, step_t, step_size): # 计算的实际上是t=step_t+1时对用的结果
    y_tes = np.squeeze(y_tes)
    n, t = len(X_train), len(x_tes)
    pred_alpha = Alpha_KGD_vector(X_train, y_tra, dim, step_t, step_size)  # (n, 1)
    if dim == 1:
        pred_ker = kernel_matrix_dim_1(X_train, x_tes)  # (n, n)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)

    else:
        pred_ker = kernel_matrix_dim_3(X_train, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)

    average_error = np.sum((y_fit - y_tes) ** 2) / t
    L2_norm = math.sqrt(average_error)
    infinity_norm = np.max(np.abs(y_fit - y_tes))
    return y_fit, L2_norm, infinity_norm




'''----------------------------------------------------------------Early_stopping_rule ----------------------------------------------------------------'''
def ESR_left_right_calculation(X_train, y_tra, dim, total_steps, step_size, noise_var):  # noise_varm是噪音的标准差
    n_D = len(X_train)
    n_T = total_steps
    ker = kernel_matrix_dim_1(X_train, X_train) if dim == 1 else kernel_matrix_dim_3(X_train, X_train)
    empirical_ker = ker / n_D
    U, S, V = np.linalg.svd(empirical_ker) # (D, )

    # R中的min的第一项
    eigenvalue_of_empirical_ker_matrix = np.tile(S.reshape(n_D, 1), (1, n_T))# (D, T)

    # R中的min的第二项
    t_vector = np.arange(1, n_T + 1)
    t_matrix = np.tile(t_vector, (n_D, 1))  # 将向量扩展成3行7列的矩阵

    eta_t_matrix = step_size * t_matrix # (D, T)
    eta_in_R = 1 / eta_t_matrix  # (D, T)

    # 逐列对比两个矩阵中较小的元素，然后生成一个形状相同的新的矩阵，存储这些较小的元素
    R_matrix = np.minimum(eigenvalue_of_empirical_ker_matrix, eta_in_R) # (D, T)
    R_vector =  np.sum(R_matrix, axis=0) / n_D # (T, )
    ESR_left =  np.sqrt(R_vector)
    ESR_right = 1 / (noise_var * t_vector) # (T, )
    return ESR_left, ESR_right


def ESR_principle(ESR_left, ESR_right_part, C_ESR, total_steps):
    ESR_right = C_ESR * ESR_right_part
    t_ESR = total_steps
    for index, (ESR_left, ESR_right) in enumerate(zip(ESR_left, ESR_right)):
        if ESR_left > ESR_right:
            t_ESR = index + 1
            # print('-------- total_steps = %s,  C_ESR=%s, t_ESR=%s' % (total_steps, C_ESR, t_ESR))
            return t_ESR

    # print('--------total_steps = %s,  C_ESR=%s, t_ESR=%s' % (total_steps, C_ESR, t_ESR))
    return t_ESR


'''----------------------------- ESR 只有L2 norm-----------------------------------'''
# def select_c_esr(X_train, y_train, dim, step_size, split_L, noise_var):
#     random.seed(1)
#     random_train = random.sample(list(range(len(X_train))), split_L)  # size为L的training data
#     random_validation = [element for element in list(range(len(X_train))) if element not in random_train] # size为|D|-L的validation data
#
#     X_train_L, X_validation_L = X_train[random_train], X_train[random_validation]  # 长度分别是L, |D|-L
#     y_train_L, y_validation_L = y_train[random_train], y_train[random_validation]
#
#     total_steps = len(X_train)
#     ESR_left, ESR_right_part = ESR_left_right_calculation(X_train_L, y_train_L, dim, total_steps, step_size, noise_var)
#     error_list, ESR_tj_list, min_error_list = [], [], []
#
#     c_esr_suggested = 2 * math.e
#     C_esr_list = [i * 0.2 for i in range(1, 10)]
#     C_esr_list.append(c_esr_suggested)
#     print('C_esr_list', C_esr_list)
#
#     for C_esr in C_esr_list:
#         tj_c_esr_1 = ESR_principle(ESR_left, ESR_right_part, C_esr, total_steps)
#         error_c_esr_1 = Predicted_KGD(X_train_L, y_train_L, X_validation_L, y_validation_L, dim, tj_c_esr_1, step_size)[1]
#         error_list.append(error_c_esr_1)
#         ESR_tj_list.append(tj_c_esr_1)
#         # print(f'When Cj={C_bsp_j:.2f}, tj={BSP_tj_with_fixed_Cj:.2f}, error={error}')
#
#     print('C_esr_list', C_esr_list)
#     print('ESR_tj_list', ESR_tj_list)
#     print('error_list', error_list)
#
#     index = error_list.index(min(error_list))
#     c_esr_star = C_esr_list[index]
#
#     print('min(error_list)', min(error_list))
#     print('tj_star', ESR_tj_list[index])
#     print('cj_star', c_esr_star)
#
#     return c_esr_star, ESR_tj_list[index], min(error_list)
#
#
# def select_t_final_byESR(X_train, y_train, dim, step_size, split_L, noise_var):
#     # c_esr_star = 2 * math.e  # suggested c by [17]; e=2.718281828459045
#     c_esr_star = select_c_esr(X_train, y_train, dim, step_size, split_L, noise_var)[0]
#     total_steps = len(X_train)
#     ESR_left, ESR_right_part = ESR_left_right_calculation(X_train, y_train, dim, total_steps, step_size, noise_var)
#     t_star = ESR_principle(ESR_left, ESR_right_part, c_esr_star, total_steps)
#     return c_esr_star, t_star
#
#
# def Test_error_KGD_ESR(X_train, y_train, X_test, y_test, dim, step_size, split_L, noise_var):
#     c_esr_star, t_star = select_t_final_byESR(X_train, y_train, dim, step_size, split_L, noise_var)
#     test_error = Predicted_KGD(X_train, y_train, X_test, y_test, dim, t_star, step_size)[1]
#     return c_esr_star, t_star, test_error


'''----------------------------- ESR, 有L2 norm 和L infinity norm ----------------------------------'''
'''-------------------------------     测试参数c的范围用    ---------------------------------'''
# def select_c_esr(X_train, y_train, dim, step_size, split_L, noise_var, log_filename):
#     random.seed(1)
#     random_train = random.sample(list(range(len(X_train))), split_L)  # size为L的training data
#     random_validation = [element for element in list(range(len(X_train))) if element not in random_train] # size为|D|-L的validation data
#     X_train_L, X_validation_L = X_train[random_train], X_train[random_validation]  # 长度分别是L, |D|-L
#     y_train_L, y_validation_L = y_train[random_train], y_train[random_validation]
#
#     total_steps = len(X_train)
#     ESR_left, ESR_right_part = ESR_left_right_calculation(X_train_L, y_train_L, dim, total_steps, step_size, noise_var)
#     L2_error_list, Linfinity_error_list, ESR_tj_list = [], [], []
#     C_esr_list = list(np.arange(0.00001, 2, 0.1))  # [i * 0.5 for i in range(1, 20)]
#     # c_esr_suggested = 2 * math.e
#     # C_esr_list.append(c_esr_suggested)
#     # C_esr_list.sort()
#
#     for C_esr in C_esr_list:
#         tj_c_esr_1 = ESR_principle(ESR_left, ESR_right_part, C_esr, total_steps)
#         ESR_tj_list.append(tj_c_esr_1)
#         # # L2_norm
#         # L2_error_c_esr_1 = Predicted_KGD(X_train_L, y_train_L, X_validation_L, y_validation_L, dim, tj_c_esr_1, step_size)[1]
#         # L2_error_list.append(L2_error_c_esr_1)
#         # # Linfinity_norm
#         # Linfinity_error_c_esr_1 = Predicted_KGD(X_train_L, y_train_L, X_validation_L, y_validation_L, dim, tj_c_esr_1, step_size)[2]
#         # Linfinity_error_list.append(Linfinity_error_c_esr_1)
#         _, L2_error_c_esr_1, Linfinity_error_c_esr_1 = Predicted_KGD(X_train_L, y_train_L, X_validation_L, y_validation_L, dim, tj_c_esr_1, step_size)
#         L2_error_list.append(L2_error_c_esr_1)
#         Linfinity_error_list.append(Linfinity_error_c_esr_1)
#
#     index_L2 = L2_error_list.index(min(L2_error_list))
#     L2_C, L2_t, L2_min_error = C_esr_list[index_L2], ESR_tj_list[index_L2], min(L2_error_list)
#     index_Linfinity = Linfinity_error_list.index(min(Linfinity_error_list))
#     Linfinity_C, Linfinity_t, Linfinity_min_error = C_esr_list[index_Linfinity], ESR_tj_list[index_Linfinity], min(Linfinity_error_list)
#
#     # print('---------------------- validation result in selecting the constant  -----------------------')
#     # print('C_esr_list:', C_esr_list)
#     # print('ESR_tj_list:', ESR_tj_list)
#     # print('L2_error_list:', L2_error_list)
#     # print('L2_C, L2_t, L2_min_error:', (L2_C, L2_t, L2_min_error))
#     # print('Linfinity_error_list:', Linfinity_error_list)
#     # print('Linfinity_C, Linfinity_t, Linfinity_min_error:', (Linfinity_C, Linfinity_t, Linfinity_min_error))
#     # # 💎logging in process
#     # with open(log_filename, 'a') as log_file:
#     #     log_file.write(f'\n--------------------------- data size : {len(X_train)} -------------------------------------\n-----------valadition result:-----------\n'
#     #                    f'C_esr_list: {C_esr_list};\nESR_tj_list: {ESR_tj_list};\nL2_error_list: {L2_error_list};\nLinfinity_error_list: {Linfinity_error_list}\n'
#     #                    f'L2_C:{L2_C};\nL2_t:{L2_t};\nL2_min_error:{L2_min_error}\n'
#     #                    f'Linfinity_C:{Linfinity_C};\nLinfinity_t:{Linfinity_t};\nLinfinity_min_error:{Linfinity_min_error}\n')
#
#     return L2_C, L2_t, L2_min_error, Linfinity_C, Linfinity_t, Linfinity_min_error


def select_c_esr(X_train_L, y_train_L, dim, step_size, split_L_tr, total_steps, noise_var, log_filename, C_bsp_list):
    random.seed(1)
    random_train = random.sample(list(range(len(X_train_L))), split_L_tr)  # size为L的training data
    random_validation = [element for element in list(range(len(X_train_L))) if element not in random_train] # size为|D|-L的validation data
    X_train_L_tr, X_train_L_val = X_train_L[random_train], X_train_L[random_validation]  # 长度分别是L, |D|-L
    y_train_L_tr, y_train_L_val = y_train_L[random_train], y_train_L[random_validation]

    ESR_left, ESR_right_part  = ESR_left_right_calculation(X_train_L_tr, y_train_L_tr, dim, total_steps, step_size, noise_var)
    L2_norm_error_list, Linfty_norm_error_list, select_t_list = [], [], []

    for C_1 in C_bsp_list:
        # print('C_1:', C_1)
        select_t = ESR_principle(ESR_left, ESR_right_part, C_1, total_steps)
        select_t_list.append(select_t)
        _, L2_norm_error, Linfty_norm_error = Predicted_KGD(X_train_L_tr, y_train_L_tr, X_train_L_val, y_train_L_val, dim, select_t, step_size)
        L2_norm_error_list.append(L2_norm_error)
        Linfty_norm_error_list.append(Linfty_norm_error)

    index_L2norm = L2_norm_error_list.index(min(L2_norm_error_list))
    index_Linftynorm = Linfty_norm_error_list.index(min(Linfty_norm_error_list))
    L2_C, L2_t, L2_min_error = C_bsp_list[index_L2norm], select_t_list[index_L2norm], min(L2_norm_error_list)
    Linfinity_C, Linfinity_t, Linfinity_min_error = C_bsp_list[index_Linftynorm], select_t_list[index_Linftynorm], min(Linfty_norm_error_list)
    return L2_C, L2_t, L2_min_error, Linfinity_C, Linfinity_t, Linfinity_min_error




# def select_t_final_byESR(X_train, y_train, dim, step_size, split_L, noise_var, log_filename):
#     total_steps = len(X_train)
#     L2_C, _, _, Linfinity_C, _, _ = select_c_esr(X_train, y_train, dim, step_size, split_L, noise_var, log_filename)
#     ESR_left, ESR_right_part = ESR_left_right_calculation(X_train, y_train, dim, total_steps, step_size, noise_var)
#     L2_t_star = ESR_principle(ESR_left, ESR_right_part, L2_C, total_steps)
#     Linfinity_t_star = ESR_principle(ESR_left, ESR_right_part, Linfinity_C, total_steps)
#     return L2_C, L2_t_star, Linfinity_C, Linfinity_t_star


# def Test_error_KGD_ESR(X_train, y_train, X_test, y_test, dim, step_size, split_L, noise_var, log_filename):
#     L2_C, L2_t_star, Linfinity_C, Linfinity_t_star = select_t_final_byESR(X_train, y_train, dim, step_size, split_L, noise_var, log_filename)
#     L2_test_error = Predicted_KGD(X_train, y_train, X_test, y_test, dim, L2_t_star, step_size)[1]
#     Linfinity_test_error = Predicted_KGD(X_train, y_train, X_test, y_test, dim, Linfinity_t_star, step_size)[2]
#     return L2_C, L2_t_star, L2_test_error, Linfinity_C, Linfinity_t_star, Linfinity_test_error


def select_t_final_byESR(X_train, y_train, X_train_L, y_train_L, dim, step_size, split_L_tr, total_steps, noise_var, log_filename, C_bsp_list):
    L2_C, _, _, Linfinity_C, _, _ = select_c_esr(X_train_L, y_train_L, dim, step_size, split_L_tr, total_steps, noise_var, log_filename, C_bsp_list)
    ESR_left, ESR_right_part = ESR_left_right_calculation(X_train, y_train, dim, total_steps, step_size, noise_var)
    L2_t_star = ESR_principle(ESR_left, ESR_right_part, L2_C, total_steps)
    Linfinity_t_star = ESR_principle(ESR_left, ESR_right_part, Linfinity_C, total_steps)
    return L2_C, L2_t_star, Linfinity_C, Linfinity_t_star



def Test_error_KGD_ESR(X_train, y_train, X_test, y_test, dim, step_size, split_L, split_L_tr, noise_var, log_filename, C_bsp_list):
    total_steps = len(X_train)
    random.seed(1)
    random_train = random.sample(list(range(len(X_train))), split_L)  # size为L的training data
    random_validation = [element for element in list(range(len(X_train))) if element not in random_train] # size为|D|-L的validation data
    X_train_L, X_validation_L = X_train[random_train], X_train[random_validation]  # 长度分别是L, |D|-L
    y_train_L, y_validation_L = y_train[random_train], y_train[random_validation]

    L2_C, L2_t_star, Linfinity_C, Linfinity_t_star = select_t_final_byESR(X_train, y_train, X_train_L, y_train_L, dim, step_size, split_L_tr, total_steps, noise_var, log_filename, C_bsp_list)
    L2_test_error = Predicted_KGD(X_train, y_train, X_test, y_test, dim, L2_t_star, step_size)[1]
    Linfinity_test_error = Predicted_KGD(X_train, y_train, X_test, y_test, dim, Linfinity_t_star, step_size)[2]
    return L2_C, L2_t_star, L2_test_error, Linfinity_C, Linfinity_t_star, Linfinity_test_error

# time_start = time.time()
# dim = 1
# step_size = 1
# np.random.seed(10)
# delta_ = 0.9
# noise_var = 0.2
# train_size = 1000
# split_L = int(train_size * 0.7)
# train, test = (train_size, dim), (200, dim)
# X_train, y_train, X_test, y_test = generate_data(train, test, dim, noise_var)
# c_esr_star, t_star, test_error = Test_error_KGD_ESR(X_train, y_train, X_test, y_test, dim, step_size, split_L, noise_var)
# print('-----------------------------------------------------final test error----------------------------------------------------- ')
# print('c_esr_star, t_star, test_error', (c_esr_star, t_star, test_error))
# time_total = time.time() - time_start
# print('runing time:', time_total)

# C_esr_list [0.2, 0.4, 0.6000000000000001, 0.8, 1.0, 1.2000000000000002, 1.4000000000000001, 1.6, 1.8, 5.43656365691809]
# ESR_tj_list [102, 261, 452, 665, 899, 1000, 1000, 1000, 1000, 1000]
# error_list [0.20341205890374361, 0.20243721081090024, 0.20277999689690362, 0.2030720083741855, 0.20328626158147853, 0.2033545867092339, 0.2033545867092339, 0.2033545867092339, 0.2033545867092339, 0.2033545867092339]
# min(error_list) 0.20243721081090024
# tj_star 261
# cj_star 0.4
# -------- total_steps = 1000,  C_ESR=0.4, t_ESR=332
# -----------------------------------------------------final test error----------------------------------------------------- 
# c_esr_star 0.4
# t_star 332
# test_error 0.015078296104653978
# runing time: 0.794093132019043


# L2_C, L2_t_star, L2_test_error, Linfinity_C, Linfinity_t_star, Linfinity_test_error = Test_error_KGD_ESR(X_train, y_train, X_test, y_test, dim, step_size, split_L, noise_var)
# print('-----------------------------------------------------final test error----------------------------------------------------- ')
# print('L2_C, L2_t_star, L2_test_error, Linfinity_C, Linfinity_t_star, Linfinity_test_error', (L2_C, L2_t_star, L2_test_error, Linfinity_C, Linfinity_t_star, Linfinity_test_error))
# time_total = time.time() - time_start
# print('runing time:', time_total)



# time_start = time.time()
# dim = 1
# step_size = 1
# np.random.seed(5)
# delta_ = 0.9
# noise_var = 0.2
#
# # 日志文件路径
# log_filename = f'./main_function_ESR_dim{dim}_noisevar{noise_var}_stepsize{step_size}_log.txt'
#
# # 初始化日志文件
# with open(log_filename, 'w') as log_file:
#     log_file.write("Start Logging\n")
#
#
# c_esr_star_list, t_star_list, test_error_list = [], [], []
# for size_i in range(1, 16):
#     train_size = 100 * size_i
#     print('train_size', train_size)
#     split_L = int(train_size * 0.7)
#     train, test = (train_size, dim), (200, dim)
#     X_train, y_train, X_test, y_test = generate_data(train, test, dim, noise_var)
#     c_esr_star, t_star, test_error = Test_error_KGD_ESR(X_train, y_train, X_test, y_test, dim, step_size, split_L, noise_var)
#
#     # 记录日志
#     with open(log_filename, 'a') as log_file:
#         log_file.write(f'data size: {train_size};  c_esr_star: {c_esr_star}; t_star: {t_star}; test_error: {test_error}\n')
#
#
#     c_esr_star_list.append(c_esr_star)
#     t_star_list.append(t_star)
#     test_error_list.append(test_error)
#     print('-----------------------------------------------------final test error----------------------------------------------------- ')
#     print('c_esr_star_list', c_esr_star_list)
#     print('t_star_list', t_star_list)
#     print('test_error_list', test_error_list)
#
#     time_total = time.time() - time_start
#     print('runing time:', time_total)
#
#
# # 记录运行时间
# with open(log_filename, 'a') as log_file:
#     log_file.write(f'Total running time: {time_total}\n')
# print("Logging complete.")




































































































































