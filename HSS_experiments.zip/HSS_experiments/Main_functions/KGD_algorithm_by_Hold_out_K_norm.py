import pandas as pd
from numpy import *
import numpy as np
import math
import h5py
from sklearn.model_selection import KFold
import os, time
time_start = time.time()
import random
import matplotlib.pyplot as plt


'''------------------------------------------------定义核函数------------------------------------------------'''
def kernel_matrix_dim_1(x, y):
    n,t = len(x), len(y)
    mat_1 = np.ones((t,n))
    y_1 = np.reshape(y, (t, 1), order='A')  # (t, 1)
    y_1 = np.repeat(y_1, n, axis=1)         # (t, n)
    x_1 = np.reshape(x, (1, n), order='A')  # (1, n)
    x_1 = np.repeat(x_1, t, axis=0)         # (t, n)
    kermatrix = np.minimum(x_1, y_1) + mat_1
    return kermatrix

def func_kernel_dim_3(x):
    if x >= 0 and x <= 1:
        result = (1 - x) ** 4 * (4*x+1)
    else:
        result = 0.0
    return result

# (2) gaussian kernel
def gaussian_k(x):
    result = math.exp(-x**2)
    return result

def kernel_matrix_dim_3(x, y):
    n, t = len(x), len(y)
    y_1 = np.reshape(y, (t, 1, 3))
    y_1 = np.repeat(y_1, n, axis=1)  # (t,n,3)
    x_1 = np.reshape(x, (1, n, 3))
    x_1 = np.repeat(x_1, t, axis=0)  # (t,n,3)
    dis = x_1 - y_1
    dis_norm = np.linalg.norm(dis, axis=2)   # (t,n)
    # for kernel defined in "h3_k()"
    h3_k_vector = np.vectorize(func_kernel_dim_3)
    kermatrix = h3_k_vector(dis_norm)
    return kermatrix

'''------------------------------------------------定义回归函数------------------------------------------------'''
def func_dim_1(x):
    if x>=0 and x<=0.5:
        result=x
    else:
        result=1-x
    return result

def create_y_func_dim_1(x):
    func_dim_1_vector = np.vectorize(func_dim_1)
    y = func_dim_1_vector(x)      # (6,n)
    return y


def func_dim_3(norm_x):
    if norm_x>=0 and norm_x<=1:
        result=(1-norm_x)**6 * (35*norm_x**2 + 18*norm_x + 3)
    else:
        result=0
    return result


def create_y_func_dim_3(x):
    norm_x = np.linalg.norm(x, axis=1)
    func_dim_3_vector = np.vectorize(func_dim_3)
    y = func_dim_3_vector(norm_x)      # (6,n)
    return y


'''------------------------------------------------采集样本------------------------------------------------'''
def sample(train_size, test_size,  dim, noise_var):
    X_train = np.random.uniform(0.0, 1.0, train_size)
    X_test = np.random.uniform(0.0, 1.0, test_size)
    if dim == 1:
        noise = np.random.normal(0, noise_var, train_size)
        y_train_noise0 = create_y_func_dim_1(X_train)
        y_train = y_train_noise0 + noise
        y_test = create_y_func_dim_1(X_test)
    else: # d=3
        noise = np.random.normal(0, noise_var, train_size[0])
        y_train_noise0 = create_y_func_dim_3(X_train)  # 是为了计算k norm
        y_train = y_train_noise0 + noise
        y_test = create_y_func_dim_3(X_test)
    return X_train.shape, y_train.shape, X_train, y_train, X_test.shape, y_test.shape, X_test, y_test, y_train_noise0


def generate_data(train, test, dim, noise_var):
    samples = sample(train, test, dim, noise_var)
    X_train, y_train, X_test, y_test, y_train_noise0 = samples[2], samples[3], samples[6], samples[7], samples[8]
    # print('\n ########### ♣️From dim = %s | noise_var=%s | Train set X:%s, y:%s | Test set X:%s, y:%s  ##########' % (dim, noise_var, samples[0], samples[1], samples[4], samples[5]))
    return X_train, y_train, X_test, y_test, y_train_noise0




'''-------------------------------计算 KGD的系数alpha(对应论文中的c_t, 默认c_0=(0,...,0))和核矩阵ker ------------------------------------'''
def Alpha_KGD_vector(X_train, y_tra, dim, step_t, step_size):
    ker = kernel_matrix_dim_1(X_train, X_train) if dim == 1 else kernel_matrix_dim_3(X_train, X_train)
    n = len(X_train)
    y_tra = np.reshape(y_tra, (n, 1))
    alpha = np.reshape(np.zeros(n), (n, 1))
    # for i in range(step_t + 1): # 应该改为step_t，此时对应才是c_t
    for i in range(step_t):
        alpha = alpha + (step_size / n) * (y_tra - np.dot(ker, alpha)) # t=1,...,t # i=0,计算的是t=1时的结果
    return alpha


def Predicted_KGD(X_train, y_tra, x_tes, y_tes, dim, step_t, step_size): # 计算的实际上是t=step_t+1时对用的结果
    y_tes = np.squeeze(y_tes)
    n, t = len(X_train), len(x_tes)
    pred_alpha = Alpha_KGD_vector(X_train, y_tra, dim, step_t, step_size)  # (n, 1)
    if dim == 1:
        pred_ker = kernel_matrix_dim_1(X_train, x_tes)  # (n, n)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)

    else:
        pred_ker = kernel_matrix_dim_3(X_train, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)

    average_error = np.sum((y_fit - y_tes) ** 2) / t
    L2_norm = math.sqrt(average_error)
    infinity_norm = np.max(np.abs(y_fit - y_tes))
    return y_fit, L2_norm, infinity_norm


def Alpha_KGD(X_train, y_tra, dim, step_t, step_size):
    ker = kernel_matrix_dim_1(X_train, X_train) if dim == 1 else kernel_matrix_dim_3(X_train, X_train)
    # U, S, V = np.linalg.svd(ker)
    # step_size = 1 / np.max(S)
    n = len(X_train)
    y_tra = np.reshape(y_tra, (n, 1))
    alpha = np.reshape(np.zeros(n), (n, 1))
    alpha_matrix = np.empty(shape=(n, step_t+2))  # alpha_0, alpha_1, ..., alpha_t, alpha_t+1
    alpha_matrix[:, 0] = np.squeeze(alpha)  # 先存alpha_0
    for i in range(step_t + 1):
        alpha = alpha + (step_size / n) * (y_tra - np.dot(ker, alpha))
        alpha_matrix[:, i+1] = np.squeeze(alpha) # i=0时,存的是alpha_1， i=step_t时,存的是alpha_t+1，
    return alpha_matrix  # (n, t+2)


'''----------------------------------------------------------------hold out, 只有l2_norm----------------------------------------------------------------'''
# def Hold_out(X_train, y_train, dim, step_size):
#     split_L = int(len(X_train) * 0.5)
#     random.seed(1)
#     random_train = random.sample(list(range(len(X_train))), split_L)
#     random_validation = [element for element in list(range(len(X_train))) if element not in random_train]
#
#     X_train_L, X_validation_L = X_train[random_train], X_train[random_validation]
#     y_train_L, y_validation_L = y_train[random_train], y_train[random_validation]
#
#     pred_alpha = Alpha_KGD(X_train_L, y_train_L, dim, len(X_train_L), step_size)
#     pred_alpha = pred_alpha[:, :-1]
#     average_error_list = []
#     if dim == 1:
#         # print()
#         pred_ker = kernel_matrix_dim_1(X_train_L, X_validation_L)  # (n, n)
#         for i in range(len(X_train_L)+1):
#             y_fit = np.dot(pred_ker, pred_alpha[:, i])
#             y_fit = np.squeeze(y_fit)
#             y_validation_L = np.squeeze(y_validation_L)
#
#             average_error = np.sum((y_fit - y_validation_L) ** 2) / len(X_validation_L)
#             average_error_list.append(math.sqrt(average_error))
#
#     else:
#         pred_ker = kernel_matrix_dim_3(X_train_L, X_validation_L)
#         for i in range(len(X_train_L)+1):
#             # print(i)
#             y_fit = np.dot(pred_ker, pred_alpha[:, i])
#             y_fit = np.squeeze(y_fit)
#             average_error = np.sum((y_fit - y_validation_L) ** 2) / len(X_validation_L)
#             average_error_list.append(math.sqrt(average_error))
#
#     index = average_error_list.index(min(average_error_list))
#     t_star = list(range(len(X_train_L)+1))[index]
#     # print(list(range(len(X_train_L)+1)))
#     # print('t_star:', t_star)
#     return t_star
#
#
# def Test_error_KGD_HO(X_train, y_train, X_test, y_test, dim, step_size):
#     t_star = Hold_out(X_train, y_train, dim, step_size)
#     test_error = Predicted_KGD(X_train, y_train, X_test, y_test, dim, t_star, step_size)[1]
#     return t_star, test_error


'''----------------------------------------------------------------hold out, l2_norm和l infinity norm----------------------------------------------------------------'''
# def Hold_out(X_train, y_train, dim, step_size):
#     split_L = int(len(X_train) * 0.5)
#     random.seed(1)
#     random_train = random.sample(list(range(len(X_train))), split_L)
#     random_validation = [element for element in list(range(len(X_train))) if element not in random_train]
#     X_train_L, X_validation_L = X_train[random_train], X_train[random_validation]
#     y_train_L, y_validation_L = y_train[random_train], y_train[random_validation]
#
#     pred_alpha = Alpha_KGD(X_train_L, y_train_L, dim, len(X_train_L), step_size)
#     pred_alpha = pred_alpha[:, :-1]
#     L2_error_list, Linfinity_error_list = [], []
#     if dim == 1:
#         # print()
#         pred_ker = kernel_matrix_dim_1(X_train_L, X_validation_L)  # (n, n)
#         for i in range(len(X_train_L)+1):
#             y_fit = np.dot(pred_ker, pred_alpha[:, i])
#             y_fit = np.squeeze(y_fit)
#             y_validation_L = np.squeeze(y_validation_L)
#             # L2_norm
#             L2_error = np.sum((y_fit - y_validation_L) ** 2) / len(X_validation_L)
#             L2_error_list.append(math.sqrt(L2_error))
#             # Linfinity_norm
#             Linfinity_error = np.max(np.abs(y_fit - y_validation_L))
#             Linfinity_error_list.append(Linfinity_error)
#     else:
#         pred_ker = kernel_matrix_dim_3(X_train_L, X_validation_L)
#         for i in range(len(X_train_L)+1):
#             # print(i)
#             y_fit = np.dot(pred_ker, pred_alpha[:, i])
#             y_fit = np.squeeze(y_fit)
#             # L2_norm
#             L2_error = np.sum((y_fit - y_validation_L) ** 2) / len(X_validation_L)
#             L2_error_list.append(math.sqrt(L2_error))
#             # Linfinity_norm
#             Linfinity_error = np.max(np.abs(y_fit - y_validation_L))
#             Linfinity_error_list.append(Linfinity_error)
#
#     index_L2 = L2_error_list.index(min(L2_error_list))
#     t_star_L2 = list(range(len(X_train_L)+1))[index_L2]
#     index_Linfinity = Linfinity_error_list.index(min(Linfinity_error_list))
#     t_star_Linfinity  = list(range(len(X_train_L)+1))[index_Linfinity]
#     return t_star_L2, t_star_Linfinity
#
#
# def Test_error_KGD_HO(X_train, y_train, X_test, y_test, dim, step_size):
#     t_star_L2, t_star_Linfinity = Hold_out(X_train, y_train, dim, step_size)
#     test_error_L2 = Predicted_KGD(X_train, y_train, X_test, y_test, dim, t_star_L2, step_size)[1]
#     test_error_Linfinity = Predicted_KGD(X_train, y_train, X_test, y_test, dim, t_star_Linfinity, step_size)[2]
#     return t_star_L2, test_error_L2, t_star_Linfinity, test_error_Linfinity


def Hold_out(X_train, y_train, dim, total_steps, step_size):
    split_L_HO = int(len(X_train) * 0.5)  # 这个是HO本身的机制
    random.seed(1)
    random_train = random.sample(list(range(len(X_train))), split_L_HO)
    random_validation = [element for element in list(range(len(X_train))) if element not in random_train]
    X_train_L, X_validation_L = X_train[random_train], X_train[random_validation]
    y_train_L, y_validation_L = y_train[random_train], y_train[random_validation]

    pred_alpha = Alpha_KGD(X_train_L, y_train_L, dim, total_steps, step_size)
    pred_alpha = pred_alpha[:, :-1]
    L2_error_list, Linfinity_error_list = [], []
    if dim == 1:
        # print()
        pred_ker = kernel_matrix_dim_1(X_train_L, X_validation_L)  # (n, n)
        for i in range(total_steps+1):
            y_fit = np.dot(pred_ker, pred_alpha[:, i])
            y_fit = np.squeeze(y_fit)
            y_validation_L = np.squeeze(y_validation_L)
            # L2_norm
            L2_error = np.sum((y_fit - y_validation_L) ** 2) / len(X_validation_L)
            L2_error_list.append(math.sqrt(L2_error))
            # Linfinity_norm
            Linfinity_error = np.max(np.abs(y_fit - y_validation_L))
            Linfinity_error_list.append(Linfinity_error)
    else:
        pred_ker = kernel_matrix_dim_3(X_train_L, X_validation_L)
        for i in range(total_steps+1):
            # print(i)
            y_fit = np.dot(pred_ker, pred_alpha[:, i])
            y_fit = np.squeeze(y_fit)
            # L2_norm
            L2_error = np.sum((y_fit - y_validation_L) ** 2) / len(X_validation_L)
            L2_error_list.append(math.sqrt(L2_error))
            # Linfinity_norm
            Linfinity_error = np.max(np.abs(y_fit - y_validation_L))
            Linfinity_error_list.append(Linfinity_error)

    index_L2 = L2_error_list.index(min(L2_error_list))
    t_star_L2 = list(range(total_steps+1))[index_L2]
    index_Linfinity = Linfinity_error_list.index(min(Linfinity_error_list))
    t_star_Linfinity  = list(range(total_steps+1))[index_Linfinity]
    return t_star_L2, t_star_Linfinity


# def Test_error_KGD_HO(X_train, y_train, X_test, y_test, dim, split_L, step_size):
#     total_steps = len(X_train)
#     random.seed(1)
#     random_train = random.sample(list(range(len(X_train))), split_L)  # size为L的training data
#     random_validation = [element for element in list(range(len(X_train))) if element not in random_train] # size为|D|-L的validation data
#     X_train_L, X_validation_L = X_train[random_train], X_train[random_validation]  # 长度分别是L, |D|-L
#     y_train_L, y_validation_L = y_train[random_train], y_train[random_validation]
#     # print(X_train_L[0:5])
#
#     t_star_L2, t_star_Linfinity = Hold_out(X_train_L, y_train_L, dim, total_steps, step_size)  # 部分样本；100， 80， 70， 60； 在这个基础上在进行50% tra和50%的val分割
#     test_error_L2 = Predicted_KGD(X_train, y_train, X_test, y_test, dim, t_star_L2, step_size)[1]
#     test_error_Linfinity = Predicted_KGD(X_train, y_train, X_test, y_test, dim, t_star_Linfinity, step_size)[2]
#     return t_star_L2, test_error_L2, t_star_Linfinity, test_error_Linfinity




''' ---------------------------------------------- K norm 使用 ----------------------------------------------'''

def Hold_out_L2norm(X_train, y_train, dim, total_steps, step_size):
    split_L_HO = int(len(X_train) * 0.5)  # 这个是HO本身的机制
    random.seed(1)
    random_train = random.sample(list(range(len(X_train))), split_L_HO)
    random_validation = [element for element in list(range(len(X_train))) if element not in random_train]
    X_train_L, X_validation_L = X_train[random_train], X_train[random_validation]
    y_train_L, y_validation_L = y_train[random_train], y_train[random_validation]

    pred_alpha = Alpha_KGD(X_train_L, y_train_L, dim, total_steps, step_size)
    pred_alpha = pred_alpha[:, :-1]
    L2_error_list = []
    if dim == 1:
        # print()
        pred_ker = kernel_matrix_dim_1(X_train_L, X_validation_L)  # (n, n)
        for i in range(total_steps+1):
            y_fit = np.dot(pred_ker, pred_alpha[:, i])
            y_fit = np.squeeze(y_fit)
            y_validation_L = np.squeeze(y_validation_L)
            # L2_norm
            L2_error = np.sum((y_fit - y_validation_L) ** 2) / len(X_validation_L)
            L2_error_list.append(math.sqrt(L2_error))

    else:
        pred_ker = kernel_matrix_dim_3(X_train_L, X_validation_L)
        for i in range(total_steps+1):
            # print(i)
            y_fit = np.dot(pred_ker, pred_alpha[:, i])
            y_fit = np.squeeze(y_fit)
            # L2_norm
            L2_error = np.sum((y_fit - y_validation_L) ** 2) / len(X_validation_L)
            L2_error_list.append(math.sqrt(L2_error))

    index_L2 = L2_error_list.index(min(L2_error_list))
    t_star_L2 = list(range(total_steps+1))[index_L2]
    return t_star_L2


# 观察knorm: f_D和f_rho的关系
def HO_knorm_plot2(X_train, y_train, y_train_noise0, X_train_L, y_train_noise0_L, dim, step_size, total_steps):
    n_T = total_steps
    n_D = len(X_train)
    ker = kernel_matrix_dim_1(X_train, X_train) if dim == 1 else kernel_matrix_dim_3(X_train, X_train) # (D, D)
    C_t_matrix = Alpha_KGD(X_train, y_train, dim, n_T, step_size)[:, :-1]  # 只取t=0,1,2..., T
    C_t_noi0_matrix = Alpha_KGD(X_train, y_train_noise0, dim, n_T, step_size)[:, :-1] # (D, T+1)

    # 先求出noise=0.0时的最好的t_star_noi0,按照什么求呢，L2 norm
    t_star_L2 = Hold_out_L2norm(X_train_L, y_train_noise0_L, dim, total_steps, step_size) # t的index对应的就是t的值
    C_t_star_noi0_vertor = C_t_noi0_matrix[:, int(t_star_L2)] # (D,)
    C_t_star_noi0_vertor = np.reshape(C_t_star_noi0_vertor, (n_D, 1), order='A')  # (D, 1)
    C_t_star_noi0_matrix = np.repeat(C_t_star_noi0_vertor, n_T + 1, axis=1)  # # (D, T+1)

    C_diff_matrix = C_t_matrix - C_t_star_noi0_matrix # (D, T+1)
    C_diff_matrix_T = C_diff_matrix.T  # (T+1, D)

    # for norm_k
    norm_k_square_matirx = np.dot(np.dot(C_diff_matrix_T, ker), C_diff_matrix)  # (T+1, T+1)
    norm_k_square_matirx[norm_k_square_matirx < 0] = 0  # 对角线上的元素保持不变就好
    norm_k_matrix = np.sqrt(norm_k_square_matirx)
    norm_k_matrix_diag = np.diagonal(norm_k_matrix) # 提取对角线上的元素 T+1个  (T, )
    t_list = list(range(n_T + 1))
    return t_list, norm_k_matrix_diag


# def HO_knorm(X_train, y_train, y_train_noise0, X_train_L, y_train_noise0_L, dim, step_size, total_steps):
#     n_T = total_steps
#     n_D = len(X_train)
#     ker = kernel_matrix_dim_1(X_train, X_train) if dim == 1 else kernel_matrix_dim_3(X_train, X_train) # (D, D)
#     C_t_matrix = Alpha_KGD(X_train, y_train, dim, n_T, step_size)[:, :-1]  # 只取t=0,1,2..., T
#     C_t_noi0_matrix = Alpha_KGD(X_train, y_train_noise0, dim, n_T, step_size)[:, :-1] # (D, T+1)
#
#     # 先求出noise=0.0时的最好的t_star_noi0,按照什么求呢，L2 norm
#     t_star_L2 = Hold_out_L2norm(X_train_L, y_train_noise0_L, dim, total_steps, step_size) # t的index对应的就是t的值
#     C_t_star_noi0_vertor = C_t_noi0_matrix[:, int(t_star_L2)] # (D,)
#     C_t_star_noi0_vertor = np.reshape(C_t_star_noi0_vertor, (n_D, 1), order='A')  # (D, 1)
#     C_t_star_noi0_matrix = np.repeat(C_t_star_noi0_vertor, n_T + 1, axis=1)  # # (D, T+1)
#
#     C_diff_matrix = C_t_matrix - C_t_star_noi0_matrix # (D, T+1)
#     C_diff_matrix_T = C_diff_matrix.T  # (T+1, D)
#
#     # for norm_k
#     norm_k_square_matirx = np.dot(np.dot(C_diff_matrix_T, ker), C_diff_matrix)  # (T+1, T+1)
#     norm_k_square_matirx[norm_k_square_matirx < 0] = 0  # 对角线上的元素保持不变就好
#     norm_k_matrix = np.sqrt(norm_k_square_matirx)
#     norm_k_matrix_diag = np.diagonal(norm_k_matrix) # 提取对角线上的元素 T+1个  (T, )
#     t_star_knorm = np.argmin(norm_k_matrix_diag) # 返回的index正好是我们要找的step
#     min_knorm = min(norm_k_matrix_diag)
#     return t_star_knorm, min_knorm
#
#
# def Test_error_KGD_HO(X_train, y_train, y_train_noise0, dim, split_L, step_size):
#     total_steps = len(X_train)
#     random.seed(1)
#     random_train = random.sample(list(range(len(X_train))), split_L)  # size为L的training data
#     random_validation = [element for element in list(range(len(X_train))) if element not in random_train] # size为|D|-L的validation data
#     X_train_L, X_validation_L = X_train[random_train], X_train[random_validation]  # 长度分别是L, |D|-L
#     y_train_L, y_validation_L = y_train[random_train], y_train[random_validation]
#     y_train_noise0_L, y_validation_noise0_L = y_train_noise0[random_train], y_train_noise0[random_validation]
#
#     t_star_knorm, min_knorm = HO_knorm(X_train, y_train, y_train_noise0, X_train_L, y_train_noise0_L, dim, step_size, total_steps)
#
#
#     return t_star_knorm, min_knorm


def HO_knorm(X_train_L, y_train_L, y_train_noise0_L, dim, step_size, total_steps):
    n_T = total_steps
    n_D = len(X_train_L)
    ker = kernel_matrix_dim_1(X_train_L, X_train_L) if dim == 1 else kernel_matrix_dim_3(X_train_L, X_train_L)  # (D, D)
    C_t_matrix = Alpha_KGD(X_train_L, y_train_L, dim, n_T, step_size)[:, :-1]  # 只取t=0,1,2..., T
    C_t_noi0_matrix = Alpha_KGD(X_train_L, y_train_noise0_L, dim, n_T, step_size)[:, :-1]  # (D, T+1)

    # 第一步：L个无噪音样本上，l2 norm 意义下的最好的t
    t_star_L2 = Hold_out_L2norm(X_train_L, y_train_noise0_L, dim, total_steps, step_size)  # t的index对应的就是t的值
    C_t_star_noi0_vertor = C_t_noi0_matrix[:, int(t_star_L2)]  # (D,)
    C_t_star_noi0_vertor = np.reshape(C_t_star_noi0_vertor, (n_D, 1), order='A')  # (D, 1)
    C_t_star_noi0_matrix = np.repeat(C_t_star_noi0_vertor, n_T + 1, axis=1)  # # (D, T+1)

    C_diff_matrix = C_t_matrix - C_t_star_noi0_matrix  # (D, T+1)
    C_diff_matrix_T = C_diff_matrix.T  # (T+1, D)

    # 第二步： L个有噪音样本上，knorm意义下的最好的t
    norm_k_square_matirx = np.dot(np.dot(C_diff_matrix_T, ker), C_diff_matrix)  # (T+1, T+1)
    norm_k_square_matirx[norm_k_square_matirx < 0] = 0  # 对角线上的元素保持不变就好
    norm_k_matrix = np.sqrt(norm_k_square_matirx)
    norm_k_matrix_diag = np.diagonal(norm_k_matrix)  # 提取对角线上的元素 T+1个  (T, )
    t_star_knorm = np.argmin(norm_k_matrix_diag)  # 返回的index正好是我们要找的step
    return t_star_knorm, t_star_L2


def Test_error_KGD_HO(X_train, y_train, y_train_noise0, dim, split_L, step_size):
    total_steps = len(X_train)
    random.seed(1)
    random_train = random.sample(list(range(len(X_train))), split_L)  # size为L的training data
    random_validation = [element for element in list(range(len(X_train))) if element not in random_train]  # size为|D|-L的validation data
    X_train_L, X_validation_L = X_train[random_train], X_train[random_validation]  # 长度分别是L, |D|-L
    y_train_L, y_validation_L = y_train[random_train], y_train[random_validation]
    y_train_noise0_L, y_validation_noise0_L = y_train_noise0[random_train], y_train_noise0[random_validation]

    t_star_knorm, t_star_L2 = HO_knorm(X_train_L, y_train_L, y_train_noise0_L, dim, step_size, total_steps)

    # 第三步：计算在全数据上的k norm
    ker = kernel_matrix_dim_1(X_train, X_train) if dim == 1 else kernel_matrix_dim_3(X_train, X_train)  # (D, D)
    C_t_matrix = Alpha_KGD(X_train, y_train, dim, total_steps, step_size)[:, :-1]  # 只取t=0,1,2..., T

    C_t_star_noi_vertor = C_t_matrix[:, int(t_star_knorm)]
    C_t_star_noi_vertor = np.reshape(C_t_star_noi_vertor, (total_steps, 1), order='A')  # (D, 1)

    C_t_star_noi0_vertor = C_t_matrix[:, int(t_star_L2)]
    C_t_star_noi0_vertor = np.reshape(C_t_star_noi0_vertor, (total_steps, 1), order='A')  # (D, 1)

    C_diff_noi_noi0 = C_t_star_noi_vertor - C_t_star_noi0_vertor
    C_diff_noi_noi0_T = C_diff_noi_noi0.T
    k_norm_value = np.dot(np.dot(C_diff_noi_noi0_T, ker), C_diff_noi_noi0)  # (T+1, T+1)

    return t_star_knorm, k_norm_value





# def Hold_out(X_train, y_train, dim, step_size):
#     split_L = int(len(X_train) * 0.5)
#     random.seed(1)
#     random_train = random.sample(list(range(len(X_train))), split_L)
#     random_validation = [element for element in list(range(len(X_train))) if element not in random_train]
#
#     X_train_L, X_validation_L = X_train[random_train], X_train[random_validation]
#     y_train_L, y_validation_L = y_train[random_train], y_train[random_validation]
#
#     pred_alpha = Alpha_KGD(X_train_L, y_train_L, dim, len(X_train_L), step_size)
#     pred_alpha = pred_alpha[:, :-1]
#     average_error_list = []
#     if dim == 1:
#         # print()
#         pred_ker = kernel_matrix_dim_1(X_train_L, X_validation_L)  # (n, n)
#         for i in range(len(X_train_L)+1):
#             y_fit = np.dot(pred_ker, pred_alpha[:, i])
#             y_fit = np.squeeze(y_fit)
#             y_validation_L = np.squeeze(y_validation_L)
#
#             average_error = np.sum((y_fit - y_validation_L) ** 2) / len(X_validation_L)
#             average_error_list.append(math.sqrt(average_error))
#
#     else:
#         pred_ker = kernel_matrix_dim_3(X_train_L, X_validation_L)
#         for i in range(len(X_train_L)+1):
#             # print(i)
#             y_fit = np.dot(pred_ker, pred_alpha[:, i])
#             y_fit = np.squeeze(y_fit)
#             average_error = np.sum((y_fit - y_validation_L) ** 2) / len(X_validation_L)
#             average_error_list.append(math.sqrt(average_error))
#
#     index = average_error_list.index(min(average_error_list))
#     t_star = list(range(len(X_train_L)+1))[index]
#     # print(list(range(len(X_train_L)+1)))
#     # print('t_star:', t_star)
#     return t_star













































''' ---------------------------------------------- K norm 使用 ----------------------------------------------'''





# time_start = time.time()
# dim = 1
# step_size = 1
# np.random.seed(10)
# delta_ = 0.9
# noise_var = 0.2
# train_size = 1000
# split_L = int(train_size * 0.7)
# train, test = (train_size, dim), (200, dim)
# X_train, y_train, X_test, y_test = generate_data(train, test, dim, noise_var)
#
# # t_star, test_error = Test_error_KGD_HO(X_train, y_train, X_test, y_test, dim, step_size)
# # print('-----------------------------------------------------final test error----------------------------------------------------- ')
# # print('t_star, test_error', t_star, test_error)
# # time_total = time.time() - time_start
# # print('runing time:', time_total)
#
#
# t_star_L2, test_error_L2, t_star_Linfinity, test_error_Linfinity = Test_error_KGD_HO(X_train, y_train, X_test, y_test, dim, step_size)
# print('-----------------------------------------------------final test error----------------------------------------------------- ')
# print('t_star_L2, test_error_L2, t_star_Linfinity, test_error_Linfinity', t_star_L2, test_error_L2, t_star_Linfinity, test_error_Linfinity)
# time_total = time.time() - time_start
# print('runing time:', time_total)
# # # t_star_L2, test_error_L2, t_star_Linfinity, test_error_Linfinity 381 0.015120844963091178 254 0.0493194533918363
# # # runing time: 0.1732957363128662
