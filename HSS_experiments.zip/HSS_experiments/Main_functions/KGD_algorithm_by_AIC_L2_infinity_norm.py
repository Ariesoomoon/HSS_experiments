import pandas as pd
from numpy import *
import numpy as np
import math
import h5py
from sklearn.model_selection import KFold
import os, time
time_start = time.time()
import random
import matplotlib.pyplot as plt
import sys, gc
import torch
import numpy.linalg as la

'''------------------------------------------------定义核函数------------------------------------------------'''
def kernel_matrix_dim_1(x, y):
    n,t = len(x), len(y)
    mat_1 = np.ones((t,n))
    y_1 = np.reshape(y, (t, 1), order='A')  # (t, 1)
    y_1 = np.repeat(y_1, n, axis=1)         # (t, n)
    x_1 = np.reshape(x, (1, n), order='A')  # (1, n)
    x_1 = np.repeat(x_1, t, axis=0)         # (t, n)
    kermatrix = np.minimum(x_1, y_1) + mat_1
    return kermatrix

def func_kernel_dim_3(x):
    if x >= 0 and x <= 1:
        result = (1 - x) ** 4 * (4*x+1)
    else:
        result = 0.0
    return result

# (2) gaussian kernel
def gaussian_k(x):
    result = math.exp(-x**2)
    return result

def kernel_matrix_dim_3(x, y):
    n, t = len(x), len(y)
    y_1 = np.reshape(y, (t, 1, 3))
    y_1 = np.repeat(y_1, n, axis=1)  # (t,n,3)
    x_1 = np.reshape(x, (1, n, 3))
    x_1 = np.repeat(x_1, t, axis=0)  # (t,n,3)
    dis = x_1 - y_1
    dis_norm = np.linalg.norm(dis, axis=2)   # (t,n)
    # for kernel defined in "h3_k()"
    h3_k_vector = np.vectorize(func_kernel_dim_3)
    kermatrix = h3_k_vector(dis_norm)
    return kermatrix

'''------------------------------------------------定义回归函数------------------------------------------------'''
def func_dim_1(x):
    if x>=0 and x<=0.5:
        result=x
    else:
        result=1-x
    return result

def create_y_func_dim_1(x):
    func_dim_1_vector = np.vectorize(func_dim_1)
    y = func_dim_1_vector(x)      # (6,n)
    return y


def func_dim_3(norm_x):
    if norm_x>=0 and norm_x<=1:
        result=(1-norm_x)**6 * (35*norm_x**2 + 18*norm_x + 3)
    else:
        result=0
    return result


def create_y_func_dim_3(x):
    norm_x = np.linalg.norm(x, axis=1)
    func_dim_3_vector = np.vectorize(func_dim_3)
    y = func_dim_3_vector(norm_x)      # (6,n)
    return y


'''------------------------------------------------采集样本------------------------------------------------'''
def sample(train_size, test_size,  dim, noise_var):
    X_train = np.random.uniform(0.0, 1.0, train_size)
    X_test = np.random.uniform(0.0, 1.0, test_size)
    truncated_noise_value = 0.4
    if dim == 1:
        noise = np.random.normal(0, noise_var, train_size)
        noise_clipped = np.clip(noise, -truncated_noise_value, truncated_noise_value)
        y_train = create_y_func_dim_1(X_train) + noise # or noise_clipped
        y_test = create_y_func_dim_1(X_test)
    else: # d=3
        noise = np.random.normal(0, noise_var, train_size[0])
        noise_clipped = np.clip(noise, -truncated_noise_value, truncated_noise_value)
        y_train = create_y_func_dim_3(X_train) + noise # or noise_clipped
        y_test = create_y_func_dim_3(X_test)
    return X_train.shape, y_train.shape, X_train, y_train, X_test.shape, y_test.shape, X_test, y_test


def generate_data(train, test, dim, noise_var):
    print('------------------------------------------------------------------------------------------------------ noise_var:', noise_var)
    samples = sample(train, test, dim, noise_var)
    X_train, y_train, X_test, y_test = samples[2], samples[3], samples[6], samples[7]
    print('------------------------------From dim = %s ------------------------------------------' % dim)
    print('Train set X:%s, y:%s  |  Test set X:%s, y:%s' % (samples[0], samples[1], samples[4], samples[5]))
    return X_train, y_train, X_test, y_test


'''------------------------------------------------计算有效维------------------------------------------------'''
# 计算有效维，快速计算，直接计算出所有steps的有效维
def effective_dim(X_tra, dim, T_upper):
    ker = kernel_matrix_dim_1(X_tra, X_tra) if dim == 1 else kernel_matrix_dim_3(X_tra, X_tra)
    U, S, V = np.linalg.svd(ker)

    step_t_list = list(range(1, T_upper + 1, 1))
    step_t_array = np.array(step_t_list)
    n_s, n_t = S.shape[0], step_t_array.shape[0]

    step_t_array = np.reshape(step_t_array, (n_t, 1)) # (n_t, 1)
    step_t_array = np.repeat(step_t_array, n_s, axis=1) # (n_t, n_s)
    step_t_array = step_t_array.T   # (n_s, n_t)

    S_new = np.reshape(S, (n_s, 1)) # (n_s, 1)
    S_new = np.repeat(S_new, n_t, axis=1) # (n_s, n_t)

    S_parameter = S_new/(S_new + (1/step_t_array) * n_s) #
    effect_dim = np.sum(S_parameter, axis = 0)
    return effect_dim





'''-------------------------------计算 KGD的系数alpha(对应论文中的c_t, 默认c_0=(0,...,0))和核矩阵ker ------------------------------------'''
def Alpha_KGD_vector(X_train, y_tra, dim, step_t, step_size):
    ker = kernel_matrix_dim_1(X_train, X_train) if dim == 1 else kernel_matrix_dim_3(X_train, X_train)
    n = len(X_train)
    y_tra = np.reshape(y_tra, (n, 1))
    alpha = np.reshape(np.zeros(n), (n, 1))
    # for i in range(step_t + 1): # 应该改为step_t，此时对应才是c_t
    for i in range(step_t):
        alpha = alpha + (step_size / n) * (y_tra - np.dot(ker, alpha)) # t=1,...,t # i=0,计算的是t=1时的结果
    return alpha


def Predicted_KGD(X_train, y_tra, x_tes, y_tes, dim, step_t, step_size): # 计算的实际上是t=step_t+1时对用的结果
    y_tes = np.squeeze(y_tes)
    n, t = len(X_train), len(x_tes)
    pred_alpha = Alpha_KGD_vector(X_train, y_tra, dim, step_t, step_size)  # (n, 1)
    if dim == 1:
        pred_ker = kernel_matrix_dim_1(X_train, x_tes)  # (n, n)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)

    else:
        pred_ker = kernel_matrix_dim_3(X_train, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)

    average_error = np.sum((y_fit - y_tes) ** 2) / t
    kgd_L2_error = math.sqrt(average_error)
    kgd_Linfinity_error = np.max(np.abs(y_fit - y_tes))
    return y_fit, kgd_L2_error, kgd_Linfinity_error


def Alpha_KGD(X_train, y_tra, dim, step_t, step_size):
    ker = kernel_matrix_dim_1(X_train, X_train) if dim == 1 else kernel_matrix_dim_3(X_train, X_train)
    # U, S, V = np.linalg.svd(ker)
    # step_size = 1 / np.max(S)
    n = len(X_train)
    y_tra = np.reshape(y_tra, (n, 1))
    alpha = np.reshape(np.zeros(n), (n, 1))
    alpha_matrix = np.empty(shape=(n, step_t+2))  # alpha_0, alpha_1, ..., alpha_t, alpha_t+1
    alpha_matrix[:, 0] = np.squeeze(alpha)  # 先存alpha_0
    for i in range(step_t + 1):
        alpha = alpha + (step_size / n) * (y_tra - np.dot(ker, alpha))
        alpha_matrix[:, i+1] = np.squeeze(alpha) # i=0时,存的是alpha_1， i=step_t时,存的是alpha_t+1，
    return alpha_matrix  # (n, t+2)



from sklearn.linear_model import LinearRegression
def noise_estimator(data):
    # 拟合一个线性模型（或其他模型），并计算残差
    X = np.arange(len(data)).reshape(-1, 1)
    model = LinearRegression().fit(X, data)
    fitted_values = model.predict(X)
    # 计算残差
    residuals = data - fitted_values
    # 计算噪音标准差
    noise_std = np.std(residuals)
    noise_std = noise_std ** 2
    return noise_std


def Baseline(X_train, y_train, X_test, y_test, dim, split_L, step_size):
    total_steps = len(X_train)
    X_train_L, y_train_L = X_train, y_train
    pred_alpha = Alpha_KGD(X_train_L, y_train_L, dim, total_steps, step_size)
    pred_alpha = pred_alpha[:, :-1]
    L2_error_list, Linfinity_error_list = [], []
    if dim == 1:
        pred_ker = kernel_matrix_dim_1(X_train_L, X_test)  # (n, n)
        for i in range(total_steps + 1):
            y_fit = np.dot(pred_ker, pred_alpha[:, i])
            y_fit = np.squeeze(y_fit)
            y_test = np.squeeze(y_test)
            # L2_norm
            L2_error = np.sum((y_fit - y_test) ** 2) / len(X_test)
            L2_error_list.append(math.sqrt(L2_error))
            # Linfinity_norm
            Linfinity_error = np.max(np.abs(y_fit - y_test))
            Linfinity_error_list.append(Linfinity_error)
    else:
        pred_ker = kernel_matrix_dim_3(X_train_L, X_test)
        for i in range(total_steps + 1):
            # print(i)
            y_fit = np.dot(pred_ker, pred_alpha[:, i])
            y_fit = np.squeeze(y_fit)
            # L2_norm
            L2_error = np.sum((y_fit - y_test) ** 2) / len(X_test)
            L2_error_list.append(math.sqrt(L2_error))
            # Linfinity_norm
            Linfinity_error = np.max(np.abs(y_fit - y_test))
            Linfinity_error_list.append(Linfinity_error)

    index_L2 = L2_error_list.index(min(L2_error_list))
    t_star_L2 = list(range(total_steps + 1))[index_L2]
    min_error_L2 = min(L2_error_list)
    index_Linfinity = Linfinity_error_list.index(min(Linfinity_error_list))
    t_star_Linfinity = list(range(total_steps + 1))[index_Linfinity]
    min_error_Linfinity = min(Linfinity_error_list)
    return t_star_L2, min_error_L2, t_star_Linfinity, min_error_Linfinity


def DP_left_right_calculation(X_train, y_tra, dim, total_steps, step_size):
    pred_alpha = Alpha_KGD(X_train, y_tra, dim, total_steps, step_size)
    pred_alpha = pred_alpha[:, :-1]
    L2_error_square_list = []
    y_test = np.squeeze(y_tra)
    if dim == 1:
        pred_ker = kernel_matrix_dim_1(X_train, X_train)  # (n, n)
        for i in range(total_steps + 1):
            y_fit = np.dot(pred_ker, pred_alpha[:, i])
            y_fit = np.squeeze(y_fit)
            # L2_norm
            L2_error = np.sum((y_fit - y_test) ** 2) / len(y_test)
            L2_error_square_list.append(L2_error)
    else:
        pred_ker = kernel_matrix_dim_3(X_train, X_train)
        for i in range(total_steps + 1):
            # print(i)
            y_fit = np.dot(pred_ker, pred_alpha[:, i])
            y_fit = np.squeeze(y_fit)
            # L2_norm
            L2_error = np.sum((y_fit - y_test) ** 2) / len(y_test)
            L2_error_square_list.append(L2_error)

    # DP的左边：
    DP_left = L2_error_square_list
    # DP的右边：
    DP_right_noise_estimate = noise_estimator(y_tra)

    return DP_left, DP_right_noise_estimate



def W_D_t(X_train, dim, T_upper):
    w_d_t_list = []
    effect_dim = effective_dim(X_train, dim, T_upper)
    for step_t in range(1, T_upper + 1):
        w_d_t = np.sqrt(step_t) / len(X_train) + np.sqrt(max(effect_dim[step_t-1], 1)) * (1 + np.sqrt(step_t / len(X_train))) / np.sqrt(len(X_train))
        w_d_t_list.append(w_d_t) # 对应t=1, 2, ..., T
    return w_d_t_list





def AIC_left_right_calculation(X_train, y_tra, dim, total_steps, step_size):
    pred_alpha = Alpha_KGD(X_train, y_tra, dim, total_steps, step_size)
    pred_alpha = pred_alpha[:, :-1]
    L2_error_square_list = []
    y_test = np.squeeze(y_tra)
    if dim == 1:
        pred_ker = kernel_matrix_dim_1(X_train, X_train)  # (n, n)
        for i in range(total_steps + 1):
            y_fit = np.dot(pred_ker, pred_alpha[:, i])
            y_fit = np.squeeze(y_fit)
            # L2_norm
            L2_error = np.sum((y_fit - y_test) ** 2) / len(y_test)
            L2_error_square_list.append(L2_error)
    else:
        pred_ker = kernel_matrix_dim_3(X_train, X_train)
        for i in range(total_steps + 1):
            # print(i)
            y_fit = np.dot(pred_ker, pred_alpha[:, i])
            y_fit = np.squeeze(y_fit)
            # L2_norm
            L2_error = np.sum((y_fit - y_test) ** 2) / len(y_test)
            L2_error_square_list.append(L2_error)

    # AIC的第一部分
    AIC_left = L2_error_square_list[1:] # 0,1,...,T, T+1
    # AIC的第二部分 W_dt
    w_d_t_list= W_D_t(X_train, dim, total_steps)
    AIC_right = [x * 2 for x in w_d_t_list]


    return AIC_left, AIC_right







def BIC_left_right_calculation(X_train, y_tra, dim, total_steps, step_size):
    pred_alpha = Alpha_KGD(X_train, y_tra, dim, total_steps, step_size)
    pred_alpha = pred_alpha[:, :-1]
    L2_error_square_list = []
    y_test = np.squeeze(y_tra)
    if dim == 1:
        pred_ker = kernel_matrix_dim_1(X_train, X_train)  # (n, n)
        for i in range(total_steps + 1):
            y_fit = np.dot(pred_ker, pred_alpha[:, i])
            y_fit = np.squeeze(y_fit)
            # L2_norm
            L2_error = np.sum((y_fit - y_test) ** 2) / len(y_test)
            L2_error_square_list.append(L2_error)
    else:
        pred_ker = kernel_matrix_dim_3(X_train, X_train)
        for i in range(total_steps + 1):
            # print(i)
            y_fit = np.dot(pred_ker, pred_alpha[:, i])
            y_fit = np.squeeze(y_fit)
            # L2_norm
            L2_error = np.sum((y_fit - y_test) ** 2) / len(y_test)
            L2_error_square_list.append(L2_error)

    # BIC的第一部分
    BIC_left = L2_error_square_list[1:] # 0,1,...,T, T+1
    # BIC的第二部分 W_dt
    w_d_t_list = W_D_t(X_train, dim, total_steps)
    a1 = [x * total_steps for x in w_d_t_list]
    BIC_right = [2 * math.log10(x) for x in a1]
    # BIC_right = [0 * x for x in a1]

    return BIC_left, BIC_right


def AIC_principle(AIC_left, AIC_right, C_AIC, total_steps):
    AIC_right_with_C = [x * C_AIC for x in AIC_right]
    AIC_value_list = [a + b for a, b in zip(AIC_left, AIC_right_with_C)]

    # print(AIC_left)  # [0.3858626346563856, 0.3792001319758232, 0.3774491478093472, 0.3763415648417967, 0.375384868113675, 0.37451390963260656,
    # print(AIC_right)  # [0.0672455532033676, 0.06890240745285997, 0.07625408650199375, 0.08191228708971263, 0.08663664593496737, 0.09076020636160448,
    # print(AIC_right_with_C)  #
    # print(AIC_value_list)  # [0.4531081878597532, 0.44810253942868317, 0.45370323431134096, 0.45825385193150936, 0.46202151404864233, 0.46527411599421103

    # t=infAIC
    index_L2 = AIC_value_list.index(min(AIC_value_list))
    # print(index_L2)
    t_star_L2 = list(range(total_steps + 1))[index_L2]

    return t_star_L2



def BIC_principle(BIC_left, BIC_right, C_BIC, total_steps):
    BIC_right_with_C = [x * C_BIC for x in BIC_right]
    BIC_value_list = [a + b for a, b in zip(BIC_left, BIC_right_with_C)]

    print(BIC_left)       # [0.3858626346563856, 0.3792001319758232, 0.3774491478093472, 0.3763415648417967, 0.375384868113675, 0.37451390963260656,
    print(BIC_right)      # [3.053267150092549, 3.0744088015504722, 3.162466254157829, 3.224638112925882, 3.2733432698647422, 3.3137309580119862,
    print(BIC_right_with_C)
    print(BIC_value_list) # [3.4391297847489346, 3.4536089335262954, 3.539915401967176, 3.600979677767679, 3.6487281379784173, 3.6882448676445927,

    # t=infBIC
    index_L2 = BIC_value_list.index(min(BIC_value_list))
    print(index_L2)
    t_star_L2 = list(range(total_steps + 1))[index_L2]

    return t_star_L2




def select_c_AIC(X_train_L, y_train_L, dim, step_size, split_L_tr, total_steps, log_filename, C_AIC_list):
    random.seed(1)
    random_train = random.sample(list(range(len(X_train_L))), split_L_tr)  # size为L的training data
    random_validation = [element for element in list(range(len(X_train_L))) if element not in random_train] # size为|D|-L的validation data
    X_train_L_tr, X_train_L_val = X_train_L[random_train], X_train_L[random_validation]  # 长度分别是L, |D|-L
    y_train_L_tr, y_train_L_val = y_train_L[random_train], y_train_L[random_validation]

    AIC_left, AIC_right_WC = AIC_left_right_calculation(X_train_L_tr, y_train_L_tr, dim, total_steps, step_size)
    L2_norm_error_list, Linfty_norm_error_list, select_t_list = [], [], []

    for C_1 in C_AIC_list:
        print('C_1:', C_1)
        select_t = AIC_principle(AIC_left, AIC_right_WC, C_1, total_steps)
        select_t_list.append(select_t)
        _, L2_norm_error, Linfty_norm_error = Predicted_KGD(X_train_L_tr, y_train_L_tr, X_train_L_val, y_train_L_val, dim, select_t, step_size)
        L2_norm_error_list.append(L2_norm_error)
        Linfty_norm_error_list.append(Linfty_norm_error)

    index_L2norm = L2_norm_error_list.index(min(L2_norm_error_list))
    index_Linftynorm = Linfty_norm_error_list.index(min(Linfty_norm_error_list))
    L2_C, L2_t, L2_min_error = C_AIC_list[index_L2norm], select_t_list[index_L2norm], min(L2_norm_error_list)
    Linfinity_C, Linfinity_t, Linfinity_min_error = C_AIC_list[index_Linftynorm], select_t_list[index_Linftynorm], min(Linfty_norm_error_list)
    return L2_C, L2_t, L2_min_error, Linfinity_C, Linfinity_t, Linfinity_min_error



def select_c_BIC(X_train_L, y_train_L, dim, step_size, split_L_tr, total_steps, log_filename, C_BIC_list):
    random.seed(1)
    random_train = random.sample(list(range(len(X_train_L))), split_L_tr)  # size为L的training data
    random_validation = [element for element in list(range(len(X_train_L))) if element not in random_train] # size为|D|-L的validation data
    X_train_L_tr, X_train_L_val = X_train_L[random_train], X_train_L[random_validation]  # 长度分别是L, |D|-L
    y_train_L_tr, y_train_L_val = y_train_L[random_train], y_train_L[random_validation]

    BIC_left, BIC_right_WC = BIC_left_right_calculation(X_train_L_tr, y_train_L_tr, dim, total_steps, step_size)
    L2_norm_error_list, Linfty_norm_error_list, select_t_list = [], [], []

    for C_1 in C_BIC_list:
        print('C_1:', C_1)
        select_t = BIC_principle(BIC_left, BIC_right_WC, C_1, total_steps)
        select_t_list.append(select_t)
        _, L2_norm_error, Linfty_norm_error = Predicted_KGD(X_train_L_tr, y_train_L_tr, X_train_L_val, y_train_L_val, dim, select_t, step_size)
        L2_norm_error_list.append(L2_norm_error)
        Linfty_norm_error_list.append(Linfty_norm_error)

    index_L2norm = L2_norm_error_list.index(min(L2_norm_error_list))
    index_Linftynorm = Linfty_norm_error_list.index(min(Linfty_norm_error_list))
    L2_C, L2_t, L2_min_error = C_BIC_list[index_L2norm], select_t_list[index_L2norm], min(L2_norm_error_list)
    Linfinity_C, Linfinity_t, Linfinity_min_error = C_BIC_list[index_Linftynorm], select_t_list[index_Linftynorm], min(Linfty_norm_error_list)
    return L2_C, L2_t, L2_min_error, Linfinity_C, Linfinity_t, Linfinity_min_error



def select_t_final_byAIC(X_train, y_train, X_train_L, y_train_L, dim, step_size, split_L_tr, total_steps, log_filename, C_bsp_list):
    L2_C, _, _, Linfinity_C, _, _ = select_c_AIC(X_train_L, y_train_L, dim, step_size, split_L_tr, total_steps, log_filename, C_bsp_list)
    BSP_left, BSP_right_W = AIC_left_right_calculation(X_train, y_train, dim, total_steps, step_size)
    L2_t_star = AIC_principle(BSP_left, BSP_right_W, L2_C, total_steps)
    Linfinity_t_star = AIC_principle(BSP_left, BSP_right_W, Linfinity_C, total_steps)
    return L2_C, L2_t_star, Linfinity_C, Linfinity_t_star


def select_t_final_byBIC(X_train, y_train, X_train_L, y_train_L, dim, step_size, split_L_tr, total_steps, log_filename, C_bsp_list):
    L2_C, _, _, Linfinity_C, _, _ = select_c_BIC(X_train_L, y_train_L, dim, step_size, split_L_tr, total_steps, log_filename, C_bsp_list)
    BSP_left, BSP_right_W = BIC_left_right_calculation(X_train, y_train, dim, total_steps, step_size)
    L2_t_star = BIC_principle(BSP_left, BSP_right_W, L2_C, total_steps)
    Linfinity_t_star = BIC_principle(BSP_left, BSP_right_W, Linfinity_C, total_steps)
    return L2_C, L2_t_star, Linfinity_C, Linfinity_t_star



def Test_error_KGD_AIC(X_train, y_train, X_test, y_test, dim, step_size, split_L, split_L_tr, log_filename, C_bsp_list):
    total_steps = len(X_train)
    random.seed(1)
    random_train = random.sample(list(range(len(X_train))), split_L)  # size为L的training data
    random_validation = [element for element in list(range(len(X_train))) if element not in random_train] # size为|D|-L的validation data
    X_train_L, X_validation_L = X_train[random_train], X_train[random_validation]  # 长度分别是L, |D|-L
    y_train_L, y_validation_L = y_train[random_train], y_train[random_validation]

    L2_C, L2_t_star, Linfinity_C, Linfinity_t_star = select_t_final_byAIC(X_train, y_train, X_train_L, y_train_L, dim, step_size, split_L_tr, total_steps, log_filename, C_bsp_list)

    L2_test_error = Predicted_KGD(X_train, y_train, X_test, y_test, dim, L2_t_star, step_size)[1]
    Linfinity_test_error = Predicted_KGD(X_train, y_train, X_test, y_test, dim, Linfinity_t_star, step_size)[2]
    return L2_C, L2_t_star, L2_test_error, Linfinity_C, Linfinity_t_star, Linfinity_test_error




def Test_error_KGD_BIC(X_train, y_train, X_test, y_test, dim, step_size, split_L, split_L_tr, log_filename, C_bsp_list):
    total_steps = len(X_train)
    random.seed(1)
    random_train = random.sample(list(range(len(X_train))), split_L)  # size为L的training data
    random_validation = [element for element in list(range(len(X_train))) if element not in random_train] # size为|D|-L的validation data
    X_train_L, X_validation_L = X_train[random_train], X_train[random_validation]  # 长度分别是L, |D|-L
    y_train_L, y_validation_L = y_train[random_train], y_train[random_validation]

    L2_C, L2_t_star, Linfinity_C, Linfinity_t_star = select_t_final_byBIC(X_train, y_train, X_train_L, y_train_L, dim, step_size, split_L_tr, total_steps, log_filename, C_bsp_list)

    L2_test_error = Predicted_KGD(X_train, y_train, X_test, y_test, dim, L2_t_star, step_size)[1]
    Linfinity_test_error = Predicted_KGD(X_train, y_train, X_test, y_test, dim, Linfinity_t_star, step_size)[2]
    return L2_C, L2_t_star, L2_test_error, Linfinity_C, Linfinity_t_star, Linfinity_test_error




#
# time_start = time.time()
# dim = 3
# step_size = 3
# np.random.seed(15)
# delta_ = 0.9
# noise_var = 0.6
# train_size = 1000
# split_L_tr_per = 0.7
# split_L_per = 1
# split_L = int(train_size * split_L_per)
# split_L_tr = int(split_L * split_L_tr_per)
#
# train, test = (train_size, dim), (200, dim)
#
# log_filename = 22
#
# C_bsp_list = C_bsp_list = [0.00001, 0.0001, 0.001, 0.01] + [i * 0.2 for i in range(1, 31, 1)]  # d=1
# X_train, y_train, X_test, y_test = generate_data(train, test, dim, noise_var)
# L2_C, L2_t_star, L2_test_error, Linfinity_C, Linfinity_t_star, Linfinity_test_error = Test_error_KGD_AIC(X_train, y_train, X_test, y_test, dim, step_size, split_L, split_L_tr, log_filename, C_bsp_list)
#
# print('-----------------------------------------------------final test error----------------------------------------------------- ')
# print('L2_C, L2_t_star, L2_test_error', (L2_C, L2_t_star, L2_test_error))
# print('Linfinity_C, Linfinity_t_star, Linfinity_test_error', (Linfinity_C, Linfinity_t_star, Linfinity_test_error))
# time_total = time.time() - time_start
# print('runing time:', time_total)
