import pandas as pd
from numpy import *
import numpy as np
import math
import h5py
from sklearn.model_selection import KFold
import os, time
time_start = time.time()
import random
import matplotlib.pyplot as plt


'''------------------------------------------------定义核函数------------------------------------------------'''
def kernel_matrix_dim_1(x, y):
    n,t = len(x), len(y)
    mat_1 = np.ones((t,n))
    y_1 = np.reshape(y, (t, 1), order='A')  # (t, 1)
    y_1 = np.repeat(y_1, n, axis=1)         # (t, n)
    x_1 = np.reshape(x, (1, n), order='A')  # (1, n)
    x_1 = np.repeat(x_1, t, axis=0)         # (t, n)
    kermatrix = np.minimum(x_1, y_1) + mat_1
    return kermatrix

def func_kernel_dim_3(x):
    if x >= 0 and x <= 1:
        result = (1 - x) ** 4 * (4*x+1)
    else:
        result = 0.0
    return result

# (2) gaussian kernel
def gaussian_k(x):
    result = math.exp(-x**2)
    return result

def kernel_matrix_dim_3(x, y):
    n, t = len(x), len(y)
    y_1 = np.reshape(y, (t, 1, 3))
    y_1 = np.repeat(y_1, n, axis=1)  # (t,n,3)
    x_1 = np.reshape(x, (1, n, 3))
    x_1 = np.repeat(x_1, t, axis=0)  # (t,n,3)
    dis = x_1 - y_1
    dis_norm = np.linalg.norm(dis, axis=2)   # (t,n)
    # for kernel defined in "h3_k()"
    h3_k_vector = np.vectorize(func_kernel_dim_3)
    kermatrix = h3_k_vector(dis_norm)
    return kermatrix

'''------------------------------------------------定义回归函数------------------------------------------------'''
def func_dim_1(x):
    if x>=0 and x<=0.5:
        result=x
    else:
        result=1-x
    return result

def create_y_func_dim_1(x):
    func_dim_1_vector = np.vectorize(func_dim_1)
    y = func_dim_1_vector(x)      # (6,n)
    return y


def func_dim_3(norm_x):
    if norm_x>=0 and norm_x<=1:
        result=(1-norm_x)**6 * (35*norm_x**2 + 18*norm_x + 3)
    else:
        result=0
    return result


def create_y_func_dim_3(x):
    norm_x = np.linalg.norm(x, axis=1)
    func_dim_3_vector = np.vectorize(func_dim_3)
    y = func_dim_3_vector(norm_x)      # (6,n)
    return y


'''------------------------------------------------采集样本------------------------------------------------'''
def sample(train_size, test_size,  dim, noise_var):
    X_train = np.random.uniform(0.0, 1.0, train_size)
    X_test = np.random.uniform(0.0, 1.0, test_size)
    truncated_noise_value = 0.4
    if dim == 1:
        noise = np.random.normal(0, noise_var, train_size)
        noise_clipped = np.clip(noise, -truncated_noise_value, truncated_noise_value)
        y_train = create_y_func_dim_1(X_train) + noise # or noise_clipped
        y_test = create_y_func_dim_1(X_test)
    else: # d=3
        noise = np.random.normal(0, noise_var, train_size[0])
        noise_clipped = np.clip(noise, -truncated_noise_value, truncated_noise_value)
        y_train = create_y_func_dim_3(X_train) + noise # or noise_clipped
        y_test = create_y_func_dim_3(X_test)
    return X_train.shape, y_train.shape, X_train, y_train, X_test.shape, y_test.shape, X_test, y_test


def generate_data(train, test, dim, noise_var):
    samples = sample(train, test, dim, noise_var)
    X_train, y_train, X_test, y_test = samples[2], samples[3], samples[6], samples[7]
    # print('\n ########### ♣️From dim = %s | noise_var=%s | Train set X:%s, y:%s | Test set X:%s, y:%s  ##########' % (dim, noise_var, samples[0], samples[1], samples[4], samples[5]))
    return X_train, y_train, X_test, y_test



def sample_noise02(train_size, test_size, dim, noise_var):
    X_train = np.random.uniform(0.0, 1.0, train_size)
    X_test = np.random.uniform(0.0, 1.0, test_size)
    noise = np.random.normal(0, noise_var, train_size)

    if dim == 1:
        y_train = create_y_func_dim_1(X_train) + noise
        y_test = create_y_func_dim_1(X_test)

    else:  # d=3
        noise = np.random.normal(0, noise_var, train_size[0])
        y_train = create_y_func_dim_3(X_train) + noise
        y_test = create_y_func_dim_3(X_test)
    return X_train.shape, y_train.shape, X_train, y_train, X_test.shape, y_test.shape, X_test, y_test


# generate data for simulation
def generate_data_noise02(train, test, dim, noise_var):
    samples = sample_noise02(train, test, dim, noise_var)
    X_train, y_train, X_test, y_test = samples[2], samples[3], samples[6], samples[7]
    print('------------------------------From dim = %s ------------------------------------------' % dim)
    print('Train set X:%s, y:%s  |  Test set X:%s, y:%s' % (samples[0], samples[1], samples[4], samples[5]))
    return X_train, y_train, X_test, y_test


def sample_noise0(train_size, test_size, dim, noise_var):
    X_train = np.random.uniform(0.0, 1.0, train_size)
    X_test = np.random.uniform(0.0, 1.0, test_size)
    if dim == 1:
        y_train = create_y_func_dim_1(X_train)
        y_test = create_y_func_dim_1(X_test)

    else:  # d=3
        y_train = create_y_func_dim_3(X_train)
        y_test = create_y_func_dim_3(X_test)
    return X_train.shape, y_train.shape, X_train, y_train, X_test.shape, y_test.shape, X_test, y_test


# generate data for simulation
def generate_data_noise0(train, test, dim, noise_var):
    samples = sample_noise0(train, test, dim, noise_var)
    X_train, y_train, X_test, y_test = samples[2], samples[3], samples[6], samples[7]
    print('------------------------------From dim = %s ------------------------------------------' % dim)
    print('Train set X:%s, y:%s  |  Test set X:%s, y:%s' % (samples[0], samples[1], samples[4], samples[5]))
    return X_train, y_train, X_test, y_test





'''-------------------------------计算 KGD的系数alpha(对应论文中的c_t, 默认c_0=(0,...,0))和核矩阵ker ------------------------------------'''
def Alpha_KGD_vector(X_train, y_tra, dim, step_t, step_size):
    ker = kernel_matrix_dim_1(X_train, X_train) if dim == 1 else kernel_matrix_dim_3(X_train, X_train)
    n = len(X_train)

    y_tra = np.reshape(y_tra, (n, 1))
    alpha = np.reshape(np.zeros(n), (n, 1))
    # for i in range(step_t + 1): # 应该改为step_t，此时对应才是c_t
    for i in range(step_t):
        alpha = alpha + (step_size / n) * (y_tra - np.dot(ker, alpha)) # t=1,...,t # i=0,计算的是t=1时的结果
    return alpha


def Alpha_KGD(X_train, y_tra, dim, step_t, step_size):
    ker = kernel_matrix_dim_1(X_train, X_train) if dim == 1 else kernel_matrix_dim_3(X_train, X_train)
    # U, S, V = np.linalg.svd(ker)
    # step_size = 1 / np.max(S)
    n = len(X_train)
    y_tra = np.reshape(y_tra, (n, 1))
    alpha = np.reshape(np.zeros(n), (n, 1))
    alpha_matrix = np.empty(shape=(n, step_t+2))  # alpha_0, alpha_1, ..., alpha_t, alpha_t+1
    alpha_matrix[:, 0] = np.squeeze(alpha)  # 先存alpha_0
    for i in range(step_t + 1):
        alpha = alpha + (step_size / n) * (y_tra - np.dot(ker, alpha))
        alpha_matrix[:, i+1] = np.squeeze(alpha) # i=0时,存的是alpha_1， i=step_t时,存的是alpha_t+1，
    return alpha_matrix  # (n, t+2)


'''----------------------------------------------------------------baseline----------------------------------------------------------------'''
# 原来只有norm2 的
# def Baseline(X_train, y_train, X_test, y_test, dim, step_size):
#     pred_alpha = Alpha_KGD(X_train, y_train, dim, len(X_train), step_size)
#     pred_alpha = pred_alpha[:, :-1]
#     average_error_list = []
#     if dim == 1:
#         pred_ker = kernel_matrix_dim_1(X_train, X_test)  # (n, n)
#         for i in range(len(X_train)+1):
#             y_fit = np.dot(pred_ker, pred_alpha[:, i])
#             y_fit = np.squeeze(y_fit)
#             y_test = np.squeeze(y_test)
#             average_error = np.sum((y_fit - y_test) ** 2) / len(X_test)
#             average_error_list.append(math.sqrt(average_error))
#     else:
#         pred_ker = kernel_matrix_dim_3(X_train, X_test)
#         for i in range(len(X_train)+1):
#             # print(i)
#             y_fit = np.dot(pred_ker, pred_alpha[:, i])
#             y_fit = np.squeeze(y_fit)
#             average_error = np.sum((y_fit - y_test) ** 2) / len(X_test)
#             average_error_list.append(math.sqrt(average_error))
#
#     index = average_error_list.index(min(average_error_list))
#     t_star = list(range(len(X_train) + 1))[index]
#     # print('t_star:', t_star)
#     min_error = min(average_error_list)
#     return t_star, min_error


def Baseline(X_train, y_train, X_test, y_test, dim, split_L, step_size):
    total_steps = len(X_train)
    # BS应该用全部的数据来选参数，这才是BS，所以下面这几行注释
    # random.seed(1)
    # random_train = random.sample(list(range(len(X_train))), split_L)  # size为L的training data
    # random_validation = [element for element in list(range(len(X_train))) if element not in random_train]  # size为|D|-L的validation data
    # X_train_L, _ = X_train[random_train], X_train[random_validation]  # 长度分别是L, |D|-L
    # y_train_L, _ = y_train[random_train], y_train[random_validation]
    # # print(X_train_L[0:5])

    X_train_L, y_train_L = X_train, y_train

    pred_alpha = Alpha_KGD(X_train_L, y_train_L, dim, total_steps, step_size)
    pred_alpha = pred_alpha[:, :-1]
    L2_error_list, Linfinity_error_list = [], []
    if dim == 1:
        pred_ker = kernel_matrix_dim_1(X_train_L, X_test)  # (n, n)
        for i in range(total_steps + 1):
            y_fit = np.dot(pred_ker, pred_alpha[:, i])
            y_fit = np.squeeze(y_fit)
            y_test = np.squeeze(y_test)
            # L2_norm
            L2_error = np.sum((y_fit - y_test) ** 2) / len(X_test)
            L2_error_list.append(math.sqrt(L2_error))
            # Linfinity_norm
            Linfinity_error = np.max(np.abs(y_fit - y_test))
            Linfinity_error_list.append(Linfinity_error)
    else:
        pred_ker = kernel_matrix_dim_3(X_train_L, X_test)
        for i in range(total_steps + 1):
            # print(i)
            y_fit = np.dot(pred_ker, pred_alpha[:, i])
            y_fit = np.squeeze(y_fit)
            # L2_norm
            L2_error = np.sum((y_fit - y_test) ** 2) / len(X_test)
            L2_error_list.append(math.sqrt(L2_error))
            # Linfinity_norm
            Linfinity_error = np.max(np.abs(y_fit - y_test))
            Linfinity_error_list.append(Linfinity_error)

    index_L2 = L2_error_list.index(min(L2_error_list))
    t_star_L2 = list(range(total_steps + 1))[index_L2]
    min_error_L2 = min(L2_error_list)
    index_Linfinity = Linfinity_error_list.index(min(Linfinity_error_list))
    t_star_Linfinity = list(range(total_steps + 1))[index_Linfinity]
    min_error_Linfinity = min(Linfinity_error_list)
    return t_star_L2, min_error_L2, t_star_Linfinity, min_error_Linfinity


def Baseline_plot(X_train, y_train, X_test, y_test, dim, split_L, step_size):
    total_steps = len(X_train)
    # random.seed(1)
    # random_train = random.sample(list(range(len(X_train))), split_L)  # size为L的training data
    # random_validation = [element for element in list(range(len(X_train))) if element not in random_train]  # size为|D|-L的validation data
    # X_train_L, X_validation_L = X_train[random_train], X_train[random_validation]  # 长度分别是L, |D|-L
    # y_train_L, y_validation_L = y_train[random_train], y_train[random_validation]
    # print(X_train_L[0:5])

    X_train_L, y_train_L = X_train, y_train


    pred_alpha = Alpha_KGD(X_train_L, y_train_L, dim, total_steps, step_size)
    pred_alpha = pred_alpha[:, :-1]
    L2_error_list, Linfinity_error_list, step_list = [], [], []
    if dim == 1:
        pred_ker = kernel_matrix_dim_1(X_train_L, X_test)  # (n, n)
        for i in range(total_steps+1):
            # print('step:', i)
            step_list.append(i)
            y_fit = np.dot(pred_ker, pred_alpha[:, i])
            y_fit = np.squeeze(y_fit)
            y_test = np.squeeze(y_test)
            # L2_norm
            L2_error = np.sum((y_fit - y_test) ** 2) / len(X_test)
            L2_error_list.append(math.sqrt(L2_error))
            # Linfinity_norm
            Linfinity_error = np.max(np.abs(y_fit - y_test))
            Linfinity_error_list.append(Linfinity_error)

    else:
        pred_ker = kernel_matrix_dim_3(X_train_L, X_test)
        for i in range(total_steps+1):
            # print('step:', i)
            step_list.append(i)
            y_fit = np.dot(pred_ker, pred_alpha[:, i])
            y_fit = np.squeeze(y_fit)
            # L2_norm
            L2_error = np.sum((y_fit - y_test) ** 2) / len(X_test)
            L2_error_list.append(math.sqrt(L2_error))
            # Linfinity_norm
            Linfinity_error = np.max(np.abs(y_fit - y_test))
            Linfinity_error_list.append(Linfinity_error)

    return step_list, L2_error_list, Linfinity_error_list
    # return list(range(len(X_train) + 1)), average_error_list



def Baseline_plot_bias_variance(X_train, y_train, X_test, y_test, dim, split_L, step_size):
    total_steps = len(X_train)
    # random.seed(1)
    # random_train = random.sample(list(range(len(X_train))), split_L)  # size为L的training data
    # random_validation = [element for element in list(range(len(X_train))) if element not in random_train]  # size为|D|-L的validation data
    # X_train_L, X_validation_L = X_train[random_train], X_train[random_validation]  # 长度分别是L, |D|-L
    # y_train_L, y_validation_L = y_train[random_train], y_train[random_validation]

    X_train_L, y_train_L = X_train, y_train

    pred_alpha = Alpha_KGD(X_train_L, y_train_L, dim, total_steps, step_size)
    pred_alpha = pred_alpha[:, :-1]
    L2_error_list, Linfinity_error_list = [], []
    if dim == 1:
        pred_ker = kernel_matrix_dim_1(X_train_L, X_test)  # (n, n)
        for i in range(total_steps+1):
            y_fit = np.dot(pred_ker, pred_alpha[:, i])
            y_fit = np.squeeze(y_fit)
            # print('y_fit.shape:', y_fit.shape)
            # print('y_test.shape:', y_test.shape)
            y_test = np.squeeze(y_test)
            L2_error = np.sum(abs(y_fit - y_test)) / len(X_test)
            L2_error_list.append(L2_error)
            Linfinity_error = np.max(np.abs(y_fit - y_test))
            Linfinity_error_list.append(Linfinity_error)

    else:
        pred_ker = kernel_matrix_dim_3(X_train_L, X_test)
        for i in range(total_steps+1):
            # print(i)
            y_fit = np.dot(pred_ker, pred_alpha[:, i])
            y_fit = np.squeeze(y_fit)
            # print('y_fit.shape:', y_fit.shape)
            # print('y_test.shape:', y_test.shape)
            L2_error = np.sum(abs(y_fit - y_test)) / len(X_test)
            L2_error_list.append(L2_error)
            Linfinity_error = np.max(np.abs(y_fit - y_test))
            Linfinity_error_list.append(Linfinity_error)
    step_list = list(range(total_steps + 1))
    return step_list, L2_error_list, Linfinity_error_list


# def Baseline_plot_bias_variance(X_train, y_train, X_test, y_test, dim, step_size):
#     pred_alpha = Alpha_KGD(X_train, y_train, dim, len(X_train), step_size)
#     pred_alpha = pred_alpha[:, :-1]
#     L2_error_list, Linfinity_error_list = [], []
#     if dim == 1:
#         pred_ker = kernel_matrix_dim_1(X_train, X_test)  # (n, n)
#         for i in range(len(X_train)+1):
#             y_fit = np.dot(pred_ker, pred_alpha[:, i])
#             y_fit = np.squeeze(y_fit)
#             # print('y_fit.shape:', y_fit.shape)
#             # print('y_test.shape:', y_test.shape)
#             y_test = np.squeeze(y_test)
#             L2_error = np.sum((y_fit - y_test) ** 2) / len(X_test)
#             L2_error_list.append(math.sqrt(L2_error))
#             # Linfinity_norm
#             Linfinity_error = np.max(np.abs(y_fit - y_test))
#             Linfinity_error_list.append(Linfinity_error)
#
#     else:
#         pred_ker = kernel_matrix_dim_3(X_train, X_test)
#         for i in range(len(X_train)+1):
#             # print(i)
#             y_fit = np.dot(pred_ker, pred_alpha[:, i])
#             y_fit = np.squeeze(y_fit)
#             # print('y_fit.shape:', y_fit.shape)
#             # print('y_test.shape:', y_test.shape)
#             L2_error = np.sum((y_fit - y_test) ** 2) / len(X_test)
#             L2_error_list.append(math.sqrt(L2_error))
#             # Linfinity_norm
#             Linfinity_error = np.max(np.abs(y_fit - y_test))
#             Linfinity_error_list.append(Linfinity_error)
#     # print('t_star:', t_star)
#     step_list = list(range(len(X_train) + 1))
#     return step_list, L2_error_list, Linfinity_error_list


# time_start = time.time()
# dim = 1
# step_size = 1
# np.random.seed(10)
# delta_ = 0.9
# noise_var = 0.2
# train_size = 1000
# split_L = int(train_size * 0.7)
# train, test = (train_size, dim), (200, dim)
# X_train, y_train, X_test, y_test = generate_data(train, test, dim, noise_var)
#
# # t_star, min_error = Baseline(X_train, y_train, X_test, y_test, dim, step_size)
# # print('-----------------------------------------------------final test error----------------------------------------------------- ')
# # print('t_star, min_error', (t_star, min_error))
#
#
# t_star_L2, min_error_L2, t_star_Linfinity, min_error_Linfinity = Baseline(X_train, y_train, X_test, y_test, dim, step_size)
# print('-----------------------------------------------------final test error----------------------------------------------------- ')
# print('t_star_L2, min_error_L2, t_star_Linfinity, min_error_Linfinity', (t_star_L2, min_error_L2, t_star_Linfinity, min_error_Linfinity))
# # t_star_L2, min_error_L2, t_star_Linfinity, min_error_Linfinity (338, 0.015077203450887066, 439, 0.04864775297758728)