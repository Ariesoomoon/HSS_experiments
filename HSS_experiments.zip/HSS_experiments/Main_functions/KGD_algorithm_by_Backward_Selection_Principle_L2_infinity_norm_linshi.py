import pandas as pd
from numpy import *
import numpy as np
import math
import h5py
from sklearn.model_selection import KFold
import os, time
time_start = time.time()
import random
import matplotlib.pyplot as plt


'''------------------------------------------------定义核函数------------------------------------------------'''
def kernel_matrix_dim_1(x, y):
    n,t = len(x), len(y)
    mat_1 = np.ones((t,n))
    y_1 = np.reshape(y, (t, 1), order='A')  # (t, 1)
    y_1 = np.repeat(y_1, n, axis=1)         # (t, n)
    x_1 = np.reshape(x, (1, n), order='A')  # (1, n)
    x_1 = np.repeat(x_1, t, axis=0)         # (t, n)
    kermatrix = np.minimum(x_1, y_1) + mat_1
    return kermatrix

def func_kernel_dim_3(x):
    if x >= 0 and x <= 1:
        result = (1 - x) ** 4 * (4*x+1)
    else:
        result = 0.0
    return result

# (2) gaussian kernel
def gaussian_k(x):
    result = math.exp(-x**2)
    return result

def kernel_matrix_dim_3(x, y):
    n, t = len(x), len(y)
    y_1 = np.reshape(y, (t, 1, 3))
    y_1 = np.repeat(y_1, n, axis=1)  # (t,n,3)
    x_1 = np.reshape(x, (1, n, 3))
    x_1 = np.repeat(x_1, t, axis=0)  # (t,n,3)
    dis = x_1 - y_1
    dis_norm = np.linalg.norm(dis, axis=2)   # (t,n)
    # for kernel defined in "h3_k()"
    h3_k_vector = np.vectorize(func_kernel_dim_3)
    kermatrix = h3_k_vector(dis_norm)
    return kermatrix

'''------------------------------------------------定义回归函数------------------------------------------------'''
def func_dim_1(x):
    if x>=0 and x<=0.5:
        result=x
    else:
        result=1-x
    return result

def create_y_func_dim_1(x):
    func_dim_1_vector = np.vectorize(func_dim_1)
    y = func_dim_1_vector(x)      # (6,n)
    return y


def func_dim_3(norm_x):
    if norm_x>=0 and norm_x<=1:
        result=(1-norm_x)**6 * (35*norm_x**2 + 18*norm_x + 3)
    else:
        result=0
    return result


def create_y_func_dim_3(x):
    norm_x = np.linalg.norm(x, axis=1)
    func_dim_3_vector = np.vectorize(func_dim_3)
    y = func_dim_3_vector(norm_x)      # (6,n)
    return y


'''------------------------------------------------采集样本------------------------------------------------'''
def sample(train_size, test_size,  dim, noise_var):
    X_train = np.random.uniform(0.0, 1.0, train_size)
    X_test = np.random.uniform(0.0, 1.0, test_size)
    truncated_noise_value = 0.4
    if dim == 1:
        noise = np.random.normal(0, noise_var, train_size)
        noise_clipped = np.clip(noise, -truncated_noise_value, truncated_noise_value)
        y_train = create_y_func_dim_1(X_train) + noise # or noise_clipped
        y_test = create_y_func_dim_1(X_test)
    else: # d=3
        noise = np.random.normal(0, noise_var, train_size[0])
        noise_clipped = np.clip(noise, -truncated_noise_value, truncated_noise_value)
        y_train = create_y_func_dim_3(X_train) + noise # or noise_clipped
        y_test = create_y_func_dim_3(X_test)
    return X_train.shape, y_train.shape, X_train, y_train, X_test.shape, y_test.shape, X_test, y_test



def generate_data(train, test, dim, noise_var):
    samples = sample(train, test, dim, noise_var)
    X_train, y_train, X_test, y_test = samples[2], samples[3], samples[6], samples[7]
    # print('\n ########### ♣️From dim = %s | noise_var=%s | Train set X:%s, y:%s | Test set X:%s, y:%s  ##########' % (dim, noise_var, samples[0], samples[1], samples[4], samples[5]))
    return X_train, y_train, X_test, y_test



'''------------------------------------------------计算有效维------------------------------------------------'''
# 计算有效维，快速计算，直接计算出所有steps的有效维
def effective_dim(X_tra, dim, T_upper):
    ker = kernel_matrix_dim_1(X_tra, X_tra) if dim == 1 else kernel_matrix_dim_3(X_tra, X_tra)
    U, S, V = np.linalg.svd(ker)

    step_t_list = list(range(1, T_upper + 1, 1))
    step_t_array = np.array(step_t_list)
    n_s, n_t = S.shape[0], step_t_array.shape[0]

    step_t_array = np.reshape(step_t_array, (n_t, 1)) # (n_t, 1)
    step_t_array = np.repeat(step_t_array, n_s, axis=1) # (n_t, n_s)
    step_t_array = step_t_array.T   # (n_s, n_t)

    S_new = np.reshape(S, (n_s, 1)) # (n_s, 1)
    S_new = np.repeat(S_new, n_t, axis=1) # (n_s, n_t)

    S_parameter = S_new/(S_new + (1/step_t_array) * n_s) #
    effect_dim = np.sum(S_parameter, axis = 0)
    return effect_dim


'''-------------------------------计算W_D_t，U_D_t_delta，T_delta_D，求出BSP的step的上界T ------------------------------------'''
def W_D_t(X_train, dim, T_upper):
    w_d_t_list = []
    effect_dim = effective_dim(X_train, dim, T_upper)
    for step_t in range(1, T_upper + 1):
        w_d_t = np.sqrt(step_t) / len(X_train) + np.sqrt(max(effect_dim[step_t-1], 1)) * (1 + np.sqrt(step_t / len(X_train))) / np.sqrt(len(X_train))
        w_d_t_list.append(w_d_t) # 对应t=1, 2, ..., T
    return w_d_t_list


def find_last_negative_index(lst, target):
    last_negative_index = None
    for index, value in enumerate(lst):
        if value <= target:
            last_negative_index = index

    if last_negative_index == None:
        last_negative_index = len(lst)
    return last_negative_index


def U_D_t_delta(X_train, T_upper, delta_, dim):
    u_d_t_delta_list = []
    effect_dim = effective_dim(X_train, dim, T_upper)
    for step_t in range(1, T_upper+1):
        # print(step_t)
        a = np.log(1 + 8 * np.log(64/delta_ * np.sqrt(step_t / len(X_train)) * max(effect_dim[step_t-1], 1))) / (len(X_train) / step_t)
        # a = np.log(1 + 8 * np.log(64/delta_) * np.sqrt(step_t / len(X_train)) * max(effect_dim[step_t-1], 1)) / (len(X_train) / step_t)
        u_d_t_delta = a + np.sqrt(a)
        u_d_t_delta_list.append(u_d_t_delta)
    return u_d_t_delta_list


def T_delta_D(X_train, dim, delta_, T_para):   # T_para = 1/2
    k_sup = np.sqrt(2) if dim == 1 else np.sqrt(1)  # else: when dim=3
    c_1_star = max((k_sup ** 2 + 1) / 3, 2 * np.sqrt(k_sup ** 2 + 1))

    u_d_t_delta_list = U_D_t_delta(X_train, len(X_train), delta_, dim)
    c_u_list = [u_d_t_delta * c_1_star for u_d_t_delta in u_d_t_delta_list]

    t_delta_d = find_last_negative_index(c_u_list, T_para)
    return t_delta_d


def C_U(C_0, q, U):
    c_u_list = []
    k_list = list(range(0, U + 1, 1))
    c_u_list = [C_0 * q**k for k in k_list]
    return c_u_list


'''-------------------------------计算 KGD的系数alpha(对应论文中的c_t, 默认c_0=(0,...,0))和核矩阵ker ------------------------------------'''
def Alpha_KGD_vector(X_train, y_tra, dim, step_t, step_size):
    ker = kernel_matrix_dim_1(X_train, X_train) if dim == 1 else kernel_matrix_dim_3(X_train, X_train)
    n = len(X_train)
    y_tra = np.reshape(y_tra, (n, 1))
    alpha = np.reshape(np.zeros(n), (n, 1))
    # for i in range(step_t + 1): # 应该改为step_t，此时对应才是c_t
    for i in range(step_t):
        alpha = alpha + (step_size / n) * (y_tra - np.dot(ker, alpha)) # t=1,...,t # i=0,计算的是t=1时的结果
    return alpha


def Predicted_KGD(X_train, y_tra, x_tes, y_tes, dim, step_t, step_size): # 计算的实际上是t=step_t+1时对用的结果
    y_tes = np.squeeze(y_tes)
    n, t = len(X_train), len(x_tes)
    pred_alpha = Alpha_KGD_vector(X_train, y_tra, dim, step_t, step_size)  # (n, 1)
    if dim == 1:
        pred_ker = kernel_matrix_dim_1(X_train, x_tes)  # (n, n)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)

    else:
        pred_ker = kernel_matrix_dim_3(X_train, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)

    average_error = np.sum((y_fit - y_tes) ** 2) / t
    kgd_L2_error = math.sqrt(average_error)
    kgd_Linfinity_error = np.max(np.abs(y_fit - y_tes))
    return y_fit, kgd_L2_error, kgd_Linfinity_error


'''------------------------------------------------ BSP 准则 -----------------------------------------------------'''
def Alpha_KGD(X_train, y_tra, dim, step_t, step_size):
    ker = kernel_matrix_dim_1(X_train, X_train) if dim == 1 else kernel_matrix_dim_3(X_train, X_train)
    # U, S, V = np.linalg.svd(ker)
    # step_size = 1 / np.max(S)
    n = len(X_train)
    y_tra = np.reshape(y_tra, (n, 1))
    alpha = np.reshape(np.zeros(n), (n, 1))
    alpha_matrix = np.empty(shape=(n, step_t+2))  # alpha_0, alpha_1, ..., alpha_t, alpha_t+1
    alpha_matrix[:, 0] = np.squeeze(alpha)  # 先存alpha_0
    for i in range(step_t + 1):
        alpha = alpha + (step_size / n) * (y_tra - np.dot(ker, alpha))
        alpha_matrix[:, i+1] = np.squeeze(alpha) # i=0时,存的是alpha_1， i=step_t时,存的是alpha_t+1，
    return alpha_matrix  # (n, t+2)


def find_last_positive_index(lst, step_max):
    last_positive_index = None
    for index, value in enumerate(lst):
        if value >= 0:
            last_positive_index = index + 1 # 需要+1， 因为steps=[1, 2, ...T]是从1开始的
    if last_positive_index == None:
        last_positive_index = step_max
    return last_positive_index

def BSP_left_right_calculation(X_train, y_tra, dim, total_steps, step_size):
    ker = kernel_matrix_dim_1(X_train, X_train) if dim == 1 else kernel_matrix_dim_3(X_train, X_train)
    C_t_matrix = Alpha_KGD(X_train, y_tra, dim, total_steps, step_size)  # (D, T+2)
    n_D = len(X_train)

    C_t_end_matrix, C_t_start_matrix = C_t_matrix[:, 2:], C_t_matrix[:, 1:-1]  # (D, T)
    C_diff_matrix = C_t_end_matrix - C_t_start_matrix  # (D, T)
    C_diff_matrix_T = C_diff_matrix.T  # (T, D)

    # for norm_k
    norm_k_square_matirx = np.dot(np.dot(C_diff_matrix_T, ker), C_diff_matrix)  # (T, T)
    norm_k_square_matirx[norm_k_square_matirx < 0] = 0  # 对角线上的元素保持不变就好
    norm_k_matrix = np.sqrt(norm_k_square_matirx)
    norm_k_matrix_diag = np.diagonal(norm_k_matrix) # 提取对角线上的元素

    # for norm_d
    norm_d_square_matirx = np.dot(np.dot(C_diff_matrix_T, np.dot(ker, ker)), C_diff_matrix) / len(X_train)  # (T, T)
    norm_d_square_matirx[norm_d_square_matirx < 0] = 0  # 对角线上的元素保持不变就好
    norm_d_matrix = np.sqrt(norm_d_square_matirx)
    norm_d_matrix_diag = np.diagonal(norm_d_matrix)  # 提取对角线上的元素

    # 构造BSP的左边：
    step_vector = np.array(list(range(1, total_steps + 1, 1)))  # (T, )
    BSP_left = step_vector * norm_d_matrix_diag + np.sqrt(step_vector) * norm_k_matrix_diag  # (T, )

    # 构造BSP的右边：
    BsP_right_W = np.array(W_D_t(X_train, dim, total_steps))  # (T, )
    # print(BsP_right_W.shape)
    return BSP_left, BsP_right_W


def BSP_principle(BSP_left, BSP_right_W, C_bsp, total_steps):  # step_t即step_max
    BSP_right = C_bsp * BSP_right_W
    diff_list = BSP_left - BSP_right
    t_BSP = find_last_positive_index(diff_list, total_steps)
    return t_BSP


# def select_c_star(X_train, y_train, dim, step_size, split_L, log_filename):
#     random.seed(1)
#     random_train = random.sample(list(range(len(X_train))), split_L)  # size为L的training data
#     random_validation = [element for element in list(range(len(X_train))) if element not in random_train] # size为|D|-L的validation data
#     X_train_L, X_validation_L = X_train[random_train], X_train[random_validation]  # 长度分别是L, |D|-L
#     y_train_L, y_validation_L = y_train[random_train], y_train[random_validation]
#
#     total_steps = len(X_train)
#     #     T_for_C_selection = T_delta_D(X_train, dim, delta_, T_para) # 这个是在全样本上计算的
#     #     print('T_for_C_selection:', T_for_C_selection)
#     BSP_left, BSP_right_W = BSP_left_right_calculation(X_train_L, y_train_L, dim, total_steps, step_size)
#     L2_error_compares, L2_c_bsp_opt_list, L2_tj_opt_list = [], [], []
#     Linfinity_error_compares, Linfinity_c_bsp_opt_list, Linfinity_tj_opt_list = [], [], []
#
#     L2_c_bsp_1, L2_c_bsp_2 = 0.25, 0.75
#     Linfinity_c_bsp_1, Linfinity_c_bsp_2 = 0.25, 0.75
#     for i in range(1, 15):
#         # -----------------------------  L2_norm   -----------------------------------
#         L2_tj_c_bsp_1 = BSP_principle(BSP_left, BSP_right_W, L2_c_bsp_1, total_steps)
#         L2_tj_c_bsp_2 = BSP_principle(BSP_left, BSP_right_W, L2_c_bsp_2, total_steps)
#         L2_error_c_bsp_1 = Predicted_KGD(X_train_L, y_train_L, X_validation_L, y_validation_L, dim, L2_tj_c_bsp_1, step_size)[1]
#         L2_error_c_bsp_2 = Predicted_KGD(X_train_L, y_train_L, X_validation_L, y_validation_L, dim, L2_tj_c_bsp_2, step_size)[1]
#
#         if L2_error_c_bsp_1 <= L2_error_c_bsp_2:
#             # print('optimal h: %s, tuning at: %s' % (c_bsp_1, c_bsp_2 - c_bsp_1))
#             L2_error_compare, L2_c_bsp_opt, L2_tj_opt = L2_error_c_bsp_1, L2_c_bsp_1, L2_tj_c_bsp_1
#             L2_c_bsp_1, L2_c_bsp_2 = L2_c_bsp_1-0.25*2**(-i), L2_c_bsp_1+0.25*2**(-i)
#
#         else:
#             L2_error_compare, L2_c_bsp_opt, L2_tj_opt = L2_error_c_bsp_2, L2_c_bsp_2, L2_tj_c_bsp_2
#             # print('optimal h: %s, tuning at: %s' % (c_bsp_2, c_bsp_2 - c_bsp_1))
#             L2_c_bsp_1, L2_c_bsp_2 = L2_c_bsp_2-0.25*2**(-i), L2_c_bsp_2+0.25*2**(-i)
#
#         # print('c_bsp_1,c_bsp_2:', c_bsp_1, c_bsp_2)
#         L2_error_compares.append(L2_error_compare)
#         L2_c_bsp_opt_list.append(L2_c_bsp_opt)
#         L2_tj_opt_list.append(L2_tj_opt)
#
#         # -----------------------------  Linfinity_norm   -----------------------------------
#         Linfinity_tj_c_bsp_1 = BSP_principle(BSP_left, BSP_right_W, Linfinity_c_bsp_1, total_steps)
#         Linfinity_tj_c_bsp_2 = BSP_principle(BSP_left, BSP_right_W, Linfinity_c_bsp_2, total_steps)
#         Linfinity_error_c_bsp_1 = Predicted_KGD(X_train_L, y_train_L, X_validation_L, y_validation_L, dim, Linfinity_tj_c_bsp_1, step_size)[2]
#         Linfinity_error_c_bsp_2 = Predicted_KGD(X_train_L, y_train_L, X_validation_L, y_validation_L, dim, Linfinity_tj_c_bsp_2, step_size)[2]
#
#         if Linfinity_error_c_bsp_1 <= Linfinity_error_c_bsp_2:
#             Linfinity_error_compare, Linfinity_c_bsp_opt, Linfinity_tj_opt = Linfinity_error_c_bsp_1, Linfinity_c_bsp_1, Linfinity_tj_c_bsp_1
#             Linfinity_c_bsp_1, Linfinity_c_bsp_2 = Linfinity_c_bsp_1-0.25*2**(-i), Linfinity_c_bsp_1+0.25*2**(-i)
#
#         else:
#             Linfinity_error_compare, Linfinity_c_bsp_opt, Linfinity_tj_opt = Linfinity_error_c_bsp_2, Linfinity_c_bsp_2, Linfinity_tj_c_bsp_2
#             Linfinity_c_bsp_1, Linfinity_c_bsp_2 = Linfinity_c_bsp_2-0.25*2**(-i), Linfinity_c_bsp_2+0.25*2**(-i)
#
#         Linfinity_error_compares.append(Linfinity_error_compare)
#         Linfinity_c_bsp_opt_list.append(Linfinity_c_bsp_opt)
#         Linfinity_tj_opt_list.append(Linfinity_tj_opt)
#
#     index_L2 = L2_error_compares.index(min(L2_error_compares))
#     L2_C, L2_t, L2_min_error = L2_c_bsp_opt_list[index_L2], L2_tj_opt_list[index_L2], min(L2_error_compares)
#     index_Linfinity = Linfinity_error_compares.index(min(Linfinity_error_compares))
#     Linfinity_C, Linfinity_t, Linfinity_min_error = Linfinity_c_bsp_opt_list[index_Linfinity], Linfinity_tj_opt_list[index_Linfinity], min(Linfinity_error_compares)
#     # print('L2_C, L2_t, L2_min_error:', (L2_C, L2_t, L2_min_error))
#     # print('Linfinity_C, Linfinity_t, Linfinity_min_error:', (Linfinity_C, Linfinity_t, Linfinity_min_error))
#
#     print('---------------------- validation result in selecting the constant  -----------------------')
#     print('L2_c_bsp_opt_list:', L2_c_bsp_opt_list)
#     print('L2_tj_opt_list:', L2_tj_opt_list)
#     print('L2_C, L2_t, L2_min_error:', (L2_C, L2_t, L2_min_error))
#     print('Linfinity_c_bsp_opt_list:', Linfinity_c_bsp_opt_list)
#     print('Linfinity_tj_opt_list:', Linfinity_tj_opt_list)
#     print('Linfinity_C, Linfinity_t, Linfinity_min_error:', (Linfinity_C, Linfinity_t, Linfinity_min_error))
#
#     # 💎logging in process
#     with open(log_filename, 'a') as log_file:
#         log_file.write(f'\n--------------------------- data size : {len(X_train)} -------------------------------------\n-----------valadition result:-----------\n'
#                         f'L2_c_bsp_opt_list: {L2_c_bsp_opt_list};\nL2_tj_opt_list: {L2_tj_opt_list};\nLinfinity_c_bsp_opt_list: {Linfinity_c_bsp_opt_list};\nLinfinity_tj_opt_list: {Linfinity_tj_opt_list}\n'
#                        f'L2_C:{L2_C};\nL2_t:{L2_t};\nL2_min_error:{L2_min_error}\n'
#                        f'Linfinity_C:{Linfinity_C};\nLinfinity_t:{Linfinity_t};\nLinfinity_min_error:{Linfinity_min_error}\n')
#
#     return L2_C, L2_t, L2_min_error, Linfinity_C, Linfinity_t, Linfinity_min_error


# def select_c_star(X_train, y_train, dim, step_size, split_L):
#     random.seed(1)
#     random_train = random.sample(list(range(len(X_train))), split_L)  # size为L的training data
#     random_validation = [element for element in list(range(len(X_train))) if
#                          element not in random_train]  # size为|D|-L的validation data
#
#     X_train_L, X_validation_L = X_train[random_train], X_train[random_validation]  # 长度分别是L, |D|-L
#     y_train_L, y_validation_L = y_train[random_train], y_train[random_validation]
#
#     total_steps = len(X_train)
#     #     T_for_C_selection = T_delta_D(X_train, dim, delta_, T_para) # 这个是在全样本上计算的
#     #     print('T_for_C_selection:', T_for_C_selection)
#     BSP_left, BSP_right_W = BSP_left_right_calculation(X_train_L, y_train_L, dim, total_steps, step_size)
#     error_compares, c_bsp_opt_list, tj_opt_list = [], [], []
#
#     c_bsp_1, c_bsp_2 = 0.25, 0.75
#     for i in range(1, 15):
#         tj_c_bsp_1 = BSP_principle(BSP_left, BSP_right_W, c_bsp_1, total_steps)
#         tj_c_bsp_2 = BSP_principle(BSP_left, BSP_right_W, c_bsp_2, total_steps)
#
#         error_c_bsp_1 = \
#         Predicted_KGD(X_train_L, y_train_L, X_validation_L, y_validation_L, dim, tj_c_bsp_1, step_size, error_norm)[1]
#         error_c_bsp_2 = \
#         Predicted_KGD(X_train_L, y_train_L, X_validation_L, y_validation_L, dim, tj_c_bsp_2, step_size, error_norm)[1]
#
#         if error_c_bsp_1 <= error_c_bsp_2:
#             # print('optimal h: %s, tuning at: %s' % (c_bsp_1, c_bsp_2 - c_bsp_1))
#             error_compare, c_bsp_opt, tj_opt = error_c_bsp_1, c_bsp_1, tj_c_bsp_1
#             c_bsp_1, c_bsp_2 = c_bsp_1 - 0.25 * 2 ** (-i), c_bsp_1 + 0.25 * 2 ** (-i)
#
#         else:
#             error_compare, c_bsp_opt, tj_opt = error_c_bsp_2, c_bsp_2, tj_c_bsp_2
#             # print('optimal h: %s, tuning at: %s' % (c_bsp_2, c_bsp_2 - c_bsp_1))
#             c_bsp_1, c_bsp_2 = c_bsp_2 - 0.25 * 2 ** (-i), c_bsp_2 + 0.25 * 2 ** (-i)
#
#         # print('c_bsp_1,c_bsp_2:', c_bsp_1, c_bsp_2)
#         error_compares.append(error_compare)
#         c_bsp_opt_list.append(c_bsp_opt)
#         tj_opt_list.append(tj_opt)
#
#     index = error_compares.index(min(error_compares))
#     c_bsp_opt_final = c_bsp_opt_list[index]
#     tj_opt_final = tj_opt_list[index]
#     min_error = min(error_compares)
#
#     print('c_bsp_opt_list', c_bsp_opt_list)
#     print('tj_opt_list', tj_opt_list)
#     print('error_compares', error_compares)
#     return c_bsp_opt_final, tj_opt_final, min_error


def Selection_parameter_for_L2norm(BSP_left, BSP_right_W, L2_c_bsp_1, L2_c_bsp_2, value1, total_steps, X_train_L_tr, y_train_L_tr, X_train_L_val, y_train_L_val, dim, step_size):
    L2_error_compares, L2_c_bsp_opt_list, L2_tj_opt_list = [], [], []
    for i in range(1, 11):
        # -----------------------------  L2_norm   -----------------------------------
        L2_tj_c_bsp_1 = BSP_principle(BSP_left, BSP_right_W, L2_c_bsp_1, total_steps)
        L2_tj_c_bsp_2 = BSP_principle(BSP_left, BSP_right_W, L2_c_bsp_2, total_steps)
        L2_error_c_bsp_1 = Predicted_KGD(X_train_L_tr, y_train_L_tr, X_train_L_val, y_train_L_val, dim, L2_tj_c_bsp_1, step_size)[1]
        L2_error_c_bsp_2 = Predicted_KGD(X_train_L_tr, y_train_L_tr, X_train_L_val, y_train_L_val, dim, L2_tj_c_bsp_2, step_size)[1]

        if L2_error_c_bsp_1 <= L2_error_c_bsp_2:
            # print('optimal h: %s, tuning at: %s' % (c_bsp_1, c_bsp_2 - c_bsp_1))
            L2_error_compare, L2_c_bsp_opt, L2_tj_opt = L2_error_c_bsp_1, L2_c_bsp_1, L2_tj_c_bsp_1
            L2_c_bsp_1, L2_c_bsp_2 = L2_c_bsp_1-value1*2**(-i), L2_c_bsp_1+value1*2**(-i)

        else:
            L2_error_compare, L2_c_bsp_opt, L2_tj_opt = L2_error_c_bsp_2, L2_c_bsp_2, L2_tj_c_bsp_2
            # print('optimal h: %s, tuning at: %s' % (c_bsp_2, c_bsp_2 - c_bsp_1))
            L2_c_bsp_1, L2_c_bsp_2 = L2_c_bsp_2-value1*2**(-i), L2_c_bsp_2+value1*2**(-i)

        # print('c_bsp_1,c_bsp_2:', c_bsp_1, c_bsp_2)
        L2_error_compares.append(L2_error_compare)
        L2_c_bsp_opt_list.append(L2_c_bsp_opt)
        L2_tj_opt_list.append(L2_tj_opt)

    index_L2 = L2_error_compares.index(min(L2_error_compares))
    L2_C, L2_t, L2_min_error = L2_c_bsp_opt_list[index_L2], L2_tj_opt_list[index_L2], min(L2_error_compares)
    return L2_C, L2_t, L2_min_error




def Selection_parameter_for_Linftynorm(BSP_left, BSP_right_W, Linfinity_c_bsp_1, Linfinity_c_bsp_2, value1, total_steps, X_train_L_tr, y_train_L_tr, X_train_L_val, y_train_L_val, dim, step_size):
    Linfinity_error_compares, Linfinity_c_bsp_opt_list, Linfinity_tj_opt_list = [], [], []
    for i in range(1, 11):
        # -----------------------------  L2_norm   -----------------------------------
        Linfinity_tj_c_bsp_1 = BSP_principle(BSP_left, BSP_right_W, Linfinity_c_bsp_1, total_steps)
        Linfinity_tj_c_bsp_2 = BSP_principle(BSP_left, BSP_right_W, Linfinity_c_bsp_2, total_steps)
        Linfinity_error_c_bsp_1 = Predicted_KGD(X_train_L_tr, y_train_L_tr, X_train_L_val, y_train_L_val, dim, Linfinity_tj_c_bsp_1, step_size)[2]
        Linfinity_error_c_bsp_2 = Predicted_KGD(X_train_L_tr, y_train_L_tr, X_train_L_val, y_train_L_val, dim, Linfinity_tj_c_bsp_2, step_size)[2]

        if Linfinity_error_c_bsp_1 <= Linfinity_error_c_bsp_2:
            Linfinity_error_compare, Linfinity_c_bsp_opt, Linfinity_tj_opt = Linfinity_error_c_bsp_1, Linfinity_c_bsp_1, Linfinity_tj_c_bsp_1
            Linfinity_c_bsp_1, Linfinity_c_bsp_2 = Linfinity_c_bsp_1-value1*2**(-i), Linfinity_c_bsp_1+value1*2**(-i)

        else:
            Linfinity_error_compare, Linfinity_c_bsp_opt, Linfinity_tj_opt = Linfinity_error_c_bsp_2, Linfinity_c_bsp_2, Linfinity_tj_c_bsp_2
            Linfinity_c_bsp_1, Linfinity_c_bsp_2 = Linfinity_c_bsp_2-value1*2**(-i), Linfinity_c_bsp_2+value1*2**(-i)

        Linfinity_error_compares.append(Linfinity_error_compare)
        Linfinity_c_bsp_opt_list.append(Linfinity_c_bsp_opt)
        Linfinity_tj_opt_list.append(Linfinity_tj_opt)

    index_Linfinity = Linfinity_error_compares.index(min(Linfinity_error_compares))
    Linfinity_C, Linfinity_t, Linfinity_min_error = Linfinity_c_bsp_opt_list[index_Linfinity], Linfinity_tj_opt_list[index_Linfinity], min(Linfinity_error_compares)
    return Linfinity_C, Linfinity_t, Linfinity_min_error





# 容错
def select_c_star(X_train_L, y_train_L, dim, step_size, split_L_tr, total_steps, log_filename):
    random.seed(1)
    random_train = random.sample(list(range(len(X_train_L))), split_L_tr)  # size为L的training data
    random_validation = [element for element in list(range(len(X_train_L))) if element not in random_train] # size为|D|-L的validation data
    X_train_L_tr, X_train_L_val = X_train_L[random_train], X_train_L[random_validation]  # 长度分别是L, |D|-L
    y_train_L_tr, y_train_L_val = y_train_L[random_train], y_train_L[random_validation]

    #     T_for_C_selection = T_delta_D(X_train, dim, delta_, T_para) # 这个是在全样本上计算的
    #     print('T_for_C_selection:', T_for_C_selection)
    BSP_left, BSP_right_W = BSP_left_right_calculation(X_train_L_tr, y_train_L_tr, dim, total_steps, step_size)
    C_bsp_list = [0.00001, 0.0001, 0.001, 0.01] + [i * 0.1 for i in range(1, 40, 1)]
    Linfinity_error_c_list, c_bsp_select2_list, L2_error_c_list, c_bsp_select1_list = [], [], [], []

    for c_bsp in C_bsp_list:
        c_bsp_select1 = BSP_principle(BSP_left, BSP_right_W, c_bsp, total_steps)
        L2_error_c= Predicted_KGD(X_train_L_tr, y_train_L_tr, X_train_L_val, y_train_L_val, dim, c_bsp_select1, step_size)[1]

        c_bsp_select2 = BSP_principle(BSP_left, BSP_right_W, c_bsp, total_steps)
        Linfinity_error = Predicted_KGD(X_train_L_tr, y_train_L_tr, X_train_L_val, y_train_L_val, dim, c_bsp_select2, step_size)[2]

        c_bsp_select1_list.append(c_bsp_select1)
        L2_error_c_list.append(L2_error_c)
        c_bsp_select2_list.append(c_bsp_select2)
        Linfinity_error_c_list.append(Linfinity_error)


    index_L2 = L2_error_c_list.index(min(L2_error_c_list))
    L2_C, L2_t, L2_min_error = c_bsp_select1_list[index_L2], 3, min(L2_error_c_list)

    index_Linfty = Linfinity_error_c_list.index(min(Linfinity_error_c_list))
    Linfinity_C, Linfinity_t, Linfinity_min_error = c_bsp_select2_list[index_Linfty],3, min(Linfinity_error_c_list)

    return L2_C, L2_t, L2_min_error, Linfinity_C, Linfinity_t, Linfinity_min_error




# def select_c_star(X_train_L, y_train_L, dim, step_size, split_L_tr, total_steps, log_filename):
#     random.seed(1)
#     random_train = random.sample(list(range(len(X_train_L))), split_L_tr)  # size为L的training data
#     random_validation = [element for element in list(range(len(X_train_L))) if element not in random_train] # size为|D|-L的validation data
#     X_train_L_tr, X_train_L_val = X_train_L[random_train], X_train_L[random_validation]  # 长度分别是L, |D|-L
#     y_train_L_tr, y_train_L_val = y_train_L[random_train], y_train_L[random_validation]
#
#
#     #     T_for_C_selection = T_delta_D(X_train, dim, delta_, T_para) # 这个是在全样本上计算的
#     #     print('T_for_C_selection:', T_for_C_selection)
#     BSP_left, BSP_right_W = BSP_left_right_calculation(X_train_L_tr, y_train_L_tr, dim, total_steps, step_size)
#     L2_error_compares, L2_c_bsp_opt_list, L2_tj_opt_list = [], [], []
#     Linfinity_error_compares, Linfinity_c_bsp_opt_list, Linfinity_tj_opt_list = [], [], []
#
#     L2_c_bsp_1, L2_c_bsp_2 = 0.25, 0.75
#     Linfinity_c_bsp_1, Linfinity_c_bsp_2 = 0.25, 0.75
#
#     for i in range(1, 11):
#         # -----------------------------  L2_norm   -----------------------------------
#         L2_tj_c_bsp_1 = BSP_principle(BSP_left, BSP_right_W, L2_c_bsp_1, total_steps)
#         L2_tj_c_bsp_2 = BSP_principle(BSP_left, BSP_right_W, L2_c_bsp_2, total_steps)
#         L2_error_c_bsp_1 = Predicted_KGD(X_train_L_tr, y_train_L_tr, X_train_L_val, y_train_L_val, dim, L2_tj_c_bsp_1, step_size)[1]
#         L2_error_c_bsp_2 = Predicted_KGD(X_train_L_tr, y_train_L_tr, X_train_L_val, y_train_L_val, dim, L2_tj_c_bsp_2, step_size)[1]
#
#         if L2_error_c_bsp_1 <= L2_error_c_bsp_2:
#             # print('optimal h: %s, tuning at: %s' % (c_bsp_1, c_bsp_2 - c_bsp_1))
#             L2_error_compare, L2_c_bsp_opt, L2_tj_opt = L2_error_c_bsp_1, L2_c_bsp_1, L2_tj_c_bsp_1
#             L2_c_bsp_1, L2_c_bsp_2 = L2_c_bsp_1-0.25*2**(-i), L2_c_bsp_1+0.25*2**(-i)
#
#         else:
#             L2_error_compare, L2_c_bsp_opt, L2_tj_opt = L2_error_c_bsp_2, L2_c_bsp_2, L2_tj_c_bsp_2
#             # print('optimal h: %s, tuning at: %s' % (c_bsp_2, c_bsp_2 - c_bsp_1))
#             L2_c_bsp_1, L2_c_bsp_2 = L2_c_bsp_2-0.25*2**(-i), L2_c_bsp_2+0.25*2**(-i)
#
#         # print('c_bsp_1,c_bsp_2:', c_bsp_1, c_bsp_2)
#         L2_error_compares.append(L2_error_compare)
#         L2_c_bsp_opt_list.append(L2_c_bsp_opt)
#         L2_tj_opt_list.append(L2_tj_opt)
#
#         # -----------------------------  Linfinity_norm   -----------------------------------
#         Linfinity_tj_c_bsp_1 = BSP_principle(BSP_left, BSP_right_W, Linfinity_c_bsp_1, total_steps)
#         Linfinity_tj_c_bsp_2 = BSP_principle(BSP_left, BSP_right_W, Linfinity_c_bsp_2, total_steps)
#         Linfinity_error_c_bsp_1 = Predicted_KGD(X_train_L_tr, y_train_L_tr, X_train_L_val, y_train_L_val, dim, Linfinity_tj_c_bsp_1, step_size)[2]
#         Linfinity_error_c_bsp_2 = Predicted_KGD(X_train_L_tr, y_train_L_tr, X_train_L_val, y_train_L_val, dim, Linfinity_tj_c_bsp_2, step_size)[2]
#
#         if Linfinity_error_c_bsp_1 <= Linfinity_error_c_bsp_2:
#             Linfinity_error_compare, Linfinity_c_bsp_opt, Linfinity_tj_opt = Linfinity_error_c_bsp_1, Linfinity_c_bsp_1, Linfinity_tj_c_bsp_1
#             Linfinity_c_bsp_1, Linfinity_c_bsp_2 = Linfinity_c_bsp_1-0.25*2**(-i), Linfinity_c_bsp_1+0.25*2**(-i)
#
#         else:
#             Linfinity_error_compare, Linfinity_c_bsp_opt, Linfinity_tj_opt = Linfinity_error_c_bsp_2, Linfinity_c_bsp_2, Linfinity_tj_c_bsp_2
#             Linfinity_c_bsp_1, Linfinity_c_bsp_2 = Linfinity_c_bsp_2-0.25*2**(-i), Linfinity_c_bsp_2+0.25*2**(-i)
#
#         Linfinity_error_compares.append(Linfinity_error_compare)
#         Linfinity_c_bsp_opt_list.append(Linfinity_c_bsp_opt)
#         Linfinity_tj_opt_list.append(Linfinity_tj_opt)
#
#     index_L2 = L2_error_compares.index(min(L2_error_compares))
#     L2_C, L2_t, L2_min_error = L2_c_bsp_opt_list[index_L2], L2_tj_opt_list[index_L2], min(L2_error_compares)
#     index_Linfinity = Linfinity_error_compares.index(min(Linfinity_error_compares))
#     Linfinity_C, Linfinity_t, Linfinity_min_error = Linfinity_c_bsp_opt_list[index_Linfinity], Linfinity_tj_opt_list[index_Linfinity], min(Linfinity_error_compares)
#     # print('L2_C, L2_t, L2_min_error:', (L2_C, L2_t, L2_min_error))
#     # print('Linfinity_C, Linfinity_t, Linfinity_min_error:', (Linfinity_C, Linfinity_t, Linfinity_min_error))
#
#     # print('---------------------- validation result in selecting the constant  -----------------------')
#     # print('L2_c_bsp_opt_list:', L2_c_bsp_opt_list)
#     # print('L2_tj_opt_list:', L2_tj_opt_list)
#     # print('L2_C, L2_t, L2_min_error:', (L2_C, L2_t, L2_min_error))
#     # print('Linfinity_c_bsp_opt_list:', Linfinity_c_bsp_opt_list)
#     # print('Linfinity_tj_opt_list:', Linfinity_tj_opt_list)
#     # print('Linfinity_C, Linfinity_t, Linfinity_min_error:', (Linfinity_C, Linfinity_t, Linfinity_min_error))
#
#     # # 💎logging in process
#     # with open(log_filename, 'a') as log_file:
#     #     log_file.write(f'\n------------------ total data size : {total_steps}; Split L data size : {len(X_train_L)} ------------------\n-----------valadition result:-----------\n'
#     #                     f'L2_c_bsp_opt_list: {L2_c_bsp_opt_list};\nL2_tj_opt_list: {L2_tj_opt_list};\nLinfinity_c_bsp_opt_list: {Linfinity_c_bsp_opt_list};\nLinfinity_tj_opt_list: {Linfinity_tj_opt_list}\n'
#     #                    f'L2_C:{L2_C};\nL2_t:{L2_t};\nL2_min_error:{L2_min_error}\n'
#     #                    f'Linfinity_C:{Linfinity_C};\nLinfinity_t:{Linfinity_t};\nLinfinity_min_error:{Linfinity_min_error}\n')
#
#     return L2_C, L2_t, L2_min_error, Linfinity_C, Linfinity_t, Linfinity_min_error




# def select_c_star_for_smallL(X_train_L, y_train_L, dim, step_size, split_L_tr, total_steps, log_filename):
#     random.seed(1)
#     random_train = random.sample(list(range(len(X_train_L))), split_L_tr)  # size为L的training data
#     random_validation = [element for element in list(range(len(X_train_L))) if
#                          element not in random_train]  # size为|D|-L的validation data
#     X_train_L_tr, X_train_L_val = X_train_L[random_train], X_train_L[random_validation]  # 长度分别是L, |D|-L
#     y_train_L_tr, y_train_L_val = y_train_L[random_train], y_train_L[random_validation]
#
#     #     T_for_C_selection = T_delta_D(X_train, dim, delta_, T_para) # 这个是在全样本上计算的
#     #     print('T_for_C_selection:', T_for_C_selection)
#     BSP_left, BSP_right_W = BSP_left_right_calculation(X_train_L_tr, y_train_L_tr, dim, total_steps, step_size)
#     L2_error_compares, L2_c_bsp_opt_list, L2_tj_opt_list = [], [], []
#     Linfinity_error_compares, Linfinity_c_bsp_opt_list, Linfinity_tj_opt_list = [], [], []
#
#     # L2_c_bsp_1, L2_c_bsp_2 = 0.25, 0.75
#     # Linfinity_c_bsp_1, Linfinity_c_bsp_2 = 0.25, 0.75
#
#     L2_c_bsp_1, L2_c_bsp_2 = 0.5, 1.5
#     Linfinity_c_bsp_1, Linfinity_c_bsp_2 = 0.5, 1.5
#
#
#     for i in range(1, 11):
#         # -----------------------------  L2_norm   -----------------------------------
#         L2_tj_c_bsp_1 = BSP_principle(BSP_left, BSP_right_W, L2_c_bsp_1, total_steps)
#         L2_tj_c_bsp_2 = BSP_principle(BSP_left, BSP_right_W, L2_c_bsp_2, total_steps)
#         L2_error_c_bsp_1 = \
#         Predicted_KGD(X_train_L_tr, y_train_L_tr, X_train_L_val, y_train_L_val, dim, L2_tj_c_bsp_1, step_size)[1]
#         L2_error_c_bsp_2 = \
#         Predicted_KGD(X_train_L_tr, y_train_L_tr, X_train_L_val, y_train_L_val, dim, L2_tj_c_bsp_2, step_size)[1]
#
#         if L2_error_c_bsp_1 <= L2_error_c_bsp_2:
#             # print('optimal h: %s, tuning at: %s' % (c_bsp_1, c_bsp_2 - c_bsp_1))
#             L2_error_compare, L2_c_bsp_opt, L2_tj_opt = L2_error_c_bsp_1, L2_c_bsp_1, L2_tj_c_bsp_1
#             L2_c_bsp_1, L2_c_bsp_2 = L2_c_bsp_1 - 0.5 * 2 ** (-i), L2_c_bsp_1 + 0.5 * 2 ** (-i)
#
#         else:
#             L2_error_compare, L2_c_bsp_opt, L2_tj_opt = L2_error_c_bsp_2, L2_c_bsp_2, L2_tj_c_bsp_2
#             # print('optimal h: %s, tuning at: %s' % (c_bsp_2, c_bsp_2 - c_bsp_1))
#             L2_c_bsp_1, L2_c_bsp_2 = L2_c_bsp_2 - 0.5 * 2 ** (-i), L2_c_bsp_2 + 0.5 * 2 ** (-i)
#
#         # print('c_bsp_1,c_bsp_2:', c_bsp_1, c_bsp_2)
#         L2_error_compares.append(L2_error_compare)
#         L2_c_bsp_opt_list.append(L2_c_bsp_opt)
#         L2_tj_opt_list.append(L2_tj_opt)
#
#         # -----------------------------  Linfinity_norm   -----------------------------------
#         Linfinity_tj_c_bsp_1 = BSP_principle(BSP_left, BSP_right_W, Linfinity_c_bsp_1, total_steps)
#         Linfinity_tj_c_bsp_2 = BSP_principle(BSP_left, BSP_right_W, Linfinity_c_bsp_2, total_steps)
#         Linfinity_error_c_bsp_1 = \
#         Predicted_KGD(X_train_L_tr, y_train_L_tr, X_train_L_val, y_train_L_val, dim, Linfinity_tj_c_bsp_1, step_size)[2]
#         Linfinity_error_c_bsp_2 = \
#         Predicted_KGD(X_train_L_tr, y_train_L_tr, X_train_L_val, y_train_L_val, dim, Linfinity_tj_c_bsp_2, step_size)[2]
#
#         if Linfinity_error_c_bsp_1 <= Linfinity_error_c_bsp_2:
#             Linfinity_error_compare, Linfinity_c_bsp_opt, Linfinity_tj_opt = Linfinity_error_c_bsp_1, Linfinity_c_bsp_1, Linfinity_tj_c_bsp_1
#             Linfinity_c_bsp_1, Linfinity_c_bsp_2 = Linfinity_c_bsp_1 - 0.5 * 2 ** (
#                 -i), Linfinity_c_bsp_1 + 0.5 * 2 ** (-i)
#
#         else:
#             Linfinity_error_compare, Linfinity_c_bsp_opt, Linfinity_tj_opt = Linfinity_error_c_bsp_2, Linfinity_c_bsp_2, Linfinity_tj_c_bsp_2
#             Linfinity_c_bsp_1, Linfinity_c_bsp_2 = Linfinity_c_bsp_2 - 0.5 * 2 ** (
#                 -i), Linfinity_c_bsp_2 + 0.5 * 2 ** (-i)
#
#         Linfinity_error_compares.append(Linfinity_error_compare)
#         Linfinity_c_bsp_opt_list.append(Linfinity_c_bsp_opt)
#         Linfinity_tj_opt_list.append(Linfinity_tj_opt)
#
#     index_L2 = L2_error_compares.index(min(L2_error_compares))
#     L2_C, L2_t, L2_min_error = L2_c_bsp_opt_list[index_L2], L2_tj_opt_list[index_L2], min(L2_error_compares)
#     index_Linfinity = Linfinity_error_compares.index(min(Linfinity_error_compares))
#     Linfinity_C, Linfinity_t, Linfinity_min_error = Linfinity_c_bsp_opt_list[index_Linfinity], Linfinity_tj_opt_list[
#         index_Linfinity], min(Linfinity_error_compares)
#     # print('L2_C, L2_t, L2_min_error:', (L2_C, L2_t, L2_min_error))
#     # print('Linfinity_C, Linfinity_t, Linfinity_min_error:', (Linfinity_C, Linfinity_t, Linfinity_min_error))
#
#     # print('---------------------- validation result in selecting the constant  -----------------------')
#     # print('L2_c_bsp_opt_list:', L2_c_bsp_opt_list)
#     # print('L2_tj_opt_list:', L2_tj_opt_list)
#     # print('L2_C, L2_t, L2_min_error:', (L2_C, L2_t, L2_min_error))
#     # print('Linfinity_c_bsp_opt_list:', Linfinity_c_bsp_opt_list)
#     # print('Linfinity_tj_opt_list:', Linfinity_tj_opt_list)
#     # print('Linfinity_C, Linfinity_t, Linfinity_min_error:', (Linfinity_C, Linfinity_t, Linfinity_min_error))
#
#     # # 💎logging in process
#     # with open(log_filename, 'a') as log_file:
#     #     log_file.write(f'\n------------------ total data size : {total_steps}; Split L data size : {len(X_train_L)} ------------------\n-----------valadition result:-----------\n'
#     #                     f'L2_c_bsp_opt_list: {L2_c_bsp_opt_list};\nL2_tj_opt_list: {L2_tj_opt_list};\nLinfinity_c_bsp_opt_list: {Linfinity_c_bsp_opt_list};\nLinfinity_tj_opt_list: {Linfinity_tj_opt_list}\n'
#     #                    f'L2_C:{L2_C};\nL2_t:{L2_t};\nL2_min_error:{L2_min_error}\n'
#     #                    f'Linfinity_C:{Linfinity_C};\nLinfinity_t:{Linfinity_t};\nLinfinity_min_error:{Linfinity_min_error}\n')
#
#     return L2_C, L2_t, L2_min_error, Linfinity_C, Linfinity_t, Linfinity_min_error



# def select_t_final(X_train, y_train, X_train_L, y_train_L, dim, step_size, split_L_tr, total_steps, log_filename):
#     if len(X_train_L) <= 800:
#         print('len(X_train_L) <= 800', len(X_train_L))
#         L2_C, _, _, Linfinity_C, _, _ = select_c_star_for_smallL(X_train_L, y_train_L, dim, step_size, split_L_tr, total_steps, log_filename)
#     else:
#         print('len(X_train_L) > 800', len(X_train_L))
#         L2_C, _, _, Linfinity_C, _, _ = select_c_star(X_train_L, y_train_L, dim, step_size, split_L_tr, total_steps, log_filename)
#     BSP_left, BSP_right_W = BSP_left_right_calculation(X_train, y_train, dim, total_steps, step_size)
#     L2_t_star = BSP_principle(BSP_left, BSP_right_W, L2_C, total_steps)
#     Linfinity_t_star = BSP_principle(BSP_left, BSP_right_W, Linfinity_C, total_steps)
#     return L2_C, L2_t_star, Linfinity_C, Linfinity_t_star


def select_t_final(X_train, y_train, X_train_L, y_train_L, dim, step_size, split_L_tr, total_steps, log_filename):
    L2_C, _, _, Linfinity_C, _, _ = select_c_star(X_train_L, y_train_L, dim, step_size, split_L_tr, total_steps, log_filename)
    BSP_left, BSP_right_W = BSP_left_right_calculation(X_train, y_train, dim, total_steps, step_size)
    L2_t_star = BSP_principle(BSP_left, BSP_right_W, L2_C, total_steps)
    Linfinity_t_star = BSP_principle(BSP_left, BSP_right_W, Linfinity_C, total_steps)
    return L2_C, L2_t_star, Linfinity_C, Linfinity_t_star


def Test_error_KGD_BSP(X_train, y_train, X_test, y_test, dim, step_size, split_L, split_L_tr, log_filename):
    total_steps = len(X_train)
    random.seed(1)
    random_train = random.sample(list(range(len(X_train))), split_L)  # size为L的training data
    random_validation = [element for element in list(range(len(X_train))) if element not in random_train] # size为|D|-L的validation data
    X_train_L, X_validation_L = X_train[random_train], X_train[random_validation]  # 长度分别是L, |D|-L
    y_train_L, y_validation_L = y_train[random_train], y_train[random_validation]
    L2_C, L2_t_star, Linfinity_C, Linfinity_t_star = select_t_final(X_train, y_train, X_train_L, y_train_L, dim, step_size, split_L_tr, total_steps, log_filename)
    # L2_C, L2_t_star, Linfinity_C, Linfinity_t_star = select_t_final(X_train, y_train, dim, step_size, split_L, log_filename)
    # print(X_train_L[0:5])

    L2_test_error = Predicted_KGD(X_train, y_train, X_test, y_test, dim, L2_t_star, step_size)[1]
    Linfinity_test_error = Predicted_KGD(X_train, y_train, X_test, y_test, dim, Linfinity_t_star, step_size)[2]
    return L2_C, L2_t_star, L2_test_error, Linfinity_C, Linfinity_t_star, Linfinity_test_error


# used by sim_l2norm_c
# def Fun_for_rmse_C_plot(X_train, y_train, X_test, y_test, dim, C_bsp_list, step_size):
#     total_steps = len(X_train)
#     BSP_left, BSP_right_W = BSP_left_right_calculation(X_train, y_train, dim, total_steps, step_size)
#     t_hat_list, L2_norm_list, Linfinity_norm_list = [], [], []
#     for C_bsp in C_bsp_list:
#         t_hat = BSP_principle(BSP_left, BSP_right_W, C_bsp, total_steps)
#         _, L2_test_error, Linfinity_test_error = Predicted_KGD(X_train, y_train, X_test, y_test, dim, t_hat, step_size)
#         t_hat_list.append(t_hat)
#         L2_norm_list.append(L2_test_error)
#         Linfinity_norm_list.append(Linfinity_test_error)
#     return t_hat_list, L2_norm_list, Linfinity_norm_list


def Fun_for_rmse_C_plot(X_train, y_train, X_test, y_test, dim, C_bsp_list, step_size, split_L, split_L_tr):
    total_steps = len(X_train)

    random.seed(1)
    random_train = random.sample(list(range(len(X_train))), split_L)  # size为L的training data
    random_validation = [element for element in list(range(len(X_train))) if
                         element not in random_train]  # size为|D|-L的validation data
    X_train_L, X_validation_L = X_train[random_train], X_train[random_validation]  # 长度分别是L, |D|-L
    y_train_L, y_validation_L = y_train[random_train], y_train[random_validation]

    random.seed(1)
    random_train = random.sample(list(range(len(X_train_L))), split_L_tr)  # size为L的training data
    random_validation = [element for element in list(range(len(X_train_L))) if
                         element not in random_train]  # size为|D|-L的validation data
    X_train_L_tr, X_train_L_val = X_train_L[random_train], X_train_L[random_validation]  # 长度分别是L, |D|-L
    y_train_L_tr, y_train_L_val = y_train_L[random_train], y_train_L[random_validation]

    # print('X_train_L_tr', X_train_L_tr.shape)
    # print('y_train_L_tr', y_train_L_tr.shape)
    # print('X_train_L_val', X_train_L_val.shape)
    # print('y_train_L_val', y_train_L_val.shape)

    BSP_left, BSP_right_W = BSP_left_right_calculation(X_train_L_tr, y_train_L_tr, dim, total_steps, step_size)
    t_hat_list, L2_norm_list, Linfinity_norm_list = [], [], []
    for C_bsp in C_bsp_list:
        t_hat = BSP_principle(BSP_left, BSP_right_W, C_bsp, total_steps)
        _, L2_test_error, Linfinity_test_error = Predicted_KGD(X_train_L_val, y_train_L_val, X_test, y_test, dim, t_hat, step_size)
        t_hat_list.append(t_hat)
        L2_norm_list.append(L2_test_error)
        Linfinity_norm_list.append(Linfinity_test_error)
    return t_hat_list, L2_norm_list, Linfinity_norm_list



# def Test_error_KGD_BSP(X_train, y_train, X_test, y_test, dim, step_size, split_L, log_filename):
#     L2_C, L2_t_star, Linfinity_C, Linfinity_t_star = select_t_final(X_train, y_train, dim, step_size, split_L, log_filename)
#     L2_test_error = Predicted_KGD(X_train, y_train, X_test, y_test, dim, L2_t_star, step_size)[1]
#     Linfinity_test_error = Predicted_KGD(X_train, y_train, X_test, y_test, dim, Linfinity_t_star, step_size)[2]
#     return L2_C, L2_t_star, L2_test_error, Linfinity_C, Linfinity_t_star, Linfinity_test_error



# time_start = time.time()
# dim = 1
# step_size = 1
# np.random.seed(10)
# delta_ = 0.9
# noise_var = 0.2
# train_size = 1500
# split_L = int(train_size * 0.7)
# train, test = (train_size, dim), (200, dim)
# X_train, y_train, X_test, y_test = generate_data(train, test, dim, noise_var)
# L2_C, L2_t_star, L2_test_error, Linfinity_C, Linfinity_t_star, Linfinity_test_error = Test_error_KGD_BSP(X_train, y_train, X_test, y_test, dim, step_size, split_L)
#
# print('-----------------------------------------------------final test error----------------------------------------------------- ')
# print('L2_C, L2_t_star, L2_test_error', (L2_C, L2_t_star, L2_test_error))
# print('Linfinity_C, Linfinity_t_star, Linfinity_test_error', (Linfinity_C, Linfinity_t_star, Linfinity_test_error))
# time_total = time.time() - time_start
# print('runing time:', time_total)



# ------------------------------From dim = 1 ------------------------------------------
# Train set X:(1500, 1), y:(1500, 1)  |  Test set X:(200, 1), y:(200, 1)
# (1500,)
# c_bsp_opt_list [0.25, 0.125, 0.1875, 0.15625, 0.140625, 0.1328125, 0.13671875, 0.138671875, 0.1396484375, 0.14013671875, 0.140380859375, 0.1402587890625, 0.14019775390625, 0.140167236328125]
# tj_opt_list [145, 482, 178, 229, 334, 405, 369, 351, 343, 338, 336, 337, 338, 338]
# error_compares [0.19608130061257553, 0.195948714412554, 0.1960002112745592, 0.19594889058477047, 0.1959196591426257, 0.19592698665627867, 0.19592134431661665, 0.19591995311526222, 0.19591968428244386, 0.19591963303208104, 0.19591963851598973, 0.1959196338936102, 0.19591963303208104, 0.19591963303208104]
# (1500,)
# -----------------------------------------------------final test error-----------------------------------------------------
# 0.14013671875 478 0.01411324510228216
# c_bsp_star 0.14013671875
# t_star 478
# test_error 0.01411324510228216
# runing time: 5.521916151046753



# c_bsp_opt_list [0.25, 0.125, 0.0625, 0.03125, 0.015625, 0.0078125, 0.00390625, 0.001953125, 0.0009765625, 0.00048828125, 0.000244140625, 0.0001220703125, 6.103515625e-05, 3.0517578125e-05]
# tj_opt_list [145, 482, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500]
# error_compares [0.5804877462353095, 0.5686585391488737, 0.564805711137079, 0.564805711137079, 0.564805711137079, 0.564805711137079, 0.564805711137079, 0.564805711137079, 0.564805711137079, 0.564805711137079, 0.564805711137079, 0.564805711137079, 0.564805711137079, 0.564805711137079]
# (1500,)
# error_norm infinity_norm
# -----------------------------------------------------final test error-----------------------------------------------------
# 0.0625 1500 0.052747590451542536
# c_bsp_star 0.0625
# t_star 1500
# test_error 0.052747590451542536
# runing time: 10.611457109451294

