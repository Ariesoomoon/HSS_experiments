import pandas as pd
from numpy import *
import numpy as np
import math
import h5py
from sklearn.model_selection import KFold
import os, time
time_start = time.time()
import random
import matplotlib.pyplot as plt


'''------------------------------------------------定义核函数------------------------------------------------'''
def kernel_matrix_dim_1(x, y):
    n,t = len(x), len(y)
    mat_1 = np.ones((t,n))
    y_1 = np.reshape(y, (t, 1), order='A')  # (t, 1)
    y_1 = np.repeat(y_1, n, axis=1)         # (t, n)
    x_1 = np.reshape(x, (1, n), order='A')  # (1, n)
    x_1 = np.repeat(x_1, t, axis=0)         # (t, n)
    kermatrix = np.minimum(x_1, y_1) + mat_1
    return kermatrix

def func_kernel_dim_3(x):
    if x >= 0 and x <= 1:
        result = (1 - x) ** 4 * (4*x+1)
    else:
        result = 0.0
    return result

# (2) gaussian kernel
def gaussian_k(x):
    result = math.exp(-x**2)
    return result

def kernel_matrix_dim_3(x, y):
    n, t = len(x), len(y)
    y_1 = np.reshape(y, (t, 1, 3))
    y_1 = np.repeat(y_1, n, axis=1)  # (t,n,3)
    x_1 = np.reshape(x, (1, n, 3))
    x_1 = np.repeat(x_1, t, axis=0)  # (t,n,3)
    dis = x_1 - y_1
    dis_norm = np.linalg.norm(dis, axis=2)   # (t,n)
    # for kernel defined in "h3_k()"
    h3_k_vector = np.vectorize(func_kernel_dim_3)
    kermatrix = h3_k_vector(dis_norm)
    return kermatrix

'''------------------------------------------------定义回归函数------------------------------------------------'''
def func_dim_1(x):
    if x>=0 and x<=0.5:
        result=x
    else:
        result=1-x
    return result

def create_y_func_dim_1(x):
    func_dim_1_vector = np.vectorize(func_dim_1)
    y = func_dim_1_vector(x)      # (6,n)
    return y


def func_dim_3(norm_x):
    if norm_x>=0 and norm_x<=1:
        result=(1-norm_x)**6 * (35*norm_x**2 + 18*norm_x + 3)
    else:
        result=0
    return result


def create_y_func_dim_3(x):
    norm_x = np.linalg.norm(x, axis=1)
    func_dim_3_vector = np.vectorize(func_dim_3)
    y = func_dim_3_vector(norm_x)      # (6,n)
    return y


'''------------------------------------------------采集样本------------------------------------------------'''
def sample(train_size, test_size,  dim, noise_var):
    X_train = np.random.uniform(0.0, 1.0, train_size)
    X_test = np.random.uniform(0.0, 1.0, test_size)
    truncated_noise_value = 0.4
    if dim == 1:
        noise = np.random.normal(0, noise_var, train_size)
        noise_clipped = np.clip(noise, -truncated_noise_value, truncated_noise_value)
        y_train = create_y_func_dim_1(X_train) + noise # or noise_clipped
        y_test = create_y_func_dim_1(X_test)
    else: # d=3
        noise = np.random.normal(0, noise_var, train_size[0])
        noise_clipped = np.clip(noise, -truncated_noise_value, truncated_noise_value)
        y_train = create_y_func_dim_3(X_train) + noise # or noise_clipped
        y_test = create_y_func_dim_3(X_test)
    return X_train.shape, y_train.shape, X_train, y_train, X_test.shape, y_test.shape, X_test, y_test


def generate_data(train, test, dim, noise_var):
    print('------------------------------------------------------------------------------------------------------ noise_var:', noise_var)
    samples = sample(train, test, dim, noise_var)
    X_train, y_train, X_test, y_test = samples[2], samples[3], samples[6], samples[7]
    print('------------------------------From dim = %s ------------------------------------------' % dim)
    print('Train set X:%s, y:%s  |  Test set X:%s, y:%s' % (samples[0], samples[1], samples[4], samples[5]))
    return X_train, y_train, X_test, y_test


'''------------------------------------------------计算有效维------------------------------------------------'''
# 计算有效维，快速计算，直接计算出所有steps的有效维
def effective_dim(X_tra, dim, T_upper):
    ker = kernel_matrix_dim_1(X_tra, X_tra) if dim == 1 else kernel_matrix_dim_3(X_tra, X_tra)
    U, S, V = np.linalg.svd(ker)

    step_t_list = list(range(1, T_upper + 1, 1))
    step_t_array = np.array(step_t_list)
    n_s, n_t = S.shape[0], step_t_array.shape[0]

    step_t_array = np.reshape(step_t_array, (n_t, 1)) # (n_t, 1)
    step_t_array = np.repeat(step_t_array, n_s, axis=1) # (n_t, n_s)
    step_t_array = step_t_array.T   # (n_s, n_t)

    S_new = np.reshape(S, (n_s, 1)) # (n_s, 1)
    S_new = np.repeat(S_new, n_t, axis=1) # (n_s, n_t)

    S_parameter = S_new/(S_new + (1/step_t_array) * n_s) #
    effect_dim = np.sum(S_parameter, axis = 0)
    return effect_dim



'''-------------------------------计算 KGD的系数alpha(对应论文中的c_t, 默认c_0=(0,...,0))和核矩阵ker ------------------------------------'''
def Alpha_KGD_vector(X_train, y_tra, dim, step_t, step_size):
    ker = kernel_matrix_dim_1(X_train, X_train) if dim == 1 else kernel_matrix_dim_3(X_train, X_train)
    n = len(X_train)
    y_tra = np.reshape(y_tra, (n, 1))
    alpha = np.reshape(np.zeros(n), (n, 1))
    # for i in range(step_t + 1): # 应该改为step_t，此时对应才是c_t
    for i in range(step_t):
        alpha = alpha + (step_size / n) * (y_tra - np.dot(ker, alpha)) # t=1,...,t # i=0,计算的是t=1时的结果
    return alpha


def Predicted_KGD(X_train, y_tra, x_tes, y_tes, dim, step_t, step_size): # 计算的实际上是t=step_t+1时对用的结果
    y_tes = np.squeeze(y_tes)
    n, t = len(X_train), len(x_tes)
    pred_alpha = Alpha_KGD_vector(X_train, y_tra, dim, step_t, step_size)  # (n, 1)
    if dim == 1:
        pred_ker = kernel_matrix_dim_1(X_train, x_tes)  # (n, n)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)

    else:
        pred_ker = kernel_matrix_dim_3(X_train, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)

    average_error = np.sum((y_fit - y_tes) ** 2) / t
    L2_norm = math.sqrt(average_error)
    infinity_norm = np.max(np.abs(y_fit - y_tes))
    return y_fit, L2_norm, infinity_norm


def Alpha_KGD(X_train, y_tra, dim, step_t, step_size):
    ker = kernel_matrix_dim_1(X_train, X_train) if dim == 1 else kernel_matrix_dim_3(X_train, X_train)
    # U, S, V = np.linalg.svd(ker)
    # step_size = 1 / np.max(S)
    n = len(X_train)
    y_tra = np.reshape(y_tra, (n, 1))
    alpha = np.reshape(np.zeros(n), (n, 1))
    alpha_matrix = np.empty(shape=(n, step_t+2))  # alpha_0, alpha_1, ..., alpha_t, alpha_t+1
    alpha_matrix[:, 0] = np.squeeze(alpha)  # 先存alpha_0
    for i in range(step_t + 1):
        alpha = alpha + (step_size / n) * (y_tra - np.dot(ker, alpha))
        alpha_matrix[:, i+1] = np.squeeze(alpha) # i=0时,存的是alpha_1， i=step_t时,存的是alpha_t+1，
    return alpha_matrix  # (n, t+2)


'''----------------------------------------------------------------lepskii_principle----------------------------------------------------------------'''
def W_D_t_lp(X_train, dim, T_upper):
    w_d_t_list = []
    effect_dim = effective_dim(X_train, dim, T_upper)
    for step_t in range(1, T_upper + 1):
        w_d_t = np.sqrt(step_t) * (effect_dim[step_t - 1] + 1) / np.sqrt(len(X_train))
        w_d_t_list.append(w_d_t) # 对应t=1, 2, ..., T
    return w_d_t_list


def LP_left_right_calculation(X_train, y_tra, dim, total_steps, step_size):
    ker = kernel_matrix_dim_1(X_train, X_train) if dim == 1 else kernel_matrix_dim_3(X_train, X_train)
    C_t_matrix = Alpha_KGD(X_train, y_tra, dim, total_steps, step_size) # (D, T+2)
    n_D = len(X_train)
    n_T = total_steps

    # ------------------- (1) 构造LP的左侧：LP_left ------------------------------
    C_t1_matrix = C_t_matrix[:, 1:-1]  # (D, T)
    C_t1_tensor = np.reshape(C_t1_matrix, (1, n_D, n_T), order='A')  # (1, D, T)
    C_t1_tensor = np.repeat(C_t1_tensor, n_T, axis=0)  # (T, D, T)

    # 对于C_t_tensor
    C_t_matrix_truncated= C_t_matrix[:, 1:-1] # (D, T), 对应的step, 1, 2, ..., T
    C_t_matrix_truncated = C_t_matrix_truncated.T # (T, D)
    C_t_tensor = C_t_matrix_truncated[:, :, None].repeat(n_T, axis=2) # (T, D, T)

    # 对于ker_tensor
    ker_tensor = np.reshape(ker, (1, n_D, n_D), order='A')  # (1, D, D)
    ker_tensor = np.repeat(ker_tensor, n_T, axis=0) # (T, D, D)

    # 对于ker_square_tensor
    ker_square_matrix = np.dot(ker, ker)  # (D, D)
    ker_square_tensor = np.reshape(ker_square_matrix, (1, n_D, n_D), order='A')  # (1, D, D)
    ker_square_tensor = np.repeat(ker_square_tensor, n_T, axis=0) # (T, D, D)

    # 对于C_diff_tensor = C_t1_tensor - C_t_tensor
    C_diff_tensor = C_t1_tensor - C_t_tensor # (T, D, T)， 第一列对应着 c1-c0
    C_diff_tensor_T = C_diff_tensor.transpose(0, 2, 1) # (T, T, D) ,第一行对应着 c1-c0

    # 计算norm_D_square_matrix
    C_diff_T_K_square = np.matmul(C_diff_tensor_T, ker_square_tensor) # (T, T, D),每一个t所对应的所有的LP计算
    C_diff_T_K_square_C_diff = np.matmul(C_diff_T_K_square, C_diff_tensor)  # (T, T, T) ⚠️，在这个地方，有服输，这里就要扶着那些负数为0，而不是后面才开始
    C_diff_T_K_square_C_diff[C_diff_T_K_square_C_diff < 0] = 0  # 对角线上的元素保持不变就好
    norm_D_square_matrix = C_diff_T_K_square_C_diff / len(X_train)  #(T, T, T)

    # 构造我们需要的norm_D数值；每一个（T, T)矩阵的对角线元素，变成列向量，存入一个(T T)的矩阵中
    norm_D_diag_elements = [np.diagonal(norm_D_square_matrix[i]) for i in range(norm_D_square_matrix.shape[0])] # 提取对角线上的元素
    norm_D_matrix_diag = np.transpose(np.array(norm_D_diag_elements)) # (T, T)
    LP_left_norm_d_part = np.tril(norm_D_matrix_diag)  # 对于多个t，多个t1所对应的norm_d,(D, D+1); 将上对角线上的元素都替换为0

    # 计算norm_K_square_matrix
    C_diff_T_K = np.matmul(C_diff_tensor_T, ker_tensor) # (T, T, D),每一个t所对应的所有的LP计算
    C_diff_T_K_C_diff = np.matmul(C_diff_T_K, C_diff_tensor)  # (T, T, T) ⚠️，在这个地方，有服输，这里就要扶着那些负数为0，而不是后面才开始
    C_diff_T_K_C_diff[C_diff_T_K_C_diff < 0] = 0  # 对角线上的元素保持不变就好
    norm_K_square_matrix = C_diff_T_K_C_diff

    # 构造我们需要的norm_K数值；每一个（T, T)矩阵的对角线元素，变成列向量，存入一个(T T)的矩阵中
    norm_K_diag_elements = [np.diagonal(norm_K_square_matrix[i]) for i in range(norm_K_square_matrix.shape[0])] # 提取对角线上的元素
    norm_K_matrix_diag = np.transpose(np.array(norm_K_diag_elements)) # (T, T)
    LP_left_norm_k_part = np.tril(norm_K_matrix_diag)  # 对于多个t，多个t1所对应的norm_d,(T, T); 将上对角线上的元素都替换为0

    # 对LP_left_norm_k_part的每一行（也就是每个t1）, 都乘以对应的1/t1
    t1_vector = 1 / np.arange(1, n_T + 1) # 生成一个包含1到T的向量。
    t1_matrix = np.tile(t1_vector.reshape(n_T, 1), (1, n_T)) # 将向量重塑为一个T行1列的列向量,将这个列向量沿着列方向重复T次，形成一个(T, T)的矩阵, 每一行都是相同的元素
    LP_left_t1_and_norm_k_part = t1_matrix * LP_left_norm_k_part #  两个矩阵对应位置元素相乘
    LP_left = np.sqrt(LP_left_norm_d_part + LP_left_t1_and_norm_k_part) # (T, T)

    # ------------------- (2) 构造LP的右侧: LP_right_t_W ------------------------------
    W_D_list= W_D_t_lp(X_train, dim, total_steps)
    W_D_array = np.array(W_D_list)  # (T, )
    W_D_array = np.reshape(W_D_array, (n_T, 1)) # (T, 1)
    W_D_matrix = np.repeat(W_D_array, n_T, axis=1)  # (T, T)
    t1_vector2 = np.arange(1, n_T + 1) ** (-0.5)
    t1_matrix2 = np.tile(t1_vector2.reshape(n_T, 1), (1, n_T))
    LP_right_t_W = t1_matrix2 * W_D_matrix
    LP_right_t_W = np.tril(LP_right_t_W)

    return LP_left, LP_right_t_W



def Lepskii_principle(LP_left, LP_right_WC, C_LP, total_steps):
    LP_right = C_LP * LP_right_WC
    smaller_mask = np.all(LP_left <= LP_right, axis=0) # 使用向量化操作来比较 LP_left 和 LP_right
    if np.any(smaller_mask):
        t_LP = np.argmax(smaller_mask) # 找到满足条件的最小列索引
    else:
        t_LP = None
    # print('--------total_steps = %s,  C_LP=%s, t_LP=%s' % (total_steps, C_LP, t_LP))
    return t_LP


'''-------------------------------  测试参数c的范围用  ---------------------------------'''
def select_c_lp(X_train, y_train, dim, step_size, split_L, log_filename):
    random.seed(1)
    random_train = random.sample(list(range(len(X_train))), split_L)  # size为L的training data
    random_validation = [element for element in list(range(len(X_train))) if element not in random_train] # size为|D|-L的validation data
    X_train_L, X_validation_L = X_train[random_train], X_train[random_validation]  # 长度分别是L, |D|-L
    y_train_L, y_validation_L = y_train[random_train], y_train[random_validation]

    total_steps = len(X_train)
    LP_left, LP_right_WC = LP_left_right_calculation(X_train_L, y_train_L, dim, total_steps, step_size)
    L2_error_list, Linfinity_error_list, LP_tj_list = [], [], []

    C_lp_list = [0.000001+i * 0.1 for i in range(0, 10)]
    for C_lp in C_lp_list:
        tj_c_lp_1 = Lepskii_principle(LP_left, LP_right_WC, C_lp, total_steps)
        LP_tj_list.append(tj_c_lp_1)
        # # L2_norm
        # L2_error_c_lp_1 = Predicted_KGD(X_train_L, y_train_L, X_validation_L, y_validation_L, dim, tj_c_lp_1, step_size)[1]
        # L2_error_list.append(L2_error_c_lp_1)
        # # Linfinity_norm
        # Linfinity_error_c_lp_1 = Predicted_KGD(X_train_L, y_train_L, X_validation_L, y_validation_L, dim, tj_c_lp_1, step_size)[2]
        # Linfinity_error_list.append(Linfinity_error_c_lp_1)

        _, L2_error_c_lp_1, Linfinity_error_c_lp_1 = Predicted_KGD(X_train_L, y_train_L, X_validation_L, y_validation_L, dim, tj_c_lp_1, step_size)
        L2_error_list.append(L2_error_c_lp_1)
        Linfinity_error_list.append(Linfinity_error_c_lp_1)


    index_L2 = L2_error_list.index(min(L2_error_list))
    L2_C, L2_t, L2_min_error = C_lp_list[index_L2], LP_tj_list[index_L2], min(L2_error_list)
    index_Linfinity = Linfinity_error_list.index(min(Linfinity_error_list))
    Linfinity_C, Linfinity_t, Linfinity_min_error = C_lp_list[index_Linfinity], LP_tj_list[index_Linfinity], min(Linfinity_error_list)

    print('---------------------- validation result in selecting the constant  -----------------------')
    print('C_lp_list:', C_lp_list)
    print('LP_tj_list:', LP_tj_list)
    print('L2_error_list:', L2_error_list)
    print('L2_C, L2_t, L2_min_error:', (L2_C, L2_t, L2_min_error))
    print('Linfinity_error_list:', Linfinity_error_list)
    print('Linfinity_C, Linfinity_t, Linfinity_min_error:', (Linfinity_C, Linfinity_t, Linfinity_min_error))
    # 💎logging in process
    with open(log_filename, 'a') as log_file:
        log_file.write(f'\n--------------------------- data size : {len(X_train)} -------------------------------------\n-----------valadition result:-----------\n'
                       f'C_lp_list: {C_lp_list};\nLP_tj_list: {LP_tj_list};\nL2_error_list: {L2_error_list};\nLinfinity_error_list: {Linfinity_error_list}\n'
                       f'L2_C:{L2_C};\nL2_t:{L2_t};\nL2_min_error:{L2_min_error}\n'
                       f'Linfinity_C:{Linfinity_C};\nLinfinity_t:{Linfinity_t};\nLinfinity_min_error:{Linfinity_min_error}\n')

    return L2_C, L2_t, L2_min_error, Linfinity_C, Linfinity_t, Linfinity_min_error



'''-------------------------------  正式跑数据时用  ---------------------------------'''
# def select_c_lp(X_train, y_train, dim, step_size, split_L, log_filename):
#     random.seed(1)
#     random_train = random.sample(list(range(len(X_train))), split_L)  # size为L的training data
#     random_validation = [element for element in list(range(len(X_train))) if element not in random_train] # size为|D|-L的validation data
#     X_train_L, X_validation_L = X_train[random_train], X_train[random_validation]  # 长度分别是L, |D|-L
#     y_train_L, y_validation_L = y_train[random_train], y_train[random_validation]
#
#     total_steps = len(X_train)
#     LP_left, LP_right_WC = LP_left_right_calculation(X_train_L, y_train_L, dim, total_steps, step_size)
#
#     L2_error_compares, L2_c_lp_opt_list, L2_tj_opt_list = [], [], []
#     Linfinity_error_compares, Linfinity_c_lp_opt_list, Linfinity_tj_opt_list = [], [], []
#
#     L2_c_lp_1, L2_c_lp_2 = 0.125, 0.375
#     Linfinity_c_lp_1, Linfinity_c_lp_2 = 0.125, 0.375
#     for i in range(1, 10):
#         # -----------------------------  L2_norm   -----------------------------------
#         L2_tj_c_lp_1 = Lepskii_principle(LP_left, LP_right_WC, L2_c_lp_1, total_steps)
#         L2_tj_c_lp_2 = Lepskii_principle(LP_left, LP_right_WC, L2_c_lp_2, total_steps)
#         L2_error_c_lp_1 = Predicted_KGD(X_train_L, y_train_L, X_validation_L, y_validation_L, dim, L2_tj_c_lp_1, step_size)[1]
#         L2_error_c_lp_2 = Predicted_KGD(X_train_L, y_train_L, X_validation_L, y_validation_L, dim, L2_tj_c_lp_2, step_size)[1]
#
#         if L2_error_c_lp_1 <= L2_error_c_lp_2:
#             # print('optimal h: %s, tuning at: %s' % (c_lp_1, c_lp_2 - c_lp_1))
#             L2_error_compare, L2_c_lp_opt, L2_tj_opt = L2_error_c_lp_1, L2_c_lp_1, L2_tj_c_lp_1
#             L2_c_lp_1, L2_c_lp_2 = L2_c_lp_1-0.125*2**(-i), L2_c_lp_1+0.125*2**(-i)
#
#         else:
#             L2_error_compare, L2_c_lp_opt, L2_tj_opt = L2_error_c_lp_2, L2_c_lp_2, L2_tj_c_lp_2
#             # print('optimal h: %s, tuning at: %s' % (c_lp_2, c_lp_2 - c_lp_1))
#             L2_c_lp_1, L2_c_lp_2 = L2_c_lp_2-0.125*2**(-i), L2_c_lp_2+0.125*2**(-i)
#
#         # print('c_lp_1,c_lp_2:', c_lp_1, c_lp_2)
#         L2_error_compares.append(L2_error_compare)
#         L2_c_lp_opt_list.append(L2_c_lp_opt)
#         L2_tj_opt_list.append(L2_tj_opt)
#
#         # -----------------------------  Linfinity_norm   -----------------------------------
#         Linfinity_tj_c_lp_1 = Lepskii_principle(LP_left, LP_right_WC, Linfinity_c_lp_1, total_steps)
#         Linfinity_tj_c_lp_2 = Lepskii_principle(LP_left, LP_right_WC, Linfinity_c_lp_2, total_steps)
#         Linfinity_error_c_lp_1 = Predicted_KGD(X_train_L, y_train_L, X_validation_L, y_validation_L, dim, Linfinity_tj_c_lp_1, step_size)[2]
#         Linfinity_error_c_lp_2 = Predicted_KGD(X_train_L, y_train_L, X_validation_L, y_validation_L, dim, Linfinity_tj_c_lp_2, step_size)[2]
#
#         if Linfinity_error_c_lp_1 <= Linfinity_error_c_lp_2:
#             Linfinity_error_compare, Linfinity_c_lp_opt, Linfinity_tj_opt = Linfinity_error_c_lp_1, Linfinity_c_lp_1, Linfinity_tj_c_lp_1
#             Linfinity_c_lp_1, Linfinity_c_lp_2 = Linfinity_c_lp_1-0.125*2**(-i), Linfinity_c_lp_1+0.125*2**(-i)
#
#         else:
#             Linfinity_error_compare, Linfinity_c_lp_opt, Linfinity_tj_opt = Linfinity_error_c_lp_2, Linfinity_c_lp_2, Linfinity_tj_c_lp_2
#             Linfinity_c_lp_1, Linfinity_c_lp_2 = Linfinity_c_lp_2-0.125*2**(-i), Linfinity_c_lp_2+0.125*2**(-i)
#
#         Linfinity_error_compares.append(Linfinity_error_compare)
#         Linfinity_c_lp_opt_list.append(Linfinity_c_lp_opt)
#         Linfinity_tj_opt_list.append(Linfinity_tj_opt)
#
#     index_L2 = L2_error_compares.index(min(L2_error_compares))
#     L2_C, L2_t, L2_min_error = L2_c_lp_opt_list[index_L2], L2_tj_opt_list[index_L2], min(L2_error_compares)
#     index_Linfinity = Linfinity_error_compares.index(min(Linfinity_error_compares))
#     Linfinity_C, Linfinity_t, Linfinity_min_error = Linfinity_c_lp_opt_list[index_Linfinity], Linfinity_tj_opt_list[index_Linfinity], min(Linfinity_error_compares)
#     # print('L2_C, L2_t, L2_min_error:', (L2_C, L2_t, L2_min_error))
#     # print('Linfinity_C, Linfinity_t, Linfinity_min_error:', (Linfinity_C, Linfinity_t, Linfinity_min_error))
#     return L2_C, L2_t, L2_min_error, Linfinity_C, Linfinity_t, Linfinity_min_error


def select_t_final_byLP(X_train, y_train, dim, step_size, split_L, log_filename):
    total_steps = len(X_train)
    L2_C, L2_t, L2_min_error, Linfinity_C, Linfinity_t, Linfinity_min_error = select_c_lp(X_train, y_train, dim, step_size, split_L, log_filename)
    LP_left, LP_right_WC = LP_left_right_calculation(X_train, y_train, dim, total_steps, step_size)
    L2_t_star = Lepskii_principle(LP_left, LP_right_WC, L2_C, total_steps)
    Linfinity_t_star = Lepskii_principle(LP_left, LP_right_WC, Linfinity_C, total_steps)
    return L2_C, L2_t_star, Linfinity_C, Linfinity_t_star


def Test_error_KGD_LP(X_train, y_train, X_test, y_test, dim, step_size, split_L, log_filename):
    L2_C, L2_t_star, Linfinity_C, Linfinity_t_star = select_t_final_byLP(X_train, y_train, dim, step_size, split_L, log_filename)
    L2_test_error = Predicted_KGD(X_train, y_train, X_test, y_test, dim, L2_t_star, step_size)[1]
    Linfinity_test_error = Predicted_KGD(X_train, y_train, X_test, y_test, dim, Linfinity_t_star, step_size)[2]
    return L2_C, L2_t_star, L2_test_error, Linfinity_C, Linfinity_t_star, Linfinity_test_error


# time_start = time.time()
# dim = 1
# step_size = 1
# np.random.seed(10)
# delta_ = 0.9
# noise_var = 0.2
# train_size = 600
# split_L = int(train_size * 0.7)
# train, test = (train_size, dim), (200, dim)
# X_train, y_train, X_test, y_test = generate_data(train, test, dim, noise_var)
# L2_C, L2_t_star, L2_test_error, Linfinity_C, Linfinity_t_star, Linfinity_test_error = Test_error_KGD_LP(X_train, y_train, X_test, y_test, dim, step_size, split_L)
#
# print('-----------------------------------------------------final test error----------------------------------------------------- ')
# print('L2_C, L2_t_star, L2_test_error', (L2_C, L2_t_star, L2_test_error))
# print('Linfinity_C, Linfinity_t_star, Linfinity_test_error', (Linfinity_C, Linfinity_t_star, Linfinity_test_error))
# time_total = time.time() - time_start
# print('runing time:', time_total)


#
# ------------------------------From dim = 1 ------------------------------------------
# Train set X:(600, 1), y:(600, 1)  |  Test set X:(200, 1), y:(200, 1)
# C_lp 1e-06
# C_lp 0.010001
# C_lp 0.020001
# C_lp 0.030001
# C_lp 0.040001
# C_lp 0.050001000000000004
# C_lp 0.060001
# C_lp 0.07000100000000001
# C_lp 0.080001
# C_lp 0.090001
# C_lp_list [1e-06, 0.010001, 0.020001, 0.030001, 0.040001, 0.050001000000000004, 0.060001, 0.07000100000000001, 0.080001, 0.090001]
# LP_tj_list [599, 447, 320, 215, 135, 93, 78, 71, 65, 60]
# error_list [0.19603810715395728, 0.19597689788518796, 0.19601057765497332, 0.1962612239018944, 0.19734660508593682, 0.19961323606628983, 0.2013409836263459, 0.20246383429427084, 0.2036472016512727, 0.2048264561862403]
# min(error_list) 0.19597689788518796
# tj_star 447
# cj_star 0.010001
# -----------------------------------------------------final test error-----------------------------------------------------
# 0.010001 457 0.0190047604166064
# c_lp_star 0.010001
# t_star 457
# test_error 0.0190047604166064
# runing time: 60.50334310531616



# ------------------------------From dim = 1 ------------------------------------------
# Train set X:(600, 1), y:(600, 1)  |  Test set X:(200, 1), y:(200, 1)
# C_lp_list: [1e-06, 0.010001, 0.020001, 0.030001, 0.040001, 0.050001000000000004, 0.060001, 0.07000100000000001, 0.080001, 0.090001]
# LP_tj_list: [599, 447, 320, 215, 135, 93, 78, 71, 65, 60]
# L2_error_list: [0.19603810715395728, 0.19597689788518796, 0.19601057765497332, 0.1962612239018944, 0.19734660508593682, 0.19961323606628983, 0.2013409836263459, 0.20246383429427084, 0.2036472016512727, 0.2048264561862403]
# L2_C, L2_t, L2_min_error: (0.010001, 447, 0.19597689788518796)
# Linfinity_error_list: [0.6610620956186571, 0.6636689436753032, 0.6661927588164522, 0.6691511024049319, 0.6761909520136831, 0.6882370255249822, 0.6962214317341027, 0.7010203302582457, 0.7058118838408236, 0.7103574930088616]
# Linfinity_C, Linfinity_t, Linfinity_min_error: (1e-06, 599, 0.6610620956186571)
# -----------------------------------------------------final test error-----------------------------------------------------
# L2_C, L2_t_star, L2_test_error (0.010001, 457, 0.0190047604166064)
# Linfinity_C, Linfinity_t_star, Linfinity_test_error (1e-06, 599, 0.040360991897307796)
# runing time: 69.996817111969