import time
from Main_functions.KGD_algorithm_by_Backward_Selection_Principle_L2_infinity_norm import generate_data, Fun_for_rmse_C_plot

time_start = time.time()
from numpy import *
import matplotlib.pyplot as plt
from matplotlib import rcParams
import matplotlib.gridspec as gridspec

config = {
    "font.family":'Times New Roman',
    "font.size": 16,
    "mathtext.fontset":'stix',
}
rcParams.update(config)


time_start = time.time()
log_filename = 0.01
split_L_tr_per = 0.7 # 固定不变
# dim = 1
# step_size = 1.4
dim = 1
step_size = 1
split_L_per = 0.8


noise_var = 0.6
# C_bsp_list = [0.00001, 0.0001, 0.001, 0.01] + [i * 0.2 for i in range(1, 30, 2)]
C_bsp_list = [0.00001, 0.0001, 0.001, 0.01] + [i * 0.2 for i in range(1, 30, 1)]

print(C_bsp_list)

'''------------------------------ 图1: 用很大的C，说明存在全局极小值点 -------------------------'''

log_filename = f'../KGD_result_data_log_file/C_test_log/BSP_dim{dim}_noisevar{noise_var}_stepsize{step_size}_seclect_C_log.txt'
# 初始化日志文件
with open(log_filename, 'w') as log_file:
    log_file.write("Start Logging\n")

trial_list = [12] # 0, 1, 2, 3 d=3
# trial_list = [12, 14, 15, 18] # 0, 1, 2, 3 d=1
for size_i in range(10,11):
    train_size = 100 * size_i
    train, test = (train_size, dim), (200, dim)
    print(' ------------------  💎 dim: %s; step_size: %s; train_size:%s; noise_var: %s  ------------------' % (dim, step_size, train_size, noise_var))
    split_L = int(train_size * split_L_per)
    split_L_tr = int(split_L * split_L_tr_per)

    for trial_i in trial_list:
        print('------------------   trial_i: %s  ------------------' % trial_i)
        np.random.seed(trial_i)
        _, _, X_test, y_test = generate_data((300, dim), (500, dim), dim, noise_var)  #保证 test只在不同的trial时有所不同
        X_train, y_train, _, _ = generate_data(train, test, dim, noise_var)
        total_steps = len(X_train)


        t_hat_list, L2_norm_list, Linfinity_norm_list = Fun_for_rmse_C_plot(X_train, y_train, X_test, y_test, dim, C_bsp_list, step_size, split_L, split_L_tr)



        # 💎logging in process "for trial_i in range(10, 20)"
        with open(log_filename, 'a') as log_file:
            log_file.write(
                f'--------------------------- train_size: {train_size}; dim: {dim}; noise_var: {noise_var}; trial_i: {trial_i}-------------------------- \n'
                f'history:\nC_bsp_list: {C_bsp_list}\n'
                f't_hat_list: {t_hat_list}\n'
                f'L2_norm_list: {L2_norm_list}\n'
                f'Linfinity_norm_list: {Linfinity_norm_list}\n')


        # （1） 保存结果
        KGD_result = {
            'C_bsp_list': C_bsp_list,
            't_hat_list': t_hat_list,
            'L2_norm_list': L2_norm_list,
            'Linfinity_norm_list': Linfinity_norm_list}
        filename = f'../HSS_result_data/C_test_result/New_BSP_trainsize{train_size}_dim{dim}_noisevar{noise_var}_stepsize{step_size}_trialindex{trial_i}_L{split_L_per}seclect_C.npy'
        np.save(filename, KGD_result)
        print(KGD_result.keys())

        # (2) 画双坐标图 -- L2 norm
        fig = plt.figure(tight_layout=True)
        gs = gridspec.GridSpec(1, 1)
        ax1 = fig.add_subplot(gs[0, 0])
        # ax1.grid(linestyle='-.', axis="y")
        ax1.plot(C_bsp_list, t_hat_list, c='royalblue', marker='d', linestyle='-', linewidth=1.2, markersize=5)
        ax1.set_ylabel('$t$ under BSP', c='royalblue')
        ax1.set_xlabel(f'$C$ of BSP \n $(d={dim}, |D|={train_size}, \\sigma={noise_var}, \\beta={step_size}$, trialindex{trial_i})', fontsize='18')
        ax1.tick_params(axis='y', colors='royalblue')
        # ax1.set_ylim(0, 17)
        ax2 = ax1.twinx()  # this is the important function
        ax2.plot(C_bsp_list, L2_norm_list, c='brown', marker='d', linestyle='-', linewidth=1.2, markersize=5)
        ax2.set_ylabel('$L_2$ norm', c='brown')
        ax2.tick_params(axis='y', colors='brown')
        # ax2.set_ylim(0.00070, 0.00120)
        plt.savefig(f'./00d1_noise06_D1000_trialrandom12_L08/BSP_L2norm_C_trainsize{train_size}_dim{dim}_noisevar{noise_var}_stepsize{step_size}_trialindex{trial_i}.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
        # plt.show()

        # (2) 画双坐标图 -- Linfty norm
        fig = plt.figure(tight_layout=True)
        gs = gridspec.GridSpec(1, 1)
        ax1 = fig.add_subplot(gs[0, 0])
        # ax1.grid(linestyle='-.', axis="y")
        ax1.plot(C_bsp_list, t_hat_list, c='royalblue', marker='d', linestyle='-', linewidth=1.2, markersize=5)
        ax1.set_ylabel('$t$ under BSP', c='royalblue')
        ax1.set_xlabel(f'$C$ of BSP \n $(d={dim}, |D|={train_size}, \\sigma={noise_var}, \\beta={step_size}$, trialindex{trial_i})', fontsize='18')
        ax1.tick_params(axis='y', colors='royalblue')
        # ax1.set_ylim(0, 17)
        ax2 = ax1.twinx()  # this is the important function
        ax2.plot(C_bsp_list, Linfinity_norm_list, c='brown', marker='d', linestyle='-', linewidth=1.2, markersize=5)
        ax2.set_ylabel('$L_\\infty$ norm', c='brown')
        ax2.tick_params(axis='y', colors='brown')
        # ax2.set_ylim(0.00070, 0.00120)
        plt.savefig(f'./00d1_noise06_D1000_trialrandom12_L08/BSP_Linftynorm_C_trainsize{train_size}_dim{dim}_noisevar{noise_var}_stepsize{step_size}_trialindex{trial_i}.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
        # plt.show()


print('------------------------------ runing information ------------------------------------------')
time_total = time.time() - time_start
print('running time:', time_total)
print("Logging complete.")






#
# dim = 3
# step_size = 3
# noise_var = 0.6
# L2_C_list, Linfty_C_list = [], []
# # for size_i in range(10,11):
# #     train_size = 100 * size_i
# #     for trial_i in range(10, 20):
#
#
# trial_list = [12, 15, 18] # 0, 1, 2, 3 d=3
# # trial_list = [12, 14, 15, 18] # 0, 1, 2, 3 d=1
# for size_i in range(1,16):
#     train_size = 100 * size_i
#     for trial_i in trial_list:
#         filename = f'../KGD_result_data/C_test_result/BSP_trainsize{train_size}_dim{dim}_noisevar{noise_var}_stepsize{step_size}_trialindex{trial_i}_seclect_C.npy'
#         BSP_result = np.load(filename, allow_pickle=True).item()
#         C_bsp_list = BSP_result['C_bsp_list']
#         t_hat_list = BSP_result['t_hat_list']
#         L2_norm_list = BSP_result['L2_norm_list']
#         Linfinity_norm_list = BSP_result['Linfinity_norm_list']
#
#
#         index_L2 = L2_norm_list.index(min(L2_norm_list))
#         L2_C = C_bsp_list[index_L2]
#         L2_C_list.append(L2_C)
#
#         index_Linfty = Linfinity_norm_list.index(min(Linfinity_norm_list))
#         Linfty_C = C_bsp_list[index_Linfty]
#         Linfty_C_list.append(Linfty_C)
#
# print('L2_C_list', L2_C_list)
# print('Linfty_C_list', Linfty_C_list)









#
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
#
#
# # (1) MSE , c
# ax.plot(C_bsp_list, L2_norm_list, c='royalblue', marker='d',  linestyle='-', linewidth=1.2, markersize=5)
# ax.set_xlabel('$\\tilde{C}$ of BSP $(d=1, \sigma=0.2, |D|=1000)$', fontsize='20')
# ax.set_ylabel('$L_2$ norm', fontsize='20')
# plt.yscale('log')
# # plt.ylim(0.018, 0.028)
# plt.savefig(f'../KGD_figures/BSP_L2norm_C_dim{dim}_noise{noise_var}_toolargeC.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()

# # (2) MSE , t
# ax.plot(C_bsp_list, t_hat_list, c='royalblue', marker='d',  linestyle='-', linewidth=1.2, markersize=5)
# ax.set_xlabel('$\\tilde{C}$ of BSP $(d=1, \sigma=0.2, |D|=1000)$', fontsize='20')
# ax.set_ylabel('$t$ under BSP', fontsize='20')
# # plt.yscale('log')
# # plt.ylim(0.018, 0.028)
# plt.savefig(f'../KGD_figures/BSP_t_C_dim{dim}_noise{noise_var}_toolargeC.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()

# (3) 双坐标图
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax1 = fig.add_subplot(gs[0, 0])
# # ax1.grid(linestyle='-.', axis="y")
# ax1.plot(C_bsp_list, t_hat_list, c='royalblue', marker='d', linestyle='-', linewidth=1.2, markersize=5)
# ax1.set_ylabel('$t$ under BSP', c='royalblue')
# ax1.set_xlabel('$\\tilde{C}$ of BSP $(d=1, \sigma=0.2, |D|=1000)$', fontsize='18')
# ax1.tick_params(axis='y', colors='royalblue')
# # ax1.set_ylim(0, 17)
#
# ax2 = ax1.twinx()  # this is the important function
# ax2.plot(C_bsp_list, L2_norm_list, c='brown', marker='d', linestyle='-', linewidth=1.2, markersize=5)
# ax2.set_ylabel('$L_2$ norm', c='brown')
# ax2.tick_params(axis='y', colors='brown')
# # ax2.set_ylim(0.00070, 0.00120)
# plt.savefig(f'./Figure_noise06/BSP_t_and_L2norm_C_dim{dim}_noise{noise_var}_L{split_L_per}_toolargeC.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()



'''------------------------------ 图2: 用正常的C，说明MSE和C的关系 -------------------------'''
# # C_bsp_list = [0.00001, 0.0001, 0.001, 0.01] + [i * 0.05 for i in range(1, 20, 2)] # d=1
# # C_bsp_list = [0.00001, 0.0001, 0.001, 0.01] + [i * 0.1 for i in range(1, 20, 2)] # d=3
#
# # C_bsp_list = [i*0.1 for i in range(0, 20, 1)]
# C_bsp_list = [i*0.25 for i in range(0, 20, 1)]
# # C_bsp_list = [0.00001, 0.0001, 0.001, 0.01] + [i * 0.5 for i in range(1, 20, 2)]
# t_hat_list, L2_norm_list, Linfinity_norm_list = Fun_for_rmse_C_plot(X_train, y_train, X_test, y_test, dim, C_bsp_list, step_size)
# KGD_result = {
#     'C_bsp_list': C_bsp_list,
#     't_hat_list': t_hat_list,
#     'L2_norm_list': L2_norm_list,
#     'Linfinity_norm_list': Linfinity_norm_list}
# filename = f'../KGD_result_data/BSP_rmse_C_dim{dim}_noisevar{noise_var}_stepsize{step_size}_toolargeC.npy'
# np.save(filename, KGD_result)
# print(KGD_result.keys())
#
#
# filename = f'../KGD_result_data/BSP_rmse_C_dim{dim}_noisevar{noise_var}_stepsize{step_size}_toolargeC.npy'
# BSP_result = np.load(filename, allow_pickle=True).item()
# C_bsp_list = BSP_result['C_bsp_list']
# t_hat_list = BSP_result['t_hat_list']
# L2_norm_list = BSP_result['L2_norm_list']
# L2_norm_list = np.array(L2_norm_list) ** 2
# Linfinity_norm_list = BSP_result['Linfinity_norm_list']
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
#
# # # (1) MSE , c
# # ax.plot(C_bsp_list, L2_norm_list, c='royalblue', marker='d',  linestyle='-', linewidth=1.2, markersize=5)
# # ax.set_xlabel('$\\tilde{C}$ of BSP $(d=1, \sigma=0.2, |D|=1000)$', fontsize='20')
# # ax.set_ylabel('$L_2$ norm', fontsize='20')
# # plt.yscale('log')
# # # plt.ylim(0.018, 0.028)
# # plt.savefig(f'../KGD_figures/BSP_L2norm_C_dim{dim}_noise{noise_var}.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# # plt.show()
#
# # # (2) MSE , t
# # ax.plot(C_bsp_list, t_hat_list, c='royalblue', marker='d',  linestyle='-', linewidth=1.2, markersize=5)
# # ax.set_xlabel('$\\tilde{C}$ of BSP $(d=1, \sigma=0.2, |D|=1000)$', fontsize='20')
# # ax.set_ylabel('$t$ under BSP', fontsize='20')
# # # plt.yscale('log')
# # # plt.ylim(0.018, 0.028)
# # plt.savefig(f'../KGD_figures/BSP_t_C_dim{dim}_noise{noise_var}.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# # plt.show()
#
# # (3) 双坐标图
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax1 = fig.add_subplot(gs[0, 0])
# # ax1.grid(linestyle='-.', axis="y")
# ax1.plot(C_bsp_list, t_hat_list, c='royalblue', marker='d', linestyle='-', linewidth=1.2, markersize=5)
# ax1.set_ylabel('$t$ under BSP', c='royalblue')
# ax1.set_xlabel('$\\tilde{C}$ of BSP $(d=3, \sigma=0.2, |D|=1000)$', fontsize='18')
# ax1.tick_params(axis='y', colors='royalblue')
# # ax1.set_ylim(0, 17)
#
# ax2 = ax1.twinx()  # this is the important function
# ax2.plot(C_bsp_list, L2_norm_list, c='brown', marker='d', linestyle='-', linewidth=1.2, markersize=5)
# ax2.set_ylabel('$L_2$ norm', c='brown')
# ax2.tick_params(axis='y', colors='brown')
# # ax2.set_ylim(0.00070, 0.00120)
# plt.savefig(f'../KGD_figures/BSP_t_and_L2norm_C_dim{dim}_noise{noise_var}__toolargeC.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()
#

