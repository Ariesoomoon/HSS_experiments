import time
from Main_functions.KGD_algorithm_by_Backward_Selection_Principle_L2_infinity_norm import generate_data, Fun_for_rmse_C_plot

time_start = time.time()
from numpy import *
import matplotlib.pyplot as plt
from matplotlib import rcParams
import matplotlib.gridspec as gridspec

config = {
    "font.family":'Times New Roman',
    "font.size": 16,
    "mathtext.fontset":'stix',
}
rcParams.update(config)


time_start = time.time()
log_filename = 0.01
split_L_tr_per = 0.7 # 固定不变
# dim = 1
# step_size = 1.4
dim = 3
step_size = 3

noise_var = 0.6
# C_bsp_list = [0.00001, 0.0001, 0.001, 0.01] + [i * 0.2 for i in range(1, 30, 2)]
C_bsp_list = [0.00001, 0.0001, 0.001, 0.01] + [i * 0.1 for i in range(1, 30, 1)]

print(C_bsp_list)

'''------------------------------ 图1: 用很大的C，说明存在全局极小值点 -------------------------'''

log_filename = f'../KGD_result_data_log_file/C_test_log/BSP_dim{dim}_noisevar{noise_var}_stepsize{step_size}_seclect_C_diffL_log.txt'
# 初始化日志文件
with open(log_filename, 'w') as log_file:
    log_file.write("Start Logging\n")

train_size = 1000
trial_list = [23, 25, 26, 29] # 0, 1, 2, 3 d=1

for L_i in range(1,11):
    train, test = (train_size, dim), (200, dim)
    split_L = int(train_size * L_i * 0.1)
    split_L_tr = int(split_L * split_L_tr_per)
    L2_C_list, L2_t_star_list, L2_test_error_list, Linfinity_C_list, Linfinity_t_star_list, Linfinity_test_error_list = [], [], [], [], [], []
    for trial_i in trial_list:
        print('------------------   trial_i: %s  ------------------' % trial_i)
        np.random.seed(trial_i)
        _, _, X_test, y_test = generate_data((300, dim), (500, dim), dim, noise_var)  # 保证 test只在不同的trial时有所不同
        X_train, y_train, _, _ = generate_data(train, test, dim, noise_var)
        t_hat_list, L2_norm_list, Linfinity_norm_list = Fun_for_rmse_C_plot(X_train, y_train, X_test, y_test, dim,
                                                                            C_bsp_list, step_size, split_L,
                                                                            split_L_tr)

        # 💎logging in process "for trial_i in range(10, 20)"
        with open(log_filename, 'a') as log_file:
            log_file.write(
                f'--------------------------- train_size: {train_size}; dim: {dim}; noise_var: {noise_var}; trial_i: {trial_i}-------------------------- \n'
                f'history:\nC_bsp_list: {C_bsp_list}\n'
                f't_hat_list: {t_hat_list}\n'
                f'L2_norm_list: {L2_norm_list}\n'
                f'Linfinity_norm_list: {Linfinity_norm_list}\n')

        # （1） 保存结果
        KGD_result = {
            'C_bsp_list': C_bsp_list,
            't_hat_list': t_hat_list,
            'L2_norm_list': L2_norm_list,
            'Linfinity_norm_list': Linfinity_norm_list}
        filename = f'../KGD_result_data/C_test_result/New_BSP_trainsize{train_size}_dim{dim}_noisevar{noise_var}_stepsize{step_size}_trialindex{trial_i}_diffL_seclect_C.npy'
        np.save(filename, KGD_result)
        print(KGD_result.keys())

        # (2) 画双坐标图 -- L2 norm
        fig = plt.figure(tight_layout=True)
        gs = gridspec.GridSpec(1, 1)
        ax1 = fig.add_subplot(gs[0, 0])
        # ax1.grid(linestyle='-.', axis="y")
        ax1.plot(C_bsp_list, t_hat_list, c='royalblue', marker='d', linestyle='-', linewidth=1.2, markersize=5)
        ax1.set_ylabel('$t$ under BSP', c='royalblue')
        ax1.set_xlabel(
            f'$C$ of BSP \n $(d={dim}, L={split_L}, \\sigma={noise_var}, \\beta={step_size}$, trialindex{trial_i})',
            fontsize='18')
        ax1.tick_params(axis='y', colors='royalblue')
        # ax1.set_ylim(0, 17)
        ax2 = ax1.twinx()  # this is the important function
        ax2.plot(C_bsp_list, L2_norm_list, c='brown', marker='d', linestyle='-', linewidth=1.2, markersize=5)
        ax2.set_ylabel('$L_2$ norm', c='brown')
        ax2.tick_params(axis='y', colors='brown')
        # ax2.set_ylim(0.00070, 0.00120)
        plt.savefig(
            f'./d3_noise06_diffL/BSP_L2norm_C_L{split_L}_dim{dim}_noisevar{noise_var}_stepsize{step_size}_trialindex{trial_i}.pdf',
            dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
        # plt.show()

        # (2) 画双坐标图 -- Linfty norm
        fig = plt.figure(tight_layout=True)
        gs = gridspec.GridSpec(1, 1)
        ax1 = fig.add_subplot(gs[0, 0])
        # ax1.grid(linestyle='-.', axis="y")
        ax1.plot(C_bsp_list, t_hat_list, c='royalblue', marker='d', linestyle='-', linewidth=1.2, markersize=5)
        ax1.set_ylabel('$t$ under BSP', c='royalblue')
        ax1.set_xlabel(
            f'$C$ of BSP \n $(d={dim}, L={split_L}, \\sigma={noise_var}, \\beta={step_size}$, trialindex{trial_i})',
            fontsize='18')
        ax1.tick_params(axis='y', colors='royalblue')
        # ax1.set_ylim(0, 17)
        ax2 = ax1.twinx()  # this is the important function
        ax2.plot(C_bsp_list, Linfinity_norm_list, c='brown', marker='d', linestyle='-', linewidth=1.2, markersize=5)
        ax2.set_ylabel('$L_\\infty$ norm', c='brown')
        ax2.tick_params(axis='y', colors='brown')
        # ax2.set_ylim(0.00070, 0.00120)
        plt.savefig(
            f'./d3_noise06_diffL/BSP_Linftynorm_C_L{split_L}_dim{dim}_noisevar{noise_var}_stepsize{step_size}_trialindex{trial_i}.pdf',
            dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
        # plt.show()

print('------------------------------ runing information ------------------------------------------')
time_total = time.time() - time_start
print('running time:', time_total)
print("Logging complete.")

